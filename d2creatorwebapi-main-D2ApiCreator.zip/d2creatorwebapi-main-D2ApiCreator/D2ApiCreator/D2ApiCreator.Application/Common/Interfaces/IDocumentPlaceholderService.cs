﻿namespace D2ApiCreator.Application.Common.Interfaces;
/// <summary>
/// Service for extracting placeholders from documents
/// </summary>
public interface IDocumentPlaceholderService
{
    /// <summary>
    /// Extracts all placeholders in format &lt;%...%&gt; from a DOCX file
    /// </summary>
    /// <param name="fileStream">The DOCX file stream</param>
    /// <param name="fileName">The name of the file</param>
    /// <returns>List of found placeholders</returns>
    Task<List<string>> ExtractPlaceholdersFromDocxAsync(Stream fileStream, string fileName);
}
