﻿using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Application.DTOs;
using MediatR;
using Microsoft.Extensions.Logging;
namespace D2ApiCreator.Application.Features.Documents.Queries.ExtractPlaceholders;
/// <summary>
/// Handler for extracting placeholders from documents
/// </summary>
public class ExtractPlaceholdersQueryHandler : IRequestHandler<ExtractPlaceholdersQuery, DocumentPlaceholderDto>
{
    private readonly IDocumentPlaceholderService _documentPlaceholderService;
    private readonly ILogger<ExtractPlaceholdersQueryHandler> _logger;
    public ExtractPlaceholdersQueryHandler(
        IDocumentPlaceholderService documentPlaceholderService,
        ILogger<ExtractPlaceholdersQueryHandler> logger)
    {
        _documentPlaceholderService = documentPlaceholderService;
        _logger = logger;
    }
    public async Task<DocumentPlaceholderDto> Handle(ExtractPlaceholdersQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Extracting placeholders from document: {FileName}", request.FileName);
        var placeholders = await _documentPlaceholderService.ExtractPlaceholdersFromDocxAsync(
            request.FileStream, 
            request.FileName);
        return new DocumentPlaceholderDto
        {
            Placeholders = placeholders,
            TotalCount = placeholders.Count,
            FileName = request.FileName
        };
    }
}
