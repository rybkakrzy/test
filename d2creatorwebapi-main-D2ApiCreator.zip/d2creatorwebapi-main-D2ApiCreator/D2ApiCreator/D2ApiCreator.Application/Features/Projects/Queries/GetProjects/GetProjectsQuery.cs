using D2ApiCreator.Application.Common;
using D2ApiCreator.Application.DTOs.Projects;
using MediatR;

namespace D2ApiCreator.Application.Features.Projects.Queries.GetProjects;

/// <summary>
/// Query to get all projects
/// </summary>
public class GetProjectsQuery : IRequest<Result<List<ProjectDto>>>
{
    /// <summary>
    /// Optional tenant ID to filter projects
    /// </summary>
    public Guid? TenantId { get; set; }

    /// <summary>
    /// Optional filter by source
    /// </summary>
    public string? Source { get; set; }

    /// <summary>
    /// Optional limit for pagination
    /// </summary>
    public int? Limit { get; set; }

    /// <summary>
    /// Optional offset for pagination
    /// </summary>
    public int? Offset { get; set; }
}
