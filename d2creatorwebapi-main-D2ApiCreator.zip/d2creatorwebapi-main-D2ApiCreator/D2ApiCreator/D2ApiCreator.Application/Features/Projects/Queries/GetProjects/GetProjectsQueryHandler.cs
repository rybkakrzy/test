using D2ApiCreator.Application.Common;
using D2ApiCreator.Application.DTOs.Projects;
using D2ApiCreator.Domain.Entities;
using D2ApiCreator.Domain.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace D2ApiCreator.Application.Features.Projects.Queries.GetProjects;

/// <summary>
/// Handler for getting all projects
/// </summary>
public class GetProjectsQueryHandler : IRequestHandler<GetProjectsQuery, Result<List<ProjectDto>>>
{
    private readonly IRepository<Project, Guid> _projectRepository;
    private readonly ILogger<GetProjectsQueryHandler> _logger;

    public GetProjectsQueryHandler(
        IRepository<Project, Guid> projectRepository,
        ILogger<GetProjectsQueryHandler> logger)
    {
        _projectRepository = projectRepository;
        _logger = logger;
    }

    public async Task<Result<List<ProjectDto>>> Handle(GetProjectsQuery request, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Getting projects. TenantId: {TenantId}, Source: {Source}", 
                request.TenantId, request.Source);

            var projects = await _projectRepository.GetAllAsync(cancellationToken);

            // Apply filters
            if (request.TenantId.HasValue)
            {
                projects = projects.Where(p => p.TenantId == request.TenantId.Value).ToList();
            }

            if (!string.IsNullOrEmpty(request.Source))
            {
                projects = projects.Where(p => p.Source.Contains(request.Source, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Order by created date descending
            projects = projects.OrderByDescending(p => p.CreatedAt).ToList();

            // Apply pagination
            if (request.Offset.HasValue)
            {
                projects = projects.Skip(request.Offset.Value).ToList();
            }

            if (request.Limit.HasValue)
            {
                projects = projects.Take(request.Limit.Value).ToList();
            }

            // Map to DTOs
            var projectDtos = projects.Select(p => new ProjectDto
            {
                Id = p.Id,
                TenantId = p.TenantId,
                Source = p.Source,
                Name = p.Name,
                DefaultTemplateName = p.DefaultTemplateName,
                CreatedBy = p.CreatedBy,
                CreatedAt = p.CreatedAt,
                RetentionDays = p.RetentionDays,
                Description = p.Description,
                CurrentActiveVersionId = p.CurrentActiveVersionId
            }).ToList();

            _logger.LogInformation("Found {Count} projects", projectDtos.Count);

            return Result<List<ProjectDto>>.Success(projectDtos);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting projects");
            return Result<List<ProjectDto>>.Failure($"Error getting projects: {ex.Message}");
        }
    }
}
