using D2ApiCreator.Application.Common;
using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Application.DTOs.Projects;
using D2ApiCreator.Domain.Entities;
using D2ApiCreator.Domain.Repositories;
using D2ApiCreator.Domain.ValueObjects;
using MediatR;
using Microsoft.Extensions.Logging;

namespace D2ApiCreator.Application.Features.Projects.Commands.CreateProject;

/// <summary>
/// Handler for creating a new project
/// </summary>
public class CreateProjectCommandHandler : IRequestHandler<CreateProjectCommand, Result<ProjectDto>>
{
    private readonly IRepository<Project, Guid> _projectRepository;
    private readonly IRepository<Tenant, Guid> _tenantRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<CreateProjectCommandHandler> _logger;

    public CreateProjectCommandHandler(
        IRepository<Project, Guid> projectRepository,
        IRepository<Tenant, Guid> tenantRepository,
        IUnitOfWork unitOfWork,
        ILogger<CreateProjectCommandHandler> logger)
    {
        _projectRepository = projectRepository;
        _tenantRepository = tenantRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<Result<ProjectDto>> Handle(CreateProjectCommand request, CancellationToken cancellationToken)
    {
        try
        {
            // Generate source if not provided
            var source = string.IsNullOrWhiteSpace(request.Source)
                ? $"PRJ-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString()[..8].ToUpper()}"
                : request.Source;

            _logger.LogInformation("Creating new project with source: {Source}", source);

            // Find tenant by name/identifier
            var tenants = await _tenantRepository.FindAsync(
                t => t.Name == request.TenantId,
                cancellationToken);
            var tenant = tenants.FirstOrDefault();
            
            if (tenant == null)
            {
                _logger.LogWarning("Tenant {TenantId} not found", request.TenantId);
                return Result<ProjectDto>.Failure($"Tenant '{request.TenantId}' not found");
            }

            // Check if project with this source already exists for tenant
            var existingProjects = await _projectRepository.FindAsync(
                p => p.TenantId == tenant.Id && p.Source == source,
                cancellationToken);

            if (existingProjects.Any())
            {
                _logger.LogWarning("Project with source {Source} already exists for tenant {TenantId}", 
                    source, request.TenantId);
                return Result<ProjectDto>.Failure($"Project with source '{source}' already exists");
            }

            // Build metadata from request
            var metadata = new ProjectMetadata(
                applicationName: request.ApplicationName,
                processName: request.ProcessName,
                processOwner: request.ProcessOwner,
                businessLineId: request.BusinessLineId,
                processVersion: request.ProcessVersion,
                processStep: request.ProcessStep,
                statusId: request.StatusId,
                recipientId: request.RecipientId
            );

            // Create project entity
            var project = new Project(
                Guid.NewGuid(),
                tenant.Id,
                source,
                request.Name,
                metadata,
                request.RetentionDays,
                request.CreatedBy
            );

            if (!string.IsNullOrEmpty(request.Description))
            {
                project.UpdateDescription(request.Description);
            }

            // Add to repository
            await _projectRepository.AddAsync(project, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("Successfully created project {ProjectId} with source {Source}", 
                project.Id, project.Source);

            // Map to DTO (flatten metadata back to DTO for API compatibility)
            var dto = new ProjectDto
            {
                Id = project.Id,
                TenantId = tenant.Id,
                Source = project.Source,
                Name = project.Name,
                ApplicationName = project.Metadata.ApplicationName,
                RecipientId = project.Metadata.RecipientId,
                RetentionDays = project.RetentionDays,
                ProcessName = project.Metadata.ProcessName,
                ProcessOwner = project.Metadata.ProcessOwner,
                BusinessLineId = project.Metadata.BusinessLineId,
                ProcessVersion = project.Metadata.ProcessVersion,
                ProcessStep = project.Metadata.ProcessStep,
                StatusId = project.Metadata.StatusId,
                DefaultTemplateName = project.DefaultTemplateName,
                CreatedBy = project.CreatedBy,
                CreatedAt = project.CreatedAt,
                Description = project.Description,
                CurrentActiveVersionId = project.CurrentActiveVersionId
            };

            return Result<ProjectDto>.Success(dto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating project with source {Source}", request.Source);
            return Result<ProjectDto>.Failure($"Failed to create project: {ex.Message}");
        }
    }
}
