﻿namespace D2ApiCreator.Application.DTOs;
/// <summary>
/// DTO representing found placeholders in a document
/// </summary>
public class DocumentPlaceholderDto
{
    public List<string> Placeholders { get; set; } = new();
    public int TotalCount { get; set; }
    public string FileName { get; set; } = string.Empty;
}
