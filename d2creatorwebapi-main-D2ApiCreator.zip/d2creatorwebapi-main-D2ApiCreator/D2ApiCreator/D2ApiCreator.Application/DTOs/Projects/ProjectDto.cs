namespace D2ApiCreator.Application.DTOs.Projects;

/// <summary>
/// DTO representing a project
/// </summary>
/// <remarks>
/// Metadata fields (ApplicationName, ProcessName, ProcessOwner, etc.) are stored in a single JSONB column in the database.
/// </remarks>
public class ProjectDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Source { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? ApplicationName { get; set; }
    public string? RecipientId { get; set; }
    public int RetentionDays { get; set; }
    public string? ProcessName { get; set; }
    public string? ProcessOwner { get; set; }
    public string? BusinessLineId { get; set; }
    public string? ProcessVersion { get; set; }
    public string? ProcessStep { get; set; }
    public string? StatusId { get; set; }
    public string? DefaultTemplateName { get; set; }
    public Guid? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? Description { get; set; }
    public Guid? CurrentActiveVersionId { get; set; }
}
