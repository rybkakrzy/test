# D2ApiCreator Quick Restart Script
# Autor: GitHub Copilot
# Data: 2025-11-20

Write-Host "`n╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║         D2ApiCreator - Quick Restart Script                    ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════════════╝`n" -ForegroundColor Cyan

# Krok 1: Zatrzymaj wszystkie procesy dotnet
Write-Host "🛑 Zatrzymywanie wszystkich procesów dotnet..." -ForegroundColor Yellow
$result = taskkill /F /IM dotnet.exe 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Procesy dotnet zostały zatrzymane" -ForegroundColor Green
} else {
    Write-Host "⚠️  Brak procesów dotnet do zatrzymania" -ForegroundColor Yellow
}

# Krok 2: Czekaj na zwolnienie zasobów
Write-Host "`n⏳ Oczekiwanie na zwolnienie portów (3 sekundy)..." -ForegroundColor Yellow
Start-Sleep -Seconds 3

# Krok 3: Sprawdź czy port 5000 jest wolny
Write-Host "`n🔍 Sprawdzanie dostępności portu 5000..." -ForegroundColor Yellow
$portCheck = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
if ($portCheck) {
    Write-Host "❌ Port 5000 jest nadal zajęty przez proces PID: $($portCheck.OwningProcess)" -ForegroundColor Red
    Write-Host "Próba wymuszenia zakończenia procesu..." -ForegroundColor Yellow
    Stop-Process -Id $portCheck.OwningProcess -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
} else {
    Write-Host "✅ Port 5000 jest wolny" -ForegroundColor Green
}

# Krok 4: Przejdź do katalogu projektu
$projectPath = "C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api"
if (Test-Path $projectPath) {
    Write-Host "`n📂 Przechodzenie do katalogu projektu..." -ForegroundColor Yellow
    Set-Location $projectPath
    Write-Host "✅ Katalog: $projectPath" -ForegroundColor Green
} else {
    Write-Host "`n❌ Nie znaleziono katalogu projektu: $projectPath" -ForegroundColor Red
    Write-Host "Sprawdź ścieżkę i uruchom skrypt ponownie." -ForegroundColor Yellow
    exit 1
}

# Krok 5: Uruchom aplikację
Write-Host "`n🚀 Uruchamianie aplikacji D2ApiCreator..." -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`n" -ForegroundColor Cyan

# Uruchomienie aplikacji (w tle)
$job = Start-Job -ScriptBlock {
    Set-Location "C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api"
    dotnet run
}

Write-Host "💡 Aplikacja startuje w tle (Job ID: $($job.Id))..." -ForegroundColor Cyan
Write-Host "⏳ Oczekiwanie 8 sekund na pełne uruchomienie...`n" -ForegroundColor Yellow
Start-Sleep -Seconds 8

# Krok 6: Weryfikacja
Write-Host "🔍 Weryfikacja działania aplikacji..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:5000/health" -Method GET -TimeoutSec 5 -UseBasicParsing
    
    Write-Host "`n╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "║                    ✅ SUKCES!                                   ║" -ForegroundColor Green
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    
    Write-Host "`n📍 Base URL:      http://localhost:5000" -ForegroundColor Cyan
    Write-Host "🏥 Health Status: $($response.Content)" -ForegroundColor White
    Write-Host "📊 Status Code:   $($response.StatusCode)" -ForegroundColor White
    
    Write-Host "`n📋 Dostępne endpointy:" -ForegroundColor Yellow
    Write-Host "   • GET  /health" -ForegroundColor White
    Write-Host "   • GET  /api/v1/examples/{name}" -ForegroundColor White
    Write-Host "   • GET  /api/v1/businesslines" -ForegroundColor White
    Write-Host "   • GET  /api/v1/businesslines/active" -ForegroundColor White
    Write-Host "   • GET  /api/v1/recipients" -ForegroundColor White
    Write-Host "   • POST /api/v1/documents/extract-placeholders" -ForegroundColor White
    
    Write-Host "`n💡 Aplikacja działa w tle (Job ID: $($job.Id))" -ForegroundColor Cyan
    Write-Host "🛑 Aby zatrzymać: taskkill /F /IM dotnet.exe" -ForegroundColor Yellow
    Write-Host "`n" -ForegroundColor White
    
} catch {
    Write-Host "`n╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Red
    Write-Host "║                    ❌ BŁĄD!                                     ║" -ForegroundColor Red
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Red
    
    Write-Host "`n❌ Aplikacja nie odpowiada na endpoint /health" -ForegroundColor Red
    Write-Host "Szczegóły błędu: $_" -ForegroundColor Yellow
    
    Write-Host "`n📝 Sprawdź logi w:" -ForegroundColor Yellow
    Write-Host "   C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api\logs\log-$(Get-Date -Format 'yyyyMMdd').txt" -ForegroundColor White
    
    Write-Host "`n🔧 Możliwe rozwiązania:" -ForegroundColor Cyan
    Write-Host "   1. Sprawdź logi aplikacji" -ForegroundColor White
    Write-Host "   2. Upewnij się, że PostgreSQL działa (jeśli wymagane)" -ForegroundColor White
    Write-Host "   3. Uruchom: dotnet build (w katalogu projektu)" -ForegroundColor White
    Write-Host "`n" -ForegroundColor White
}

# Koniec skryptu
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "Skrypt zakończony. Aplikacja działa w tle." -ForegroundColor Green
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`n" -ForegroundColor Cyan

