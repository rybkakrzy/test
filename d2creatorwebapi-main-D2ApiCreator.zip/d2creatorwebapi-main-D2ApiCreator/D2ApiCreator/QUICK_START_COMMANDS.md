# D2ApiCreator - Szybkie Komendy Uruchomieniowe

## 🚀 SZYBKI RESTART APLIKACJI (Wszystko w jednym)

```powershell
# Zatrzymaj wszystkie dotnet, poczekaj, uruchom aplikację
taskkill /F /IM dotnet.exe 2>$null; Start-Sleep -Seconds 3; cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api; dotnet run
```

### Weryfikacja po uruchomieniu (w nowym terminalu):
```powershell
Start-Sleep -Seconds 8; Invoke-WebRequest -Uri "http://localhost:5000/health" -UseBasicParsing
```

---

## Zatrzymanie Aplikacji

### Opcja 1: Zatrzymaj wszystkie procesy dotnet
```powershell
taskkill /F /IM dotnet.exe
```

### Opcja 2: Zatrzymaj proces na konkretnym porcie (5000)
```powershell
$connection = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
if ($connection) {
    Stop-Process -Id $connection.OwningProcess -Force
}
```

## Uruchomienie Aplikacji

### 🎯 NAJŁATWIEJSZY SPOSÓB - Użyj gotowych skryptów

#### Restart aplikacji (zatrzymaj + uruchom):
```powershell
.\restart-app.ps1
```

#### Tylko zatrzymanie aplikacji:
```powershell
.\stop-app.ps1
```

---

### Standardowe uruchomienie (Development)
```powershell
cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api
dotnet run
```

### Uruchomienie z rebuild
```powershell
cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator
dotnet build
cd D2ApiCreator.Api
dotnet run
```

### Uruchomienie w Production mode
```powershell
$env:ASPNETCORE_ENVIRONMENT="Production"
dotnet run --project D2ApiCreator.Api
```

## Testowanie Endpointów

### Health Check
```powershell
Invoke-WebRequest -Uri "http://localhost:5000/health" -UseBasicParsing
```

### Przykładowy endpoint z wersjonowaniem
```powershell
Invoke-WebRequest -Uri "http://localhost:5000/api/v1/examples/TestUser" -UseBasicParsing
```

### Business Lines
```powershell
Invoke-WebRequest -Uri "http://localhost:5000/api/v1/businesslines" -UseBasicParsing
```

## Szybkie Testy Wszystkich Endpointów

```powershell
# Test all endpoints
$endpoints = @(
    "http://localhost:5000/health",
    "http://localhost:5000/api/v1/examples/Test",
    "http://localhost:5000/api/v1/businesslines",
    "http://localhost:5000/api/v1/recipients"
)

foreach ($endpoint in $endpoints) {
    try {
        $response = Invoke-WebRequest -Uri $endpoint -UseBasicParsing -TimeoutSec 5
        Write-Host "✅ $endpoint - Status: $($response.StatusCode)" -ForegroundColor Green
    } catch {
        Write-Host "❌ $endpoint - Error: $_" -ForegroundColor Red
    }
}
```

## Sprawdzenie Aktywnych Portów

```powershell
# Zobacz wszystkie aktywne porty
Get-NetTCPConnection | Where-Object {$_.State -eq "Listen"} | Select-Object LocalAddress, LocalPort, OwningProcess | Sort-Object LocalPort

# Sprawdź tylko port 5000
Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
```

## Rozwiązywanie Problemów

### Problem: Port zajęty (ADDRESS ALREADY IN USE)
```powershell
# SZYBKIE ROZWIĄZANIE - Zabij wszystkie dotnet i uruchom ponownie
taskkill /F /IM dotnet.exe
Start-Sleep -Seconds 3
cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api
dotnet run
```

### Problem: Znajdź proces na konkretnym porcie
```powershell
# Znajdź i zabij proces na porcie 5000
$port = 5000
$connection = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
if ($connection) {
    $processId = $connection.OwningProcess
    Write-Host "Killing process $processId on port $port"
    Stop-Process -Id $processId -Force
    Start-Sleep -Seconds 2
}
```

### Problem: API Versioning Error
```
InvalidOperationException: The constraint reference 'apiVersion' could not be resolved
```
**Rozwiązanie**: Problem został już naprawiony w projekcie. Jeśli nadal występuje:
1. Sprawdź czy pakiet `Asp.Versioning.Mvc.ApiExplorer` jest zainstalowany
2. Zobacz dokumentację: `API_VERSIONING_FIX.md`

### Problem: Błędy kompilacji
```powershell
# Clean i rebuild
cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator
dotnet clean
dotnet restore
dotnet build
```

## URL Aplikacji

- **Base URL**: http://localhost:5000
- **HTTPS URL**: http://localhost:5001 (jeśli skonfigurowane)
- **Swagger**: http://localhost:5000/swagger (tylko Development)
- **Health Check**: http://localhost:5000/health

## Struktura Endpointów API

Wszystkie endpointy biznesowe używają wersjonowania:

```
/api/v1/[controller]/[action]
```

Przykłady:
- `/api/v1/examples/{name}`
- `/api/v1/businesslines`
- `/api/v1/businesslines/active`
- `/api/v1/recipients`
- `/api/v1/documents/extract-placeholders`

## Logi Aplikacji

Logi są zapisywane w:
```
C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api\logs\
```

Plik logu: `log-YYYYMMDD.txt`

### Podgląd logów
```powershell
Get-Content "C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api\logs\log-$(Get-Date -Format 'yyyyMMdd').txt" -Tail 50
```

