# ⚙️ Konfiguracja Projektu - Quick Setup

## 🚀 Dla Nowych Developerów (5 minut)

### Krok 1: Sklonuj repozytorium
```powershell
git clone https://your-repo-url/D2ApiCreator.git
cd D2ApiCreator
```

### Krok 2: Uruchom bazę danych
```powershell
docker-compose up -d
```
✅ PostgreSQL będzie dostępny na `localhost:5432`  
✅ pgAdmin na `http://localhost:5050`

### Krok 3: Skonfiguruj User Secrets
```powershell
cd D2ApiCreator.Api

# Inicjalizacja (jeśli jeszcze nie ma)
dotnet user-secrets init

# Ustaw connection string
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=postgres"
```

### Krok 4: Uruchom migracje (gdy będą dostępne)
```powershell
dotnet ef database update --project ..\D2ApiCreator.Infrastructure
```

### Krok 5: Uruchom aplikację
```powershell
dotnet run
```

Aplikacja dostępna na: `https://localhost:5001/swagger`

---

## 📋 Konfiguracje Uruchomieniowe

### Visual Studio / Rider
Masz teraz 2 profile do wyboru:

#### 1. **D2ApiCreator (Kestrel)** - ZALECANE
- Uruchamia na Kestrel (produkcyjny serwer)
- URLs: `https://localhost:5001` i `http://localhost:5000`
- Automatycznie otwiera Swagger

#### 2. **D2ApiCreator (IIS Express)**
- Uruchamia na IIS Express
- URLs: `https://localhost:5001` i `http://localhost:5000`

### Wybór profilu w IDE

**JetBrains Rider:**
1. Kliknij dropdown obok przycisku Run (góra)
2. Wybierz `D2ApiCreator (Kestrel)`
3. Kliknij Run ▶️

**Visual Studio:**
1. Kliknij dropdown obok przycisku Start
2. Wybierz `D2ApiCreator (Kestrel)`
3. Kliknij Start

---

## 🔐 Zarządzanie Secretami

### Development (Lokalnie)

**Sposób 1: User Secrets (ZALECANE)**
```powershell
cd D2ApiCreator.Api
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=twoje_haslo"
```

**Sposób 2: appsettings.Development.json**
- Plik już zawiera domyślne ustawienia dla Docker
- Możesz edytować, ale **NIE commituj z hasłami!**

### Production

**Nigdy nie commituj haseł!** Użyj:
- Azure: App Service Configuration / Key Vault
- AWS: Secrets Manager / Parameter Store
- Docker: Environment variables z .env
- Kubernetes: Secrets

Szczegóły w: `SECRETS_MANAGEMENT.md`

---

## 🔍 Weryfikacja Konfiguracji

### Sprawdź User Secrets
```powershell
cd D2ApiCreator.Api
dotnet user-secrets list
```

Powinno pokazać:
```
ConnectionStrings:DefaultConnection = Host=localhost;...
```

### Sprawdź połączenie z bazą
1. Otwórz pgAdmin: `http://localhost:5050`
   - Email: `admin@d2creator.com`
   - Hasło: `admin`

2. Dodaj serwer:
   - Name: `D2Creator Local`
   - Host: `postgres` (w dockerze) lub `localhost` (z zewnątrz)
   - Port: `5432`
   - Username: `postgres`
   - Password: `postgres`

### Test API
Po uruchomieniu aplikacji:
```powershell
# Health check
curl https://localhost:5001/api/health

# Swagger UI
start https://localhost:5001/swagger
```

---

## 🐛 Troubleshooting

### Problem: "No connection string configured"

**Rozwiązanie:**
```powershell
cd D2ApiCreator.Api
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=postgres"
```

### Problem: Nie można połączyć z PostgreSQL

**Sprawdź czy kontener działa:**
```powershell
docker ps
```

**Restart kontenera:**
```powershell
docker-compose down
docker-compose up -d
```

**Sprawdź logi:**
```powershell
docker-compose logs postgres
```

### Problem: Port 5432 zajęty

**Zmień port w docker-compose.yml:**
```yaml
ports:
  - "15432:5432"  # Zewnętrzny port 15432
```

**I zaktualizuj User Secrets:**
```powershell
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=15432;Database=D2CreatorDb;Username=postgres;Password=postgres"
```

### Problem: User Secrets nie działa

**Sprawdź środowisko:**
```powershell
# Musi być Development
$env:ASPNETCORE_ENVIRONMENT
```

**Jeśli nie jest Development:**
```powershell
$env:ASPNETCORE_ENVIRONMENT = "Development"
dotnet run
```

---

## 📝 Pliki Konfiguracyjne - Przegląd

| Plik | Commitować? | Przeznaczenie |
|------|-------------|---------------|
| `appsettings.json` | ✅ TAK | Podstawowa konfiguracja (BEZ secretów) |
| `appsettings.Development.json` | ⚠️ OPCJONALNIE | Dev settings (zawiera hasło do Docker) |
| `appsettings.Production.json` | ✅ TAK | Production template (puste secrety) |
| `launchSettings.json` | ✅ TAK | Profile uruchomieniowe IDE |
| **User Secrets** | ❌ NIE | Lokalne sekrety (poza repo) |
| `.env` | ❌ NIE | Environment variables (production) |
| `.env.example` | ✅ TAK | Template dla .env |

---

## 🎯 Następne Kroki

Po skonfigurowaniu podstaw:

1. **Stwórz pierwszą migrację** (gdy dodasz encje)
   ```powershell
   dotnet ef migrations add InitialCreate --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
   dotnet ef database update --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
   ```

2. **Uruchom testy**
   ```powershell
   dotnet test
   ```

3. **Dodaj swoje features** w `D2ApiCreator.Application/Features/`

4. **Przeczytaj dokumentację:**
   - `README.md` - Architektura
   - `QUICKSTART.md` - Szczegółowe instrukcje
   - `BEST_PRACTICES.md` - Coding standards
   - `SECRETS_MANAGEMENT.md` - Zarządzanie secretami

---

## 📞 Potrzebujesz pomocy?

- Sprawdź dokumentację w `docs/`
- Zobacz przykłady w `D2ApiCreator.Application/Features/Examples/`
- Przejrzyj testy w `D2ApiCreator.Tests.*`

**Happy coding! 🚀**

