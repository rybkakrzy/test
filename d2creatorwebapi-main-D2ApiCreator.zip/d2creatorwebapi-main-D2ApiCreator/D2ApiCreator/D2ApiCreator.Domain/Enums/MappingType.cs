
namespace D2ApiCreator.Domain.Enums;

public enum MappingType
{
    Static,
    JsonPath,
    Expression,
    Lookup
}

