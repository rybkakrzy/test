

using System.Text.Json;

namespace D2ApiCreator.Domain.Entities;

using Common.BaseTypes;
using Enums;

public class ProjectVersion : AggregateRoot<Guid>
{
    private readonly List<FileEntity> _files = new();
    private readonly List<Mapping> _mappings = new();
    private readonly List<Approval> _approvals = new();

    protected ProjectVersion() { }

    public ProjectVersion(Guid id, Guid projectId, int major = 1, int minor = 0, Guid? createdBy = null)
        : base(id)
    {
        ProjectId = projectId;
        Major = major;
        Minor = minor;
        VersionTag = $"{major}.{minor}";
        IsActive = false;
        Status = ProjectStatus.Draft;
        CreatedBy = createdBy;
        CreatedAt = DateTime.UtcNow;
        StepData = JsonDocument.Parse("{}");
    }

    public Guid ProjectId { get; private set; }
    public int Major { get; private set; }
    public int Minor { get; private set; }
    public string VersionTag { get; private set; } = null!;
    public bool IsActive { get; private set; }
    public ProjectStatus Status { get; private set; }
    public Guid? CreatedBy { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }
    public JsonDocument? StepData { get; private set; }
    public string? Notes { get; private set; }

    // Navigation properties
    public Project Project { get; private set; } = null!;
    public User? Creator { get; private set; }
    public IReadOnlyCollection<FileEntity> Files => _files.AsReadOnly();
    public IReadOnlyCollection<Mapping> Mappings => _mappings.AsReadOnly();
    public IReadOnlyCollection<Approval> Approvals => _approvals.AsReadOnly();

    public void Activate()
    {
        IsActive = true;
        if (Status == ProjectStatus.Draft || Status == ProjectStatus.Approved)
        {
            Status = ProjectStatus.Active;
        }
        UpdatedAt = DateTime.UtcNow;
    }

    public void Deactivate()
    {
        IsActive = false;
        Status = ProjectStatus.Inactive;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateStatus(ProjectStatus status)
    {
        Status = status;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateStepData(JsonDocument stepData)
    {
        StepData = stepData;
        UpdatedAt = DateTime.UtcNow;
    }

    public void UpdateNotes(string? notes)
    {
        Notes = notes;
        UpdatedAt = DateTime.UtcNow;
    }
}

