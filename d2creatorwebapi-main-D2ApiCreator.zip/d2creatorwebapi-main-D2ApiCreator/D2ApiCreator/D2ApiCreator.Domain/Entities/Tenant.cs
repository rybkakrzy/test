using System.Text.Json;

namespace D2ApiCreator.Domain.Entities;

using Common.BaseTypes;

public class Tenant : AggregateRoot<Guid>
{
    private readonly List<User> _users = new();
    private readonly List<Project> _projects = new();

    protected Tenant() { }

    public Tenant(Guid id, string name)
        : base(id)
    {
        Name = name;
        IsActive = true;
        CreatedAt = DateTime.UtcNow;
    }

    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }
    public bool IsActive { get; private set; }
    public JsonDocument? Metadata { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    // Navigation properties
    public IReadOnlyCollection<User> Users => _users.AsReadOnly();
    public IReadOnlyCollection<Project> Projects => _projects.AsReadOnly();

    public void UpdateMetadata(JsonDocument? metadata)
    {
        Metadata = metadata;
        UpdatedAt = DateTime.UtcNow;
    }
    
    public void UpdateDescription(string? description)
    {
        Description = description;
        UpdatedAt = DateTime.UtcNow;
    }
    
    public void Activate()
    {
        IsActive = true;
    }
    
    public void Deactivate()
    {
        IsActive = false;
    }
}

