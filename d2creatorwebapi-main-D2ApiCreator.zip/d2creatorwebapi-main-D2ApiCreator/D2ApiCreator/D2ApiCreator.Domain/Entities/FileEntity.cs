namespace D2ApiCreator.Domain.Entities;

using Common.BaseTypes;

public class FileEntity : AggregateRoot<Guid>
{
    private readonly List<ParseResult> _parseResults = new();

    protected FileEntity() { }

    public FileEntity(Guid id, Guid projectVersionId, string filename, byte[] content, string? contentType = null, long? size = null, string? sha256 = null)
        : base(id)
    {
        ProjectVersionId = projectVersionId;
        Filename = filename;
        Content = content;
        ContentType = contentType;
        Size = size ?? content?.Length;
        Sha256 = sha256;
        CreatedAt = DateTime.UtcNow;
    }

    public Guid ProjectVersionId { get; private set; }
    public string Filename { get; private set; } = null!;
    public byte[]? Content { get; private set; }
    public string? StorageRef { get; private set; }
    public string? ContentType { get; private set; }
    public long? Size { get; private set; }
    public string? Sha256 { get; private set; }
    public DateTime CreatedAt { get; private set; }

    // Navigation properties
    public ProjectVersion ProjectVersion { get; private set; } = null!;
    public IReadOnlyCollection<ParseResult> ParseResults => _parseResults.AsReadOnly();

    public void MigrateToExternalStorage(string storageRef)
    {
        StorageRef = storageRef;
        Content = null; // Clear DB storage after migration
    }
}

