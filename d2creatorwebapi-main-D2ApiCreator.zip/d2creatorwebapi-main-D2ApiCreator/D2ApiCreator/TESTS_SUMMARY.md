# Testy dla Ekstrakcji Znaczników z Dokumentów DOCX

## Podsumowanie

Utworzono **57 testów** dla funkcjonalności ekstrakcji znaczników z plików DOCX:
- **24 testy jednostkowe** dla `DocumentPlaceholderService`
- **5 testów jednostkowych** dla `ExtractPlaceholdersQueryHandler`
- **12 testów jednostkowych** dla `ExtractPlaceholdersQueryValidator`
- **16 testów integracyjnych** dla `DocumentsController`

## Testy Jednostkowe

### DocumentPlaceholderService (24 testy)

#### Podstawowe Funkcjonalności
1. ✅ `ExtractPlaceholdersFromDocxAsync_WithSinglePlaceholder_ShouldReturnOnePlaceholder`
2. ✅ `ExtractPlaceholdersFromDocxAsync_WithMultiplePlaceholders_ShouldReturnAllPlaceholders`
3. ✅ `ExtractPlaceholdersFromDocxAsync_WithDuplicatePlaceholders_ShouldReturnUniqueOnly`
4. ✅ `ExtractPlaceholdersFromDocxAsync_WithNoPlaceholders_ShouldReturnEmptyList`
5. ✅ `ExtractPlaceholdersFromDocxAsync_WithEmptyDocument_ShouldReturnEmptyList`

#### Obsługa Różnych Lokalizacji w Dokumencie
6. ✅ `ExtractPlaceholdersFromDocxAsync_WithPlaceholdersInMultipleParagraphs_ShouldFindAll`
7. ✅ `ExtractPlaceholdersFromDocxAsync_WithPlaceholdersInHeader_ShouldFindThem`
8. ✅ `ExtractPlaceholdersFromDocxAsync_WithPlaceholdersInFooter_ShouldFindThem`
9. ✅ `ExtractPlaceholdersFromDocxAsync_WithPlaceholdersEverywhere_ShouldFindAll`

#### Formatowanie Znaczników
10. ✅ `ExtractPlaceholdersFromDocxAsync_WithUnderscoresInPlaceholder_ShouldExtractCorrectly`
11. ✅ `ExtractPlaceholdersFromDocxAsync_WithNumbersInPlaceholder_ShouldExtractCorrectly`
12. ✅ `ExtractPlaceholdersFromDocxAsync_WithHyphensInPlaceholder_ShouldExtract`
13. ✅ `ExtractPlaceholdersFromDocxAsync_WithDotInPlaceholder_ShouldExtract`
14. ✅ `ExtractPlaceholdersFromDocxAsync_WithWhitespaceInPlaceholder_ShouldExtract`
15. ✅ `ExtractPlaceholdersFromDocxAsync_WithMixedCase_ShouldPreserveCase`
16. ✅ `ExtractPlaceholdersFromDocxAsync_WithLongPlaceholderName_ShouldExtract`

#### Przypadki Specjalne
17. ✅ `ExtractPlaceholdersFromDocxAsync_WithSpecialExample_ShouldExtractCorrectly` (<%ala_nazwa%>, <%kuta_lubi_cipki%>)
18. ✅ `ExtractPlaceholdersFromDocxAsync_WithIncompletePlaceholder_ShouldNotExtract`
19. ✅ `ExtractPlaceholdersFromDocxAsync_WithNestedBrackets_ShouldExtractOuterOnly`
20. ✅ `ExtractPlaceholdersFromDocxAsync_WithAdjacentPlaceholders_ShouldExtractBoth`

#### Sortowanie i Porządek
21. ✅ `ExtractPlaceholdersFromDocxAsync_ShouldReturnSortedList`

#### Logowanie i Obsługa Błędów
22. ✅ `ExtractPlaceholdersFromDocxAsync_ShouldLogInformation`
23. ✅ `ExtractPlaceholdersFromDocxAsync_WithInvalidStream_ShouldThrowAndLog`

#### Rozszerzenia
24. ✅ `ExtractPlaceholdersFromDocxAsync_WithDotInPlaceholder_ShouldExtract`

### ExtractPlaceholdersQueryHandler (5 testów)

1. ✅ `Handle_WithValidQuery_ShouldReturnDto`
2. ✅ `Handle_ShouldCallServiceWithCorrectParameters`
3. ✅ `Handle_WithEmptyPlaceholders_ShouldReturnEmptyDto`
4. ✅ `Handle_ShouldLogInformation`
5. ✅ `Handle_WithMultiplePlaceholders_ShouldReturnCorrectCount`

### ExtractPlaceholdersQueryValidator (12 testów)

#### Walidacja Nazwy Pliku
1. ✅ `Validate_WithValidDocxFile_ShouldPass`
2. ✅ `Validate_WithEmptyFileName_ShouldFail`
3. ✅ `Validate_WithNullFileName_ShouldFail`
4. ✅ `Validate_WithNonDocxExtension_ShouldFail`
5. ✅ `Validate_WithDocExtension_ShouldFail`
6. ✅ `Validate_WithTxtExtension_ShouldFail`
7. ✅ `Validate_WithUppercaseDocxExtension_ShouldPass`
8. ✅ `Validate_WithMixedCaseDocxExtension_ShouldPass`
9. ✅ `Validate_WithFileNameWithPath_ShouldValidateExtensionOnly`

#### Walidacja Strumienia
10. ✅ `Validate_WithNullFileStream_ShouldFail`
11. ✅ `Validate_WithEmptyFileStream_ShouldFail`

#### Wielokrotne Błędy
12. ✅ `Validate_WithMultipleErrors_ShouldReturnAllErrors`

## Testy Integracyjne

### DocumentsController (16 testów)

#### Podstawowe Operacje
1. ✅ `ExtractPlaceholders_WithValidDocx_ShouldReturnOk`
2. ✅ `ExtractPlaceholders_WithValidDocx_ShouldReturnCorrectPlaceholders`
3. ✅ `ExtractPlaceholders_WithEmptyFile_ShouldReturnBadRequest`
4. ✅ `ExtractPlaceholders_WithNonDocxFile_ShouldReturnBadRequest`
5. ✅ `ExtractPlaceholders_WithPdfFile_ShouldReturnBadRequest`

#### Różne Scenariusze
6. ✅ `ExtractPlaceholders_WithMultiplePlaceholders_ShouldReturnAll`
7. ✅ `ExtractPlaceholders_WithNoPlaceholders_ShouldReturnEmptyList`
8. ✅ `ExtractPlaceholders_WithHeaderAndFooter_ShouldFindAll`
9. ✅ `ExtractPlaceholders_WithDuplicates_ShouldReturnUnique`
10. ✅ `ExtractPlaceholders_WithComplexPlaceholders_ShouldExtractCorrectly`
11. ✅ `ExtractPlaceholders_ResponseShouldBeSorted`
12. ✅ `ExtractPlaceholders_WithMultipleParagraphs_ShouldFindAll`

#### HTTP i Metadane
13. ✅ `ExtractPlaceholders_WithLongFileName_ShouldPreserveFileName`
14. ✅ `ExtractPlaceholders_ContentTypeShouldBeJson`
15. ✅ `ExtractPlaceholders_WithUppercaseExtension_ShouldAccept`
16. ✅ `ExtractPlaceholders_WithSpecialCharactersInPlaceholder_ShouldExtract`

## Klasy Pomocnicze

### DocxTestHelper
Klasa pomocnicza do generowania dokumentów DOCX dla testów:
- `CreateDocxWithText(string text)` - Tworzy dokument z jednym paragrafem
- `CreateDocxWithParagraphs(params string[] paragraphs)` - Tworzy dokument z wieloma paragrafami
- `CreateDocxWithHeaderAndFooter(...)` - Tworzy dokument z nagłówkiem i stopką
- `CreateEmptyDocx()` - Tworzy pusty dokument
- `CreateDocxWithFragmentedText(...)` - Tworzy dokument z pofragmentowanym tekstem

## Pokrycie Testami

### Funkcjonalności Testowane
- ✅ Ekstrakcja pojedynczego znacznika
- ✅ Ekstrakcja wielu znaczników
- ✅ Usuwanie duplikatów
- ✅ Sortowanie wyników
- ✅ Obsługa pustych dokumentów
- ✅ Przeszukiwanie nagłówków i stopek
- ✅ Różne formaty nazw znaczników (underscore, hyphen, dot, spacje)
- ✅ Zachowanie wielkości liter
- ✅ Walidacja formatu pliku
- ✅ Walidacja rozszerzenia pliku
- ✅ Obsługa błędów
- ✅ Logowanie operacji
- ✅ Integracja z HTTP API
- ✅ Serializacja JSON
- ✅ Obsługa Content-Type

### Przypadki Brzegowe
- ✅ Puste pliki
- ✅ Nieprawidłowe pliki
- ✅ Niekompletne znaczniki
- ✅ Znaczniki obok siebie
- ✅ Bardzo długie nazwy znaczników
- ✅ Znaki specjalne w znacznikach
- ✅ Różna wielkość liter w rozszerzeniach plików

## Uruchamianie Testów

### Wszystkie Testy Jednostkowe
```bash
dotnet test D2ApiCreator.Tests.Unit
```

### Konkretna Klasa Testów
```bash
dotnet test D2ApiCreator.Tests.Unit --filter "FullyQualifiedName~DocumentPlaceholderServiceTests"
```

### Konkretny Test
```bash
dotnet test D2ApiCreator.Tests.Unit --filter "FullyQualifiedName~WithSinglePlaceholder"
```

### Testy z Pokryciem Kodu
```bash
dotnet test D2ApiCreator.Tests.Unit /p:CollectCoverage=true /p:CoverletOutputFormat=cobertura
```

## Metryki

- **Całkowita liczba testów**: 57
- **Testy jednostkowe**: 41 (72%)
- **Testy integracyjne**: 16 (28%)
- **Klasy testowe**: 4
- **Klasy pomocnicze**: 1

## Wzorce Testowe Użyte

1. **AAA Pattern** (Arrange-Act-Assert) - we wszystkich testach
2. **Test Fixtures** - `CustomWebApplicationFactory` dla testów integracyjnych
3. **Test Helpers** - `DocxTestHelper` do generowania dokumentów testowych
4. **Mocking** - NSubstitute dla zależności
5. **Fluent Assertions** - dla czytelnych asercji
6. **Parameterized Tests** - poprzez różne scenariusze w osobnych metodach

## Frameworki i Biblioteki

- **xUnit** - framework testowy
- **FluentAssertions** - asercje
- **NSubstitute** - mockowanie
- **DocumentFormat.OpenXml** - generowanie dokumentów DOCX
- **Microsoft.AspNetCore.Mvc.Testing** - testy integracyjne

## Kolejne Kroki

Możliwe rozszerzenia testów:
1. Testy wydajnościowe dla dużych dokumentów
2. Testy dla dokumentów z tysiącami znaczników
3. Testy dla uszkodzonych plików DOCX
4. Testy współbieżności
5. Testy timeout dla długich operacji

