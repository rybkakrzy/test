# Architecture Decision Records (ADR)

## ADR-001: Clean Architecture & DDD

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Projekt wymaga profesjonalnej, skalowalnej i łatwej w utrzymaniu architektury.

**Decision:**
Implementujemy Clean Architecture z Domain-Driven Design:
- **Domain Layer**: Logika biznesowa, agregaty, encje, value objects
- **Application Layer**: Use cases, CQRS, walidacja
- **Infrastructure Layer**: Implementacje (EF Core, zewnętrzne serwisy)
- **Presentation Layer**: REST API kontrolery

**Consequences:**
- ✅ Separacja odpowiedzialności
- ✅ Testowalne warstwy
- ✅ Niezależność od frameworków
- ⚠️ Wyższa złożoność dla małych projektów

---

## ADR-002: CQRS Pattern z MediatR

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Potrzeba oddzielenia operacji zapisu od odczytu.

**Decision:**
Używamy CQRS z biblioteką MediatR:
- Commands dla operacji zapisu
- Queries dla operacji odczytu
- Pipeline behaviors dla cross-cutting concerns

**Consequences:**
- ✅ Jasne rozdzielenie odpowiedzialności
- ✅ Łatwiejsze testowanie
- ✅ Performance optimization możliwy osobno dla read/write
- ⚠️ Więcej boilerplate code

---

## ADR-003: PostgreSQL jako baza danych

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Wybór relacyjnej bazy danych.

**Decision:**
PostgreSQL 16+ jako główna baza danych:
- Darmowa, open-source
- Zaawansowane funkcje (JSON, full-text search)
- Dobra wydajność
- Wsparcie Entity Framework Core

**Consequences:**
- ✅ Brak kosztów licencji
- ✅ Duża społeczność
- ✅ Zaawansowane funkcje SQL
- ⚠️ Wymaga dodatkowej konfiguracji serwera

---

## ADR-004: Entity Framework Core

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Wybór ORM dla dostępu do danych.

**Decision:**
Entity Framework Core 8:
- Code-first approach
- Migrations dla wersjonowania schematu
- Fluent API dla konfiguracji

**Consequences:**
- ✅ Produktywność programistów
- ✅ Łatwe migracje
- ✅ LINQ queries
- ⚠️ Performance overhead vs raw SQL

---

## ADR-005: FluentValidation

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Walidacja danych wejściowych.

**Decision:**
FluentValidation jako główne narzędzie walidacji:
- Zintegrowane z MediatR pipeline
- Separacja logiki walidacji

**Consequences:**
- ✅ Czytelny, fluent API
- ✅ Łatwe testowanie
- ✅ Reużywalność reguł
- ✅ Dobre komunikaty błędów

---

## ADR-006: Serilog dla logowania

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Profesjonalne logowanie aplikacji.

**Decision:**
Serilog z structured logging:
- Console sink dla development
- File sink dla production
- Możliwość rozszerzenia o Seq, ElasticSearch

**Consequences:**
- ✅ Structured logging
- ✅ Łatwa konfiguracja
- ✅ Wiele sinks
- ✅ Dobra wydajność

---

## ADR-007: Repository Pattern

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Abstrakcja dostępu do danych.

**Decision:**
Implementacja Repository Pattern:
- Generic repository dla podstawowych operacji
- Specjalizowane repozytoria dla złożonych queries

**Consequences:**
- ✅ Abstrakcja dostępu do danych
- ✅ Łatwiejsze testowanie
- ✅ Możliwość zmiany persistence
- ⚠️ Dodatkowa warstwa abstrakcji

---

## ADR-008: Unit of Work Pattern

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Zarządzanie transakcjami.

**Decision:**
DbContext jako Unit of Work:
- Centralne zarządzanie transakcjami
- SaveChanges jako commit

**Consequences:**
- ✅ ACID transactions
- ✅ Spójność danych
- ✅ Łatwe zarządzanie transakcjami

---

## ADR-009: Global Exception Handling

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Obsługa błędów w aplikacji.

**Decision:**
Custom middleware dla global exception handling:
- Spójne formatowanie błędów
- Logowanie wyjątków
- Ukrywanie stack traces w production

**Consequences:**
- ✅ Spójne API responses
- ✅ Centralne logowanie
- ✅ Bezpieczniejsze w production
- ✅ Lepsze UX

---

## ADR-010: Testcontainers dla testów integracyjnych

**Date:** 2025-01-19

**Status:** Accepted

**Context:**
Testy integracyjne z rzeczywistą bazą danych.

**Decision:**
Testcontainers.PostgreSql:
- Docker containers w testach
- Izolowane środowisko testowe
- Rzeczywista baza danych

**Consequences:**
- ✅ Testy bliższe produkcji
- ✅ Izolacja testów
- ⚠️ Wymaga Docker
- ⚠️ Wolniejsze niż in-memory

