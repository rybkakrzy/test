﻿param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("init", "update", "version", "reset", "backup")]
    [string]$Action = "update",
    [Parameter(Mandatory=$false)]
    [string]$BackupPath = ".\backups"
)

$ScriptsPath = "c:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Infrastructure\Database"
$InitScript = "$ScriptsPath\init-database.sql"
$ContainerName = "d2creator-postgres"
$DbName = "D2CreatorDb"
$DbUser = "postgres"

function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White")
    Write-Host $Message -ForegroundColor $Color
}

function Test-Container {
    $containerRunning = podman ps --filter "name=$ContainerName" --format "{{.Names}}"
    if ($containerRunning -ne $ContainerName) {
        Write-ColorOutput "ERROR: PostgreSQL container not running!" "Red"
        Write-ColorOutput "Start it with: podman start $ContainerName" "Yellow"
        exit 1
    }
}

function Get-DatabaseVersion {
    Write-ColorOutput "`n=== Current Database Version ===" "Cyan"
    $query = "SELECT id_version, description, applied_at FROM database_version ORDER BY id_version;"
    podman exec $ContainerName psql -U $DbUser -d $DbName -c $query
}

function Initialize-Database {
    Write-ColorOutput "`n=== Initializing Database ===" "Cyan"
    Write-ColorOutput "Executing init-database.sql..." "Yellow"
    Get-Content $InitScript | podman exec -i $ContainerName psql -U $DbUser -d $DbName
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "Initialization completed successfully" "Green"
    } else {
        Write-ColorOutput "Error during initialization" "Red"
        exit 1
    }
}

function Update-Database {
    Write-ColorOutput "`n=== Updating Database ===" "Cyan"
    Write-ColorOutput "Executing init-database.sql..." "Yellow"
    
    Get-Content $InitScript | podman exec -i $ContainerName psql -U $DbUser -d $DbName
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "Script executed successfully" "Green"
        Get-DatabaseVersion
    } else {
        Write-ColorOutput "Error during script execution" "Red"
        exit 1
    }
}

function Reset-Database {
    Write-ColorOutput "`n=== DATABASE RESET ===" "Red"
    Write-ColorOutput "WARNING: This will delete all data!" "Red"
    Write-ColorOutput "Cleaning database..." "Yellow"
    
    $dropQuery = "DROP SCHEMA public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO postgres; GRANT ALL ON SCHEMA public TO public;"
    podman exec $ContainerName psql -U $DbUser -d $DbName -c $dropQuery
    
    Write-ColorOutput "Database cleaned" "Green"
    Write-ColorOutput "Running initialization..." "Yellow"
    Initialize-Database
}

function Backup-Database {
    Write-ColorOutput "`n=== Creating Database Backup ===" "Cyan"
    
    if (-not (Test-Path $BackupPath)) {
        New-Item -ItemType Directory -Path $BackupPath | Out-Null
    }
    
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupFile = "$BackupPath\D2CreatorDb_$timestamp.sql"
    
    Write-ColorOutput "Creating backup: $backupFile..." "Yellow"
    podman exec $ContainerName pg_dump -U $DbUser -d $DbName > $backupFile
    
    if ($LASTEXITCODE -eq 0) {
        Write-ColorOutput "Backup created successfully" "Green"
        Write-ColorOutput "Location: $backupFile" "White"
    } else {
        Write-ColorOutput "Error creating backup" "Red"
    }
}

Write-ColorOutput "`n========================================" "Cyan"
Write-ColorOutput "D2Creator Database Management" "Cyan"
Write-ColorOutput "========================================`n" "Cyan"

Test-Container

switch ($Action) {
    "init" { Initialize-Database }
    "update" { Update-Database }
    "version" { Get-DatabaseVersion }
    "reset" { Reset-Database }
    "backup" { Backup-Database }
}

Write-ColorOutput "`n========================================" "Cyan"
Write-ColorOutput "Operation completed" "Cyan"
Write-ColorOutput "========================================`n" "Cyan"