# Naprawa problemu z API Versioning

## Problem
```
InvalidOperationException: The constraint reference 'apiVersion' could not be resolved to a type. 
Register the constraint type with 'Microsoft.AspNetCore.Routing.RouteOptions.ConstraintMap'.
```

## Przyczyna
Kontrolery używały constraint `{version:apiVersion}` w routingu, ale brakło konfiguracji API Versioning w `Program.cs`.

## Rozwiązanie

### 1. Dodano pakiet NuGet
```xml
<PackageReference Include="Asp.Versioning.Mvc.ApiExplorer" Version="8.1.0" />
```

### 2. Zaktualizowano Program.cs
Dodano konfigurację API Versioning przed rejestracją kontrolerów:

```csharp
// Add API Versioning
builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new Asp.Versioning.ApiVersion(1, 0);
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.ReportApiVersions = true;
}).AddApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;
});
```

### 3. Zaktualizowano BaseApiController
```csharp
[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
[Asp.Versioning.ApiVersion("1.0")]
public abstract class BaseApiController : ControllerBase
```

### 4. Usunięto nadmiarowe atrybuty z kontrolerów
Z kontrolerów dziedziczących z `BaseApiController` usunięto:
- `[ApiController]`
- `[Route("api/v{version:apiVersion}/[controller]")]`

Kontrolery, które zostały zaktualizowane:
- BusinessLinesController
- DocumentsController
- RecipientsController
- ExamplesController

## Weryfikacja
Aplikacja działa poprawnie. Testy endpointów:

✅ `/health` - Status 200
✅ `/api/v1/examples/TestUser` - Status 200
✅ `/api/v1/businesslines` - Status 200
✅ `/api/v1/recipients` - Status 200

## Format URL
Wszystkie endpointy API są teraz dostępne w formacie:
```
http://localhost:5000/api/v1/[controller]
```

## Data naprawy
2025-11-20

