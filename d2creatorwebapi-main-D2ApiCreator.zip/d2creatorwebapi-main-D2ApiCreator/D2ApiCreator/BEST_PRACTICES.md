# Best Practices & Coding Standards

## 🎯 Zasady SOLID

### Single Responsibility Principle (SRP)
✅ **DO:**
```csharp
// Jedna klasa = jedna odpowiedzialność
public class UserService
{
    public Task<User> GetUserAsync(Guid id) { }
}

public class UserValidator
{
    public ValidationResult Validate(User user) { }
}
```

❌ **DON'T:**
```csharp
// Klasa robi za dużo
public class UserManager
{
    public Task<User> GetUserAsync(Guid id) { }
    public ValidationResult Validate(User user) { }
    public void SendEmail(User user) { }
    public void LogActivity(User user) { }
}
```

### Open/Closed Principle (OCP)
✅ **DO:**
```csharp
public abstract class PaymentProcessor
{
    public abstract Task ProcessAsync(Payment payment);
}

public class CreditCardProcessor : PaymentProcessor
{
    public override Task ProcessAsync(Payment payment) { }
}
```

### Dependency Inversion Principle (DIP)
✅ **DO:**
```csharp
// Zależność od abstrakcji
public class OrderService
{
    private readonly IOrderRepository _repository;
    
    public OrderService(IOrderRepository repository)
    {
        _repository = repository;
    }
}
```

## 🏗️ Domain-Driven Design

### Aggregate Roots
```csharp
public class Order : AggregateRoot<Guid>
{
    private readonly List<OrderItem> _items = new();
    
    public IReadOnlyCollection<OrderItem> Items => _items.AsReadOnly();
    
    // Factory method
    public static Order Create(Guid customerId)
    {
        var order = new Order
        {
            Id = Guid.NewGuid(),
            CustomerId = customerId,
            Status = OrderStatus.Draft
        };
        
        order.AddDomainEvent(new OrderCreatedEvent(order.Id));
        return order;
    }
    
    // Business logic
    public void AddItem(Product product, int quantity)
    {
        if (quantity <= 0)
            throw new BusinessRuleValidationException("Quantity must be positive");
            
        var item = OrderItem.Create(product.Id, quantity, product.Price);
        _items.Add(item);
        
        AddDomainEvent(new ItemAddedToOrderEvent(Id, item.Id));
    }
    
    // Private constructor for EF Core
    private Order() { }
}
```

### Value Objects
```csharp
public class Money : ValueObject
{
    public decimal Amount { get; }
    public string Currency { get; }
    
    public Money(decimal amount, string currency)
    {
        if (amount < 0)
            throw new ArgumentException("Amount cannot be negative");
            
        Amount = amount;
        Currency = currency;
    }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Amount;
        yield return Currency;
    }
    
    // Operators
    public static Money operator +(Money a, Money b)
    {
        if (a.Currency != b.Currency)
            throw new InvalidOperationException("Cannot add money with different currencies");
            
        return new Money(a.Amount + b.Amount, a.Currency);
    }
}
```

### Domain Events
```csharp
public class OrderCreatedEvent : IDomainEvent
{
    public Guid EventId { get; } = Guid.NewGuid();
    public DateTime OccurredOn { get; } = DateTime.UtcNow;
    public Guid OrderId { get; }
    
    public OrderCreatedEvent(Guid orderId)
    {
        OrderId = orderId;
    }
}
```

## 📝 CQRS Best Practices

### Commands
```csharp
// Command - zawsze zwraca pojedynczy result
public record CreateOrderCommand : IRequest<Guid>
{
    public Guid CustomerId { get; init; }
    public List<OrderItemDto> Items { get; init; } = new();
}

// Handler
public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommand, Guid>
{
    private readonly IOrderRepository _repository;
    private readonly IUnitOfWork _unitOfWork;
    
    public CreateOrderCommandHandler(
        IOrderRepository repository,
        IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }
    
    public async Task<Guid> Handle(CreateOrderCommand request, CancellationToken cancellationToken)
    {
        var order = Order.Create(request.CustomerId);
        
        foreach (var item in request.Items)
        {
            // Business logic here
        }
        
        await _repository.AddAsync(order, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        
        return order.Id;
    }
}
```

### Queries
```csharp
// Query - read-only operations
public record GetOrderQuery : IRequest<OrderDto>
{
    public Guid OrderId { get; init; }
}

// Handler - może używać read-only DbContext
public class GetOrderQueryHandler : IRequestHandler<GetOrderQuery, OrderDto>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    
    public async Task<OrderDto> Handle(GetOrderQuery request, CancellationToken cancellationToken)
    {
        var order = await _context.Orders
            .Include(o => o.Items)
            .AsNoTracking() // Read-only!
            .FirstOrDefaultAsync(o => o.Id == request.OrderId, cancellationToken);
            
        if (order == null)
            throw new KeyNotFoundException($"Order {request.OrderId} not found");
            
        return _mapper.Map<OrderDto>(order);
    }
}
```

### Validators
```csharp
public class CreateOrderCommandValidator : AbstractValidator<CreateOrderCommand>
{
    public CreateOrderCommandValidator()
    {
        RuleFor(x => x.CustomerId)
            .NotEmpty()
            .WithMessage("Customer ID is required");
            
        RuleFor(x => x.Items)
            .NotEmpty()
            .WithMessage("Order must contain at least one item");
            
        RuleForEach(x => x.Items)
            .SetValidator(new OrderItemDtoValidator());
    }
}
```

## 🧪 Testing Best Practices

### Unit Tests
```csharp
public class OrderTests
{
    [Fact]
    public void AddItem_WithPositiveQuantity_ShouldAddItem()
    {
        // Arrange
        var order = Order.Create(Guid.NewGuid());
        var product = Product.Create("Product", 10.00m);
        
        // Act
        order.AddItem(product, 2);
        
        // Assert
        order.Items.Should().HaveCount(1);
        order.Items.First().Quantity.Should().Be(2);
    }
    
    [Fact]
    public void AddItem_WithZeroQuantity_ShouldThrowException()
    {
        // Arrange
        var order = Order.Create(Guid.NewGuid());
        var product = Product.Create("Product", 10.00m);
        
        // Act & Assert
        var act = () => order.AddItem(product, 0);
        act.Should().Throw<BusinessRuleValidationException>();
    }
}
```

### Integration Tests
```csharp
public class OrdersControllerTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;
    
    public OrdersControllerTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }
    
    [Fact]
    public async Task CreateOrder_WithValidData_ShouldReturnCreated()
    {
        // Arrange
        var command = new CreateOrderCommand
        {
            CustomerId = Guid.NewGuid(),
            Items = new List<OrderItemDto>
            {
                new() { ProductId = Guid.NewGuid(), Quantity = 2 }
            }
        };
        
        // Act
        var response = await _client.PostAsJsonAsync("/api/orders", command);
        
        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);
    }
}
```

## 📊 Database Best Practices

### Entity Configuration
```csharp
public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.ToTable("Orders");
        
        builder.HasKey(o => o.Id);
        
        builder.Property(o => o.Id)
            .ValueGeneratedNever(); // Używamy Guid z kodu
            
        builder.Property(o => o.Status)
            .HasConversion<string>() // Enum as string
            .HasMaxLength(50)
            .IsRequired();
            
        // Value Object
        builder.OwnsOne(o => o.TotalAmount, amount =>
        {
            amount.Property(a => a.Value)
                .HasColumnName("TotalAmount")
                .HasPrecision(18, 2);
                
            amount.Property(a => a.Currency)
                .HasColumnName("Currency")
                .HasMaxLength(3);
        });
        
        // Collection
        builder.HasMany(o => o.Items)
            .WithOne()
            .HasForeignKey("OrderId")
            .OnDelete(DeleteBehavior.Cascade);
            
        // Ignore domain events
        builder.Ignore(o => o.DomainEvents);
    }
}
```

### Migrations
```csharp
// ✅ DO: Descriptive migration names
dotnet ef migrations add AddOrdersTable
dotnet ef migrations add AddOrderItemsTable
dotnet ef migrations add AddIndexToOrdersCustomerId

// ❌ DON'T: Generic names
dotnet ef migrations add Migration1
dotnet ef migrations add UpdateDatabase
```

## 🔒 Security Best Practices

### Input Validation
```csharp
// ✅ Zawsze waliduj input
public class UpdateUserCommandValidator : AbstractValidator<UpdateUserCommand>
{
    public UpdateUserCommandValidator()
    {
        RuleFor(x => x.Email)
            .NotEmpty()
            .EmailAddress()
            .MaximumLength(256);
            
        RuleFor(x => x.Password)
            .MinimumLength(8)
            .Matches(@"[A-Z]").WithMessage("Password must contain uppercase")
            .Matches(@"[a-z]").WithMessage("Password must contain lowercase")
            .Matches(@"[0-9]").WithMessage("Password must contain digit");
    }
}
```

### SQL Injection Prevention
```csharp
// ✅ DO: Use parametrized queries (EF Core robi to automatycznie)
var users = await _context.Users
    .Where(u => u.Email == email)
    .ToListAsync();

// ❌ DON'T: Raw SQL z concatenation
var sql = $"SELECT * FROM Users WHERE Email = '{email}'"; // NIGDY!
```

## 🚀 Performance Best Practices

### Async/Await
```csharp
// ✅ DO: Async all the way
public async Task<Order> GetOrderAsync(Guid id)
{
    return await _repository.GetByIdAsync(id);
}

// ❌ DON'T: Sync over async
public Order GetOrder(Guid id)
{
    return _repository.GetByIdAsync(id).Result; // Deadlock risk!
}
```

### Query Optimization
```csharp
// ✅ DO: Use AsNoTracking for read-only
var orders = await _context.Orders
    .AsNoTracking()
    .Include(o => o.Items)
    .ToListAsync();

// ✅ DO: Project to DTOs early
var orderDtos = await _context.Orders
    .Select(o => new OrderDto
    {
        Id = o.Id,
        Status = o.Status
    })
    .ToListAsync();

// ❌ DON'T: Over-fetching
var orders = await _context.Orders
    .Include(o => o.Items)
    .Include(o => o.Customer)
    .Include(o => o.Customer.Address)
    .ToListAsync(); // Jeśli nie potrzebujesz wszystkiego
```

## 📝 Naming Conventions

```csharp
// Interfaces: I prefix
public interface IOrderRepository { }

// Classes: PascalCase
public class OrderService { }

// Methods: PascalCase, verb
public async Task<Order> GetOrderAsync(Guid id) { }

// Private fields: _camelCase
private readonly IOrderRepository _repository;

// Properties: PascalCase
public Guid Id { get; set; }

// Constants: PascalCase
public const int MaxOrderItems = 100;

// Local variables: camelCase
var orderItems = new List<OrderItem>();
```

## 🎨 Code Organization

```
Feature/
├── Commands/
│   ├── CreateOrder/
│   │   ├── CreateOrderCommand.cs
│   │   ├── CreateOrderCommandHandler.cs
│   │   └── CreateOrderCommandValidator.cs
│   └── UpdateOrder/
│       ├── UpdateOrderCommand.cs
│       ├── UpdateOrderCommandHandler.cs
│       └── UpdateOrderCommandValidator.cs
└── Queries/
    ├── GetOrder/
    │   ├── GetOrderQuery.cs
    │   └── GetOrderQueryHandler.cs
    └── GetOrders/
        ├── GetOrdersQuery.cs
        └── GetOrdersQueryHandler.cs
```

## ✅ Code Review Checklist

- [ ] Kod zgodny z SOLID principles
- [ ] Wszystkie publiczne API mają XML comments
- [ ] Unit testy pokrywają logikę domenową
- [ ] Integration testy dla API endpoints
- [ ] Walidacja wszystkich inputów
- [ ] Obsługa błędów (try-catch gdzie potrzeba)
- [ ] Async/await poprawnie użyte
- [ ] Żadnych magic strings/numbers
- [ ] Logging w kluczowych miejscach
- [ ] Performance considerations (N+1, over-fetching)

