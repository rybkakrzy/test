# D2ApiCreator - RESTful Web API

## 📋 Opis

Profesjonalna aplikacja Web API zbudowana z wykorzystaniem najlepszych praktyk programowania:
- **Domain-Driven Design (DDD)**
- **Test-Driven Development (TDD)**
- **Clean Architecture**
- **CQRS Pattern** (MediatR)
- **Microservices Ready**
- **PostgreSQL** jako baza danych
- **Kestrel** jako serwer HTTP

## 🏗️ Architektura Projektu

```
D2ApiCreator/
│
├── D2ApiCreator.Api/                 # Warstwa prezentacji (REST API)
│   ├── Controllers/                  # Kontrolery API
│   ├── Middleware/                   # Custom middleware (error handling, logging)
│   ├── Filters/                      # Action filters
│   └── Extensions/                   # Extension methods
│
├── D2ApiCreator.Application/         # Warstwa aplikacji (Use Cases)
│   ├── Common/
│   │   ├── Interfaces/              # Interfejsy (IUnitOfWork, IApplicationDbContext)
│   │   ├── Mappings/                # AutoMapper profiles
│   │   └── Behaviours/              # MediatR pipeline behaviors
│   ├── Features/                     # CQRS Features (Commands & Queries)
│   ├── DTOs/                        # Data Transfer Objects
│   └── Validators/                   # FluentValidation validators
│
├── D2ApiCreator.Domain/              # Warstwa domenowa (Business Logic)
│   ├── Common/
│   │   ├── BaseTypes/               # Entity, AggregateRoot, ValueObject
│   │   └── Exceptions/              # Domain exceptions
│   ├── Entities/                     # Domain entities
│   ├── ValueObjects/                 # Value objects
│   ├── Events/                       # Domain events
│   ├── Repositories/                 # Repository interfaces
│   └── Services/                     # Domain services
│
├── D2ApiCreator.Infrastructure/      # Warstwa infrastruktury
│   ├── Persistence/
│   │   ├── Configurations/          # EF Core entity configurations
│   │   ├── Repositories/            # Repository implementations
│   │   └── Migrations/              # Database migrations
│   ├── Services/                     # External services implementations
│   └── Identity/                     # Authentication & Authorization
│
├── D2ApiCreator.Tests.Unit/          # Testy jednostkowe
│   └── Domain/                       # Testy logiki domenowej
│
└── D2ApiCreator.Tests.Integration/   # Testy integracyjne
    ├── Common/                       # Test infrastructure
    └── Controllers/                  # API endpoint tests
```

## 🚀 Technologie

### Backend
- **.NET 8.0** - Framework
- **ASP.NET Core** - Web API
- **Entity Framework Core 8** - ORM
- **PostgreSQL** - Baza danych
- **Kestrel** - Web Server

### Wzorce i Biblioteki
- **MediatR** - CQRS Pattern implementation
- **FluentValidation** - Walidacja
- **AutoMapper** - Object mapping
- **Serilog** - Structured logging

### Testy
- **xUnit** - Test framework
- **FluentAssertions** - Assertion library
- **NSubstitute** - Mocking framework
- **Bogus** - Test data generation
- **Testcontainers** - Integration testing with Docker
- **WebApplicationFactory** - API integration testing

## 📦 Wymagania

- .NET 8.0 SDK
- PostgreSQL 14+
- Docker (opcjonalnie dla Testcontainers)

## ⚙️ Konfiguracja

### 1. Konfiguracja bazy danych

Edytuj connection string w `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=your_password"
  }
}
```

### 2. Migracje bazy danych

```powershell
# Tworzenie nowej migracji
dotnet ef migrations add InitialCreate --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api

# Aktualizacja bazy danych
dotnet ef database update --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
```

### 3. Uruchomienie aplikacji

#### 🎯 Najłatwiejszy sposób (Skrypty PowerShell):

```powershell
# Restart aplikacji (zatrzymaj wszystkie dotnet + uruchom ponownie)
.\restart-app.ps1

# Tylko zatrzymanie aplikacji
.\stop-app.ps1
```

#### Standardowe uruchomienie:

```powershell
cd D2ApiCreator.Api
dotnet run
```

#### Szybki restart (jedna komenda):

```powershell
taskkill /F /IM dotnet.exe 2>$null; Start-Sleep -Seconds 3; cd D2ApiCreator.Api; dotnet run
```

Aplikacja będzie dostępna pod adresem:
- HTTP: `http://localhost:5000`
- HTTPS: `https://localhost:5001`
- Swagger UI: `http://localhost:5000/swagger` (tylko Development)
- Health Check: `http://localhost:5000/health`

### 4. Szybkie komendy

Pełna lista komend dostępna w pliku: **[QUICK_START_COMMANDS.md](QUICK_START_COMMANDS.md)**

#### Typowe problemy:

**Problem: Port 5000 zajęty (address already in use)**
```powershell
taskkill /F /IM dotnet.exe
Start-Sleep -Seconds 3
cd D2ApiCreator.Api
dotnet run
```

Zobacz więcej w: [QUICK_START_COMMANDS.md](QUICK_START_COMMANDS.md#rozwiązywanie-problemów)

## 🧪 Uruchomienie Testów

### Testy jednostkowe
```powershell
dotnet test D2ApiCreator.Tests.Unit
```

### Testy integracyjne
```powershell
dotnet test D2ApiCreator.Tests.Integration
```

### Wszystkie testy
```powershell
dotnet test
```

## 📝 Zasady Clean Architecture

### Zależności między warstwami

```
Api → Application → Domain
         ↓
    Infrastructure
```

**Zasady:**
- **Domain** - Nie ma zależności do żadnej innej warstwy
- **Application** - Zależy tylko od Domain
- **Infrastructure** - Implementuje interfejsy z Application i Domain
- **Api** - Zależy od Application i Infrastructure (Composition Root)

### Dependency Injection

Każda warstwa posiada własny `DependencyInjection.cs` do rejestracji serwisów:
- `Application.AddApplication()`
- `Infrastructure.AddInfrastructure(configuration)`

## 🔧 Dobre Praktyki

### 1. CQRS Pattern
Oddzielenie operacji zapisu (Commands) od odczytu (Queries):
```
Features/
├── YourFeature/
│   ├── Commands/
│   │   ├── CreateCommand.cs
│   │   ├── CreateCommandHandler.cs
│   │   └── CreateCommandValidator.cs
│   └── Queries/
│       ├── GetQuery.cs
│       └── GetQueryHandler.cs
```

### 2. Repository Pattern
```csharp
public interface IYourRepository : IRepository<YourEntity, Guid>
{
    Task<IEnumerable<YourEntity>> GetSpecialItemsAsync();
}
```

### 3. Value Objects
```csharp
public class Email : ValueObject
{
    public string Value { get; }
    
    protected override IEnumerable<object?> GetEqualityComponents()
    {
        yield return Value;
    }
}
```

### 4. Domain Events
```csharp
public class YourDomainEvent : IDomainEvent
{
    public Guid EventId { get; } = Guid.NewGuid();
    public DateTime OccurredOn { get; } = DateTime.UtcNow;
}
```

## 📚 Middleware Pipeline

1. **ExceptionHandlingMiddleware** - Global error handling
2. **Serilog Request Logging** - Request/Response logging
3. **CORS** - Cross-Origin Resource Sharing
4. **Authentication** (ready to implement)
5. **Authorization** (ready to implement)

## 🔐 Health Checks

Endpoint: `/health`

Sprawdza:
- Status aplikacji
- Połączenie z bazą danych (do zaimplementowania)
- Zewnętrzne zależności (do zaimplementowania)

## 📖 API Documentation

Swagger UI dostępny pod adresem: `/swagger`

## 🎯 Kolejne Kroki

1. **Implementacja pierwszego Aggregate Root**
   - Dodaj encję w `Domain/Entities/`
   - Stwórz konfigurację EF Core w `Infrastructure/Persistence/Configurations/`

2. **Dodanie CQRS Feature**
   - Stwórz Commands i Queries w `Application/Features/`
   - Zaimplementuj Handlers
   - Dodaj Validators

3. **Utworzenie Controller**
   - Dodaj kontroler dziedziczący po `BaseApiController`
   - Użyj MediatR do wysyłania Commands/Queries

4. **Napisanie Testów**
   - Testy jednostkowe dla logiki domenowej
   - Testy integracyjne dla API endpoints

## 📄 Licencja

Projekt stworzony dla celów edukacyjnych i komercyjnych.

## 👨‍💻 Autor

Stworzono przez profesjonalnego developera z wykorzystaniem najlepszych praktyk .NET

