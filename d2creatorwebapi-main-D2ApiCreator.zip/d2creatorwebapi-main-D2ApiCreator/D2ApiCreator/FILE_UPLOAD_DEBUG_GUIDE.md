# Przewodnik Debugowania Uploadu Plików

## Problem
```json
{"message":"An error occurred while uploading the file"}
```

## Krok po kroku - Diagnoza

### 1. Sprawdź Logi
```powershell
# Otwórz najnowszy log
cd C:\Projekty\Jit\Kreator\d2creatorwebapi\D2ApiCreator\D2ApiCreator.Api\logs
Get-Content (Get-ChildItem -Filter "log-*.txt" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName -Tail 50
```

Szukaj w logach:
- `[ERR]` - błędy
- `Uploading file` - informacje o uploadzie
- `Error uploading file` - szczegóły błędu

### 2. Sprawdź Connection String

**Lokalizacja:** `appsettings.Development.json`

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=your_password"
  }
}
```

**Weryfikacja:**
```powershell
# Sprawdź czy PostgreSQL działa
Test-NetConnection -ComputerName localhost -Port 5432
```

### 3. Sprawdź Bazę Danych

```sql
-- Połącz się z bazą danych
psql -U postgres -d D2CreatorDb

-- Sprawdź czy tabele istnieją
\dt

-- Sprawdź ProjectVersions
SELECT * FROM "ProjectVersions" ORDER BY "CreatedAt" DESC LIMIT 5;

-- Sprawdź Files
SELECT * FROM "Files" ORDER BY "CreatedAt" DESC LIMIT 5;
```

### 4. Test Manualny z cURL

```bash
# Krok 1: Utwórz projekt
curl -X POST http://localhost:5000/api/v1/projects \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Project",
    "description": "Test upload"
  }'

# Zapisz zwrócone projectId i projectVersionId

# Krok 2: Upload pliku
curl -X POST "http://localhost:5000/api/v1/files/project-versions/{projectVersionId}/upload" \
  -F "file=@path/to/your/file.docx"
```

### 5. Sprawdź Backend Endpoint

**Endpoint:** `POST /api/v1/files/project-versions/{projectVersionId}/upload`

**Wymagania:**
- Plik: format `.docx`
- Rozmiar: max 10MB
- ProjectVersionId musi istnieć w bazie

**Kod walidacji:**
```csharp
// Sprawdza czy plik istnieje
if (file == null || file.Length == 0)
    return BadRequest("File is required and cannot be empty");

// Sprawdza rozszerzenie
if (!file.FileName.EndsWith(".docx"))
    return BadRequest("Only .docx files are allowed");

// Sprawdza rozmiar
if (file.Length > 10 * 1024 * 1024)
    return BadRequest("File size cannot exceed 10MB");

// Sprawdza czy ProjectVersion istnieje
var projectVersion = await _projectVersionRepository.GetByIdAsync(projectVersionId);
if (projectVersion == null)
    throw new InvalidOperationException($"Project version {projectVersionId} not found");
```

## Najczęstsze Przyczyny Błędu

### 1. ProjectVersion nie istnieje
**Objaw:** Błąd 500 + log "Project version {id} not found"

**Rozwiązanie:**
- Sprawdź czy krok 1 kreatora (utworzenie projektu) zakończył się sukcesem
- Zweryfikuj czy `projectVersionId` jest poprawnie przekazywane z frontendu

### 2. Brak połączenia z bazą danych
**Objaw:** Timeout / Connection refused

**Rozwiązanie:**
```powershell
# Uruchom PostgreSQL jeśli nie działa
Start-Service postgresql-x64-14  # lub inna wersja
```

### 3. Nieprawidłowy format pliku
**Objaw:** Błąd 400 "Only .docx files are allowed"

**Rozwiązanie:**
- Upewnij się że plik ma rozszerzenie `.docx`
- Sprawdź czy plik nie jest uszkodzony

### 4. Plik za duży
**Objaw:** Błąd 400 "File size cannot exceed 10MB"

**Rozwiązanie:**
- Zmniejsz rozmiar pliku
- Lub zwiększ limit w `FilesController.cs`

## Debug Mode - Szczegółowe Logi

Dodaj szczegółowe logowanie w `UploadFileCommandHandler.cs`:

```csharp
public async Task<Guid> Handle(UploadFileCommand request, CancellationToken cancellationToken)
{
    try
    {
        _logger.LogInformation("=== START UPLOAD ===");
        _logger.LogInformation("ProjectVersionId: {Id}", request.ProjectVersionId);
        _logger.LogInformation("FileName: {Name}", request.FileName);
        _logger.LogInformation("ContentType: {Type}", request.ContentType);
        
        var projectVersion = await _projectVersionRepository.GetByIdAsync(request.ProjectVersionId, cancellationToken);
        _logger.LogInformation("ProjectVersion found: {Found}", projectVersion != null);
        
        if (projectVersion == null)
        {
            _logger.LogError("ProjectVersion {Id} NOT FOUND in database", request.ProjectVersionId);
            throw new InvalidOperationException($"Project version {request.ProjectVersionId} not found");
        }
        
        // ... reszta kodu ...
        
        _logger.LogInformation("=== UPLOAD SUCCESS ===");
        return fileId;
    }
    catch (Exception ex)
    {
        _logger.LogError(ex, "=== UPLOAD FAILED === Error: {Message}", ex.Message);
        throw;
    }
}
```

## Quick Fix Checklist

- [ ] PostgreSQL działa (port 5432)
- [ ] Connection string jest poprawny
- [ ] Tabele w bazie istnieją
- [ ] Projekt został utworzony w kroku 1
- [ ] ProjectVersionId jest poprawny
- [ ] Plik ma format .docx
- [ ] Plik jest mniejszy niż 10MB
- [ ] Aplikacja API działa (port 5000 lub 5001)
- [ ] Sprawdzono logi pod kątem szczegółów błędu

## Kontakt z Supportem

Jeśli problem persystuje, załącz:
1. Ostatnie 100 linii logu
2. Screenshot błędu z frontendu
3. Request payload (bez wrażliwych danych)
4. Wersję aplikacji

---

**Autor:** GitHub Copilot  
**Data:** 2025-11-23

