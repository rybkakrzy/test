# Ekstrakcja Znaczników z Dokumentów DOCX

## Przegląd
Funkcjonalność pozwala na przesyłanie plików DOCX i automatyczne wyszukiwanie wszystkich znaczników w formacie `<%...%>`.

## Architektura

### Utworzone Komponenty

#### 1. Controller
- **Ścieżka**: `D2ApiCreator.Api/Controllers/DocumentsController.cs`
- **Endpoint**: `POST /api/documents/extract-placeholders`
- **Opis**: Przyjmuje plik DOCX poprzez multipart/form-data

#### 2. Query Handler (CQRS)
- **Ścieżka**: `D2ApiCreator.Application/Features/Documents/Queries/ExtractPlaceholders/`
- **Klasy**:
  - `ExtractPlaceholdersQuery.cs` - Query object
  - `ExtractPlaceholdersQueryHandler.cs` - Handler implementujący logikę biznesową
  - `ExtractPlaceholdersQueryValidator.cs` - Walidator FluentValidation

#### 3. Service
- **Ścieżka**: `D2ApiCreator.Infrastructure/Services/DocumentPlaceholderService.cs`
- **Interfejs**: `IDocumentPlaceholderService`
- **Opis**: Serwis odpowiedzialny za parsowanie plików DOCX i ekstrakcję znaczników

#### 4. DTO
- **Ścieżka**: `D2ApiCreator.Application/DTOs/DocumentPlaceholderDto.cs`
- **Właściwości**:
  - `Placeholders` - Lista znalezionych znaczników
  - `TotalCount` - Liczba znalezionych znaczników
  - `FileName` - Nazwa przesłanego pliku

## Użycie

### cURL Example
```bash
curl -X POST "https://localhost:5001/api/documents/extract-placeholders" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@document.docx"
```

### Przykładowa Odpowiedź
```json
{
  "placeholders": [
    "<%ala_nazwa%>",
    "<%imie%>",
    "<%kuta_lubi_cipki%>",
    "<%nazwisko%>"
  ],
  "totalCount": 4,
  "fileName": "document.docx"
}
```

### Swagger UI
1. Uruchom aplikację: `dotnet run --project D2ApiCreator.Api`
2. Przejdź do: `https://localhost:5001/swagger`
3. Znajdź endpoint: `POST /api/documents/extract-placeholders`
4. Użyj przycisku "Try it out"
5. Wybierz plik DOCX i kliknij "Execute"

## Walidacja

Walidacja jest wykonywana automatycznie przez FluentValidation:
- Plik musi być w formacie `.docx`
- Plik nie może być pusty
- Nazwa pliku jest wymagana

## Wzorzec Regex

Znaczniki są wyszukiwane przy użyciu wyrażenia regularnego:
```regex
<%([^%>]+)%>
```

To wyrażenie znajdzie wszystkie znaczniki w formacie `<%...%>`, gdzie:
- `<%` - początek znacznika
- `([^%>]+)` - jedna lub więcej znaków, które nie są `%` lub `>`
- `%>` - koniec znacznika

## Przeszukiwane Części Dokumentu

Usługa przeszukuje następujące części dokumentu DOCX:
- Treść główna dokumentu (Body)
- Wszystkie nagłówki (Headers)
- Wszystkie stopki (Footers)

## Zależności

### Dodane Pakiety NuGet
- `DocumentFormat.OpenXml` (v3.1.1) - Do parsowania plików DOCX

### Rejestracja w DI Container
Serwis `IDocumentPlaceholderService` jest zarejestrowany w `Infrastructure/DependencyInjection.cs` jako Scoped.

## Obsługa Błędów

- **400 Bad Request**: Gdy plik jest pusty lub nie jest w formacie .docx
- **500 Internal Server Error**: Gdy wystąpi błąd podczas parsowania dokumentu
- Wszystkie błędy są logowane przez ILogger

## Testowanie

### Plik HTTP Request
Użyj pliku `D2ApiCreator.Api/D2ApiCreator.http` w IDE (Rider/Visual Studio) do szybkiego testowania endpointu.
Endpoint do ekstrakcji znaczników znajduje się na końcu pliku.

### Przykład w Postman
1. Metoda: POST
2. URL: `https://localhost:5001/api/documents/extract-placeholders`
3. Body: form-data
4. Key: `file` (type: File)
5. Value: Wybierz plik .docx

## Clean Architecture

Funkcjonalność została zaimplementowana zgodnie z zasadami Clean Architecture:
- **API Layer**: Controller
- **Application Layer**: Query, Handler, Validator, DTO, Interface
- **Infrastructure Layer**: Implementacja serwisu, zależności zewnętrzne

## Rozszerzenia

Możliwe rozszerzenia funkcjonalności:
1. Dodanie obsługi innych formatów (DOC, ODT, PDF)
2. Zwracanie lokalizacji znaczników w dokumencie
3. Grupowanie znaczników według typów
4. Podgląd kontekstu wokół znacznika
5. Walidacja znaczników według wzorców biznesowych

