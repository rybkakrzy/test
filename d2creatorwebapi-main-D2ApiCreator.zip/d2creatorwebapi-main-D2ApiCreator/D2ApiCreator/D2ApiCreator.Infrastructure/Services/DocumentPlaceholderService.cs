﻿﻿using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using D2ApiCreator.Application.Common.Interfaces;
using Microsoft.Extensions.Logging;
namespace D2ApiCreator.Infrastructure.Services;
/// <summary>
/// Service for extracting placeholders from DOCX documents
/// </summary>
public class DocumentPlaceholderService : IDocumentPlaceholderService
{
    private readonly ILogger<DocumentPlaceholderService> _logger;
    private static readonly Regex PlaceholderRegex = new(@"<%([^<>%]+)%>", RegexOptions.Compiled);
    public DocumentPlaceholderService(ILogger<DocumentPlaceholderService> logger)
    {
        _logger = logger;
    }
    public async Task<List<string>> ExtractPlaceholdersFromDocxAsync(Stream fileStream, string fileName)
    {
        try
        {
            var placeholders = new HashSet<string>();
            using (var document = WordprocessingDocument.Open(fileStream, false))
            {
                if (document.MainDocumentPart == null)
                {
                    _logger.LogWarning("Document {FileName} has no main document part", fileName);
                    return new List<string>();
                }
                var body = document.MainDocumentPart.Document.Body;
                if (body == null)
                {
                    _logger.LogWarning("Document {FileName} has no body", fileName);
                    return new List<string>();
                }
                // Extract text from all text elements
                var textElements = body.Descendants<Text>();
                foreach (var textElement in textElements)
                {
                    if (string.IsNullOrWhiteSpace(textElement.Text))
                        continue;
                    var matches = PlaceholderRegex.Matches(textElement.Text);
                    foreach (Match match in matches)
                    {
                        if (match.Success && match.Groups.Count > 1)
                        {
                            placeholders.Add(match.Value); // Includes <% and %>
                        }
                    }
                }
                // Also check in headers and footers
                foreach (var headerPart in document.MainDocumentPart.HeaderParts)
                {
                    ExtractPlaceholdersFromPart(headerPart.Header, placeholders);
                }
                foreach (var footerPart in document.MainDocumentPart.FooterParts)
                {
                    ExtractPlaceholdersFromPart(footerPart.Footer, placeholders);
                }
            }
            _logger.LogInformation("Extracted {Count} unique placeholders from {FileName}", 
                placeholders.Count, fileName);
            return await Task.FromResult(placeholders.OrderBy(p => p).ToList());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting placeholders from {FileName}", fileName);
            throw;
        }
    }
    private void ExtractPlaceholdersFromPart(OpenXmlElement element, HashSet<string> placeholders)
    {
        var textElements = element.Descendants<Text>();
        foreach (var textElement in textElements)
        {
            if (string.IsNullOrWhiteSpace(textElement.Text))
                continue;
            var matches = PlaceholderRegex.Matches(textElement.Text);
            foreach (Match match in matches)
            {
                if (match.Success && match.Groups.Count > 1)
                {
                    placeholders.Add(match.Value);
                }
            }
        }
    }
}
