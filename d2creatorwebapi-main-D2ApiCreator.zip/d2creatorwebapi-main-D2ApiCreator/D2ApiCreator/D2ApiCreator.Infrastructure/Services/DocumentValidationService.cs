using D2ApiCreator.Application.DTOs;
using Microsoft.Extensions.Logging;

namespace D2ApiCreator.Infrastructure.Services;

/// <summary>
/// Interfejs serwisu do walidacji dokumentów Word
/// </summary>
public interface IDocumentValidationService
{
    /// <summary>
    /// Waliduje szablon dokumentu Word
    /// </summary>
    /// <param name="fileStream">Strumień pliku DOCX</param>
    /// <param name="fileName">Nazwa pliku</param>
    /// <param name="cancellationToken">Token anulowania</param>
    /// <returns>Wynik walidacji</returns>
    Task<DocumentValidationResultDto> ValidateDocumentTemplateAsync(
        Stream fileStream, 
        string fileName, 
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Mock implementacja serwisu walidacji dokumentów
/// Docelowo będzie komunikować się z zewnętrznym serwisem walidacji
/// </summary>
public sealed class MockDocumentValidationService : IDocumentValidationService
{
    private readonly ILogger<MockDocumentValidationService> _logger;

    public MockDocumentValidationService(ILogger<MockDocumentValidationService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<DocumentValidationResultDto> ValidateDocumentTemplateAsync(
        Stream fileStream, 
        string fileName, 
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Validating document template: {FileName}", fileName);

        // Symulacja opóźnienia sieciowego (wywołanie zewnętrznego API)
        await Task.Delay(500, cancellationToken);

        // Sprawdzenie podstawowych parametrów
        if (fileStream == null || fileStream.Length == 0)
        {
            return new DocumentValidationResultDto
            {
                IsValid = false,
                Errors = new List<ValidationErrorDto>
                {
                    new ValidationErrorDto
                    {
                        Code = "EMPTY_FILE",
                        Message = "Plik jest pusty",
                        Severity = "Error"
                    }
                }
            };
        }

        // Mock - dokument zawsze jest poprawny
        var result = new DocumentValidationResultDto
        {
            IsValid = true,
            Errors = new List<ValidationErrorDto>(),
            Warnings = new List<ValidationWarningDto>(),
            Metadata = new DocumentMetadataDto
            {
                FileSizeBytes = fileStream.Length,
                Format = "DOCX",
                PageCount = 1,
                CharacterCount = 0,
                ContainsMacros = false
            }
        };

        _logger.LogInformation(
            "Document validation completed: {FileName}, IsValid: {IsValid}", 
            fileName, 
            result.IsValid);

        return result;
    }
}
