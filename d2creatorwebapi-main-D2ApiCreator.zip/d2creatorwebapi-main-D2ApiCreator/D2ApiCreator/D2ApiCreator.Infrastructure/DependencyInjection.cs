using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Domain.Repositories;
using D2ApiCreator.Infrastructure.Persistence;
using D2ApiCreator.Infrastructure.Persistence.Repositories;
using D2ApiCreator.Infrastructure.Services;

namespace D2ApiCreator.Infrastructure;

/// <summary>
/// Dependency Injection configuration for Infrastructure layer
/// </summary>
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        // Register Database Context (without migrations - using SQL scripts instead)
        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("DefaultConnection")));

        // Register Unit of Work
        services.AddScoped<IUnitOfWork>(provider => provider.GetRequiredService<ApplicationDbContext>());
        services.AddScoped<IApplicationDbContext>(provider => provider.GetRequiredService<ApplicationDbContext>());

        // Register generic repository
        services.AddScoped(typeof(IRepository<,>), typeof(Repository<,>));

        // Register specific repositories
        services.AddScoped<IProjectRepository, ProjectRepository>();
        services.AddScoped<IProjectVersionRepository, ProjectVersionRepository>();
        services.AddScoped<IFileRepository, FileRepository>();

        // Register services
        services.AddScoped<IDocumentPlaceholderService, DocumentPlaceholderService>();
        services.AddScoped<IDocumentValidationService, MockDocumentValidationService>();
        
        // Register Cache Service
        services.AddMemoryCache();
        services.AddSingleton<ICacheService, MemoryCacheService>();
        
        // Register External Data Service (mock - to be replaced with real implementation)
        services.AddScoped<IExternalDataService, MockExternalDataService>();

        return services;
    }
}

