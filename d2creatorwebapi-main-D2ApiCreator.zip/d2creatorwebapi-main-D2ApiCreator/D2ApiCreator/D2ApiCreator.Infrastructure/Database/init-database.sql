--=================================================--
-- D2Creator Database - Complete Schema
-- Wszystkie wersje połączone w jeden plik inicjalizacyjny
-- Data utworzenia: 2025-11-23
-- UWAGA: PRZED URUCHOMIENIEM WYKONAJ KOPIĘ BAZY DANYCH!
--=================================================--
SET ROLE postgres;

-- ===========================================
-- TABELA WERSJI BAZY DANYCH
-- ===========================================
CREATE TABLE IF NOT EXISTS database_version (
    id_version INTEGER PRIMARY KEY,
    description VARCHAR(500),
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    applied_by VARCHAR(100) DEFAULT CURRENT_USER
);

-- ===========================================
-- WERSJA 1: PODSTAWOWY SCHEMAT
-- ===========================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM database_version WHERE id_version >= 1) THEN
        RAISE NOTICE 'Tworzenie podstawowego schematu bazy danych...';
        
        -- Tabela: Tenants
        CREATE TABLE tenants (
            "Id" UUID PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            description TEXT,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Tabela: Users
        CREATE TABLE users (
            "Id" UUID PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            email VARCHAR(255) NOT NULL UNIQUE,
            full_name VARCHAR(200),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Tabela: Projects
        CREATE TABLE projects (
            "Id" UUID PRIMARY KEY,
            tenant_id UUID NOT NULL,
            source VARCHAR(50) NOT NULL,
            name TEXT NOT NULL,
            application_name VARCHAR(255),
            recipient_id VARCHAR(100),
            retention_days INTEGER NOT NULL DEFAULT 365,
            process_name VARCHAR(255),
            process_owner VARCHAR(255),
            business_line_id VARCHAR(100),
            process_version VARCHAR(50),
            process_step VARCHAR(100),
            status_id VARCHAR(50),
            default_template_name VARCHAR(255),
            created_by UUID,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            description TEXT,
            current_active_version_id UUID,
            
            CONSTRAINT "FK_projects_tenants_tenant_id" 
                FOREIGN KEY (tenant_id) REFERENCES tenants("Id") ON DELETE CASCADE,
            CONSTRAINT "FK_projects_users_created_by" 
                FOREIGN KEY (created_by) REFERENCES users("Id") ON DELETE SET NULL,
            CONSTRAINT "uq_project_source_per_tenant" 
                UNIQUE (tenant_id, source)
        );
        
        -- Indeksy dla projects
        CREATE INDEX "IX_projects_created_by" ON projects(created_by);
        CREATE INDEX "IX_projects_tenant_id" ON projects(tenant_id);
        CREATE INDEX "IX_projects_source" ON projects(source);
        CREATE INDEX "IX_projects_process_name" ON projects(process_name);
        CREATE INDEX "IX_projects_business_line_id" ON projects(business_line_id);
        CREATE INDEX "IX_projects_status_id" ON projects(status_id);
        
        -- Tabela: ProjectVersions
        CREATE TABLE project_versions (
            "Id" UUID PRIMARY KEY,
            project_id UUID NOT NULL,
            description TEXT,
            is_active BOOLEAN NOT NULL DEFAULT FALSE,
            created_by UUID,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            
            CONSTRAINT "FK_project_versions_projects_project_id" 
                FOREIGN KEY (project_id) REFERENCES projects("Id") ON DELETE CASCADE,
            CONSTRAINT "FK_project_versions_users_created_by" 
                FOREIGN KEY (created_by) REFERENCES users("Id") ON DELETE SET NULL
        );
        
        -- Indeksy dla project_versions
        CREATE INDEX "IX_project_versions_project_id" ON project_versions(project_id);
        CREATE INDEX "IX_project_versions_is_active" ON project_versions(is_active) WHERE is_active = TRUE;
        
        -- Tabela: Documents
        CREATE TABLE documents (
            "Id" UUID PRIMARY KEY,
            project_version_id UUID NOT NULL,
            template_name VARCHAR(255) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            
            CONSTRAINT "FK_documents_project_versions_project_version_id" 
                FOREIGN KEY (project_version_id) REFERENCES project_versions("Id") ON DELETE CASCADE
        );
        
        -- Indeksy dla documents
        CREATE INDEX "IX_documents_project_version_id" ON documents(project_version_id);
        
        -- Tabela: DocumentPlaceholders
        CREATE TABLE document_placeholders (
            "Id" UUID PRIMARY KEY,
            document_id UUID NOT NULL,
            placeholder_key VARCHAR(100) NOT NULL,
            placeholder_value TEXT,
            placeholder_type VARCHAR(50) NOT NULL,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            
            CONSTRAINT "FK_document_placeholders_documents_document_id" 
                FOREIGN KEY (document_id) REFERENCES documents("Id") ON DELETE CASCADE,
            CONSTRAINT "uq_document_placeholder_key" 
                UNIQUE (document_id, placeholder_key)
        );
        
        -- Indeksy dla document_placeholders
        CREATE INDEX "IX_document_placeholders_document_id" ON document_placeholders(document_id);
        
        -- Dane testowe - Tenant
        INSERT INTO tenants ("Id", name, description, is_active)
        VALUES 
            ('11111111-1111-1111-1111-111111111111', 'NL', 'Netherlands Tenant', TRUE),
            ('22222222-2222-2222-2222-222222222222', 'PL', 'Poland Tenant', TRUE);
        
        -- Dane testowe - User
        INSERT INTO users ("Id", username, email, full_name, is_active)
        VALUES 
            ('33333333-3333-3333-3333-333333333333', 'admin', 'admin@d2creator.com', 'System Administrator', TRUE),
            ('44444444-4444-4444-4444-444444444444', 'testuser', 'test@d2creator.com', 'Test User', TRUE);
        
        -- Rejestracja wersji
        INSERT INTO database_version (id_version, description)
        VALUES (1, 'Utworzenie podstawowego schematu bazy danych');
        
        RAISE NOTICE 'Wersja 1 została zastosowana';
    END IF;
END $$;

-- ===========================================
-- WERSJA 2: POLA METADANYCH W PROJECTS
-- ===========================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM database_version WHERE id_version >= 2) 
       AND EXISTS (SELECT 1 FROM database_version WHERE id_version = 1) THEN
        
        RAISE NOTICE 'Rozpoczęcie aktualizacji do wersji 2...';
        
        -- Wszystkie kolumny zostały już dodane w wersji 1, więc tylko rejestrujemy wersję
        INSERT INTO database_version (id_version, description)
        VALUES (2, 'Rozszerzenie tabeli projects o pola metadanych biznesowych');
        
        RAISE NOTICE 'Wersja 2 została zastosowana';
    END IF;
END $$;

-- ===========================================
-- WERSJA 3: METADATA W TENANTS
-- ===========================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM database_version WHERE id_version >= 3) 
       AND EXISTS (SELECT 1 FROM database_version WHERE id_version = 2) THEN
        
        RAISE NOTICE 'Rozpoczęcie aktualizacji do wersji 3...';
        
        -- Dodanie kolumny metadata do tabeli tenants
        ALTER TABLE tenants ADD COLUMN metadata JSONB;
        COMMENT ON COLUMN tenants.metadata IS 'Dodatkowe metadane tenanta w formacie JSON';
        CREATE INDEX "IX_tenants_metadata" ON tenants USING GIN (metadata);
        
        INSERT INTO database_version (id_version, description)
        VALUES (3, 'Dodanie kolumny metadata (JSONB) do tabeli tenants');
        
        RAISE NOTICE 'Wersja 3 została zastosowana';
    END IF;
END $$;

-- ===========================================
-- WERSJA 4: TENANT_ID I DISPLAY_NAME W USERS
-- ===========================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM database_version WHERE id_version >= 4) 
       AND EXISTS (SELECT 1 FROM database_version WHERE id_version = 3) THEN
        
        RAISE NOTICE 'Rozpoczęcie aktualizacji do wersji 4...';
        
        -- Dodanie kolumny tenant_id
        ALTER TABLE users ADD COLUMN tenant_id UUID;
        UPDATE users SET tenant_id = '11111111-1111-1111-1111-111111111111' WHERE tenant_id IS NULL;
        ALTER TABLE users ALTER COLUMN tenant_id SET NOT NULL;
        ALTER TABLE users ADD CONSTRAINT "FK_users_tenants_tenant_id" 
            FOREIGN KEY (tenant_id) REFERENCES tenants("Id") ON DELETE CASCADE;
        
        -- Zmiana full_name na display_name
        ALTER TABLE users RENAME COLUMN full_name TO display_name;
        
        -- Usunięcie starych constraintów
        ALTER TABLE users DROP CONSTRAINT IF EXISTS users_username_key;
        ALTER TABLE users DROP CONSTRAINT IF EXISTS users_email_key;
        
        -- Utworzenie nowego unikalnego indeksu
        CREATE UNIQUE INDEX "ux_users_tenant_username" ON users(tenant_id, username);
        CREATE INDEX "IX_users_tenant_id" ON users(tenant_id);
        
        INSERT INTO database_version (id_version, description)
        VALUES (4, 'Dodanie kolumn tenant_id i display_name do tabeli users');
        
        RAISE NOTICE 'Wersja 4 została zastosowana';
    END IF;
END $$;

-- ===========================================
-- WERSJA 5: ROZSZERZENIE PROJECT_VERSIONS
-- ===========================================
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM database_version WHERE id_version >= 5) 
       AND EXISTS (SELECT 1 FROM database_version WHERE id_version = 4) THEN
        
        RAISE NOTICE 'Rozpoczęcie aktualizacji do wersji 5...';
        
        -- Dodanie kolumn wersjonowania
        ALTER TABLE project_versions ADD COLUMN major INTEGER;
        ALTER TABLE project_versions ADD COLUMN minor INTEGER;
        ALTER TABLE project_versions ADD COLUMN version_tag VARCHAR(50) NOT NULL DEFAULT 'v1.0';
        ALTER TABLE project_versions ADD COLUMN status VARCHAR(50);
        ALTER TABLE project_versions ADD COLUMN notes TEXT;
        ALTER TABLE project_versions ADD COLUMN step_data JSONB;
        
        -- Utworzenie indeksów
        CREATE UNIQUE INDEX "uq_project_version_tag" ON project_versions(project_id, version_tag);
        CREATE INDEX "idx_project_versions_project_id_created_at" ON project_versions(project_id, created_at);
        CREATE INDEX "IX_project_versions_step_data" ON project_versions USING GIN (step_data);
        
        -- Komentarze
        COMMENT ON COLUMN project_versions.major IS 'Główny numer wersji';
        COMMENT ON COLUMN project_versions.minor IS 'Pomocniczy numer wersji';
        COMMENT ON COLUMN project_versions.version_tag IS 'Tag wersji (np. v1.0, v2.1)';
        COMMENT ON COLUMN project_versions.status IS 'Status wersji projektu';
        COMMENT ON COLUMN project_versions.notes IS 'Notatki do wersji';
        COMMENT ON COLUMN project_versions.step_data IS 'Dane kroków wizarda w formacie JSON';
        
        INSERT INTO database_version (id_version, description)
        VALUES (5, 'Rozszerzenie tabeli project_versions o kolumny wersjonowania');
        
        RAISE NOTICE 'Wersja 5 została zastosowana';
    END IF;
END $$;

-- ===========================================
-- PODSUMOWANIE
-- ===========================================
DO $$
DECLARE
    v_current_version INTEGER;
BEGIN
    SELECT COALESCE(MAX(id_version), 0) INTO v_current_version FROM database_version;
    RAISE NOTICE '';
    RAISE NOTICE '===========================================';
    RAISE NOTICE 'Inicjalizacja bazy danych zakończona';
    RAISE NOTICE 'Aktualna wersja: %', v_current_version;
    RAISE NOTICE '===========================================';
END $$;

-- Wyświetlenie historii wersji
SELECT 
    id_version AS "Wersja",
    description AS "Opis",
    applied_at AS "Data zastosowania",
    applied_by AS "Wykonane przez"
FROM database_version
ORDER BY id_version;
