# Model encji D2ApiCreator — opis aktualnego stanu

Data: 2025-11-19 (zaktualizowano po refaktoringu)

Ten dokument opisuje aktualne encje domenowe i odpowiadające im tabele DB w projekcie D2ApiCreator. Zawiera: pola (typy DB i C#), powód projektowy, zależności (FK), navigation properties, indeksy i uwagi o mapowaniach EF Core.

Uwaga: pliki z implementacją można znaleźć w repozytorium:
- encje domenowe: `D2ApiCreator.Domain/Entities/`
- enumy domenowe: `D2ApiCreator.Domain/Enums/` (ProjectStatus, MappingType, ApprovalStatus)
- konfiguracje EF Core: `D2ApiCreator.Infrastructure/Persistence/Configurations/`
- DDL / Flyway: `D2ApiCreator.Infrastructure/Database/init_schema_d2api.sql` i `.../Flyway/V1__init_schema_d2api.sql`.

---

## Zasady projektowe (krótkie przypomnienie)
- Główne Id używamy jako `uuid` (PG) i `Guid` w C#.
- Pliki DOCX są przechowywane jako `bytea` w kolumnie `files.content` (mapowane do `byte[]` w C#).
- Dane kroków kreatora przechowujemy w `project_versions.step_data` typu `jsonb` (w C# mapowane jako `JsonDocument`).
- Wersjonowanie: snapshot per version (copy-on-write) — pełne kopiowanie powiązanych danych (mappings, pliki) przy tworzeniu nowej wersji.
- Jedna aktywna wersja na projekt: `project_versions.is_active` + partial unique index + trigger zapewniający spójność.
- **Navigation properties**: wszystkie encje mają teraz navigation properties dla relacji EF Core (lazy loading disabled by default).
- **Metody biznesowe**: encje posiadają metody do zarządzania stanem (Activate, Deactivate, UpdateStatus itp.) zgodnie z podejściem DDD.

---

# Lista encji i opis

Poniżej opisy każdej encji: tabela DB, klasa domenowa, pola, zależności, navigation properties i uwagi.

---

## `Tenant` (tabela `tenants`)
- Klasa: `D2ApiCreator.Domain.Entities.Tenant`
- Konfiguracja EF: `TenantConfiguration`

Pola (DB : C#):
- `id uuid` : `Guid Id` — PK, domyślnie `gen_random_uuid()` po stronie DB.
- `name text` : `string Name` — nazwa tenanta.
- `metadata jsonb` : `JsonDocument? Metadata` — dodatkowe metadane (opcjonalne). **[POPRAWKA: JsonElement->JsonDocument]**
- `created_at timestamptz` : `DateTime CreatedAt` — data utworzenia.

Cel / uzasadnienie:
- Izolacja danych wielotenantowa: tenanty grupują projekty i użytkowników.

Relacje (FK):
- 1:N -> `users` (users.tenant_id).
- 1:N -> `projects` (projects.tenant_id).

Navigation properties:
- `IReadOnlyCollection<User> Users`
- `IReadOnlyCollection<Project> Projects`

Metody biznesowe:
- `UpdateMetadata(JsonDocument? metadata)` — aktualizacja metadanych.

Uwagi:
- Tabela lekka, może zawierać dodatkowe metadane JSON dla integracji.

---

## `User` (tabela `users`)
- Klasa: `D2ApiCreator.Domain.Entities.User`
- Konfiguracja EF: `UserConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `tenant_id uuid` : `Guid TenantId` (FK -> tenants.id).
- `username text` : `string Username` (unikalne per tenant).
- `email text` : `string? Email`.
- `display_name text` : `string? DisplayName`.
- `is_active boolean` : `bool IsActive`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Reprezentuje użytkownika aplikacji; używany jako referencja w `created_by` oraz `approver_id`.

Indeksy / constraints:
- UNIQUE (`tenant_id`, `username`) — zapewnia unikalne nazwy w ramach tenant.

Navigation properties:
- `Tenant Tenant` — tenant do którego należy użytkownik.

Metody biznesowe:
- `Deactivate()` — dezaktywacja użytkownika.
- `Activate()` — aktywacja użytkownika.

---

## `Project` (tabela `projects`)
- Klasa: `D2ApiCreator.Domain.Entities.Project`
- Konfiguracja EF: `ProjectConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `tenant_id uuid` : `Guid TenantId` (FK -> tenants.id).
- `source text` : `string Source` — identyfikator pisma, unikalny per tenant.
- `name text` : `string Name` — nazwa pisma.
- `default_template_name text` : `string? DefaultTemplateName`.
- `created_by uuid` : `Guid? CreatedBy` (FK -> users.id).
- `created_at timestamptz` : `DateTime CreatedAt`.
- `retention_days int` : `int RetentionDays` (domyślnie 90).
- `description text` : `string? Description`.
- `current_active_version_id uuid` : `Guid? CurrentActiveVersionId` (cache do szybkiego dostępu).

Cel:
- Rekord nadrzędny dla zestawu wersji dokumentu. Trzyma metadane opisowe i wskazanie aktywnej wersji (kopiowany/aktualizowany przy zmianie aktywnej wersji).

Constraints / indeksy:
- UNIQUE (`tenant_id`, `source`) — enforcement scope per tenant.

Relacje:
- N:1 -> `tenants`
- N:1 -> `users` (creator)
- 1:N -> `project_versions`

Navigation properties:
- `Tenant Tenant`
- `User? Creator`
- `IReadOnlyCollection<ProjectVersion> Versions`

Metody biznesowe:
- `SetActiveVersion(Guid versionId)` — ustawia cache aktywnej wersji.
- `UpdateDescription(string? description)` — aktualizuje opis.
- `UpdateTemplateName(string? templateName)` — aktualizuje nazwę szablonu.

Uwagi:
- `current_active_version_id` jest opcjonalnym cachem i może być utrzymywany przez trigger lub aplikację.

---

## `ProjectVersion` (tabela `project_versions`)
- Klasa: `D2ApiCreator.Domain.Entities.ProjectVersion`
- Konfiguracja EF: `ProjectVersionConfiguration`

Pola (DB : C#):
- `id uuid` : `Guid Id`.
- `project_id uuid` : `Guid ProjectId` (FK -> projects.id).
- `major int` : `int Major`.
- `minor int` : `int Minor`.
- `version_tag text` : `string VersionTag` (np. "1.0").
- `is_active boolean` : `bool IsActive`.
- `status project_status` : `ProjectStatus Status` (enum mapped as string w EF).
- `created_by uuid` : `Guid? CreatedBy`.
- `created_at timestamptz` : `DateTime CreatedAt`.
- `step_data jsonb` : `JsonDocument? StepData` — wolne pole JSONB przechowujące dane etapów kreatora. **[POPRAWKA: inicjalizowane jako JsonDocument.Parse("{}")]**
- `notes text` : `string? Notes`.

Cel / uzasadnienie:
- Każda wersja jest snapshotem kompletnego stanu kreatora dla danego projektu (kroków, mapowań, wskazanych plików).
- `step_data` przechowuje dane poszczególnych kroków (np. krok1: metadane; krok2: wynik parsowania; krok3: mapowania options) w formacie JSON — to umożliwia dodawanie nowych kroków bez zmian schematu.
- Wersje są numerowane major/minor, `version_tag` jest wygodnym przedstawieniem.

Relacje:
- N:1 -> `projects`.
- N:1 -> `users` (creator).
- 1:N -> `files`, `mappings`, `approvals`.

Navigation properties:
- `Project Project`
- `User? Creator`
- `IReadOnlyCollection<FileEntity> Files`
- `IReadOnlyCollection<Mapping> Mappings`
- `IReadOnlyCollection<Approval> Approvals`

Metody biznesowe:
- `Activate()` — aktywuje wersję (zmienia status na Active).
- `Deactivate()` — dezaktywuje wersję (zmienia status na Inactive).
- `UpdateStatus(ProjectStatus status)` — aktualizuje status.
- `UpdateStepData(JsonDocument stepData)` — aktualizuje dane kroków.
- `UpdateNotes(string? notes)` — aktualizuje notatki.

Constraints / indeksy:
- UNIQUE (`project_id`, `version_tag`).
- Partial unique index: `uq_project_active_version` — WHERE `is_active = true` (ensures only one active version per project). **[POPRAWKA: filter syntax]**
- Index: (`project_id`, `created_at`) for fast listing by project's versions.

Operacje typowe:
- Tworzenie nowej wersji (copy-on-write): kopiujemy `project_version` + powiązane `mappings` i `files` (zawartość bytea) do nowego rekordu.
- Ustawienie aktywnej wersji: atomowa transakcja, która wyłącza inne `is_active` i ustawia wybraną wersję jako `is_active=true`. Trigger dodatkowo utrzymuje `projects.current_active_version_id`.

---

## `FileEntity` (tabela `files`)
- Klasa: `D2ApiCreator.Domain.Entities.FileEntity` (zamiast nazwy `File` by uniknąć kolizji)
- Konfiguracja EF: `FileEntityConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId` (FK -> project_versions.id).
- `filename text` : `string Filename`.
- `content bytea` : `byte[]? Content` — przechowuje rzeczywisty plik DOCX w DB.
- `storage_ref text` : `string? StorageRef` (opcjonalne miejsce na przyszłą migrację do S3).
- `content_type text` : `string? ContentType`.
- `size bigint` : `long? Size` — **[POPRAWKA: auto-set from content.Length if null]**.
- `sha256 text` : `string? Sha256` — checksumy dla integralności.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel / uzasadnienie:
- Przechowujemy szablon DOCX w DB jako `bytea` (zgodnie z wymaganiem). Umożliwia to atomowy zapis w transakcji i prosty backup.
- `storage_ref` jest polem zapasowym w przypadku decyzji o przeniesieniu plików do zewnętrznego storage.

Relacje:
- N:1 -> `project_versions`.
- 1:N -> `parse_results`.

Navigation properties:
- `ProjectVersion ProjectVersion`
- `IReadOnlyCollection<ParseResult> ParseResults`

Metody biznesowe:
- `MigrateToExternalStorage(string storageRef)` — migruje plik do S3 i czyści Content.

Indeksy:
- Index on `project_version_id` (szybkie pobieranie plików powiązanych z wersją).

Uwagi:
- Przechowywanie dużych plików może zwiększyć rozmiar DB; rozważ archiwizację / przeniesienie starszych wersji do S3 w przyszłości.

---

## `ParseResult` (tabela `parse_results`)
- Klasa: `D2ApiCreator.Domain.Entities.ParseResult`
- Konfiguracja EF: `ParseResultConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `file_id uuid` : `Guid FileId` (FK -> files.id).
- `parse_json jsonb` : `JsonDocument? ParseJson` — struktura wykrytych znaczników i metadanych szablonu.
- `sample_request jsonb` : `JsonDocument? SampleRequest` — przykładowe dane (fake) dla wygenerowanego ModelRequest.
- `validation_errors jsonb` : `JsonDocument? ValidationErrors` — lista błędów lub ostrzeżeń wykrytych podczas walidacji szablonu.
- `parsed_at timestamptz` : `DateTime ParsedAt`.

Cel:
- Wynik procesu parsowania pliku DOCX (wykryte znaczniki, model request oraz przykładowe dane). Dane przechowujemy jako JSONB, co umożliwia zapytania po strukturze i indeksację GIN.

Relacje:
- N:1 -> `files`.

Navigation properties:
- `FileEntity File`

Metody biznesowe:
- `SetParseResults(JsonDocument? parseJson, JsonDocument? sampleRequest, JsonDocument? validationErrors)` — ustawia wyniki parsowania.

Indexy:
- Index on `file_id`.
- GIN na `parse_json`, `sample_request`, `validation_errors` dla szybkiego wyszukiwania znaczników.

---

## `Mapping` (tabela `mappings`)
- Klasa: `D2ApiCreator.Domain.Entities.Mapping`
- Konfiguracja EF: `MappingConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId` (FK -> project_versions.id).
- `tag_name text` : `string TagName` (np. identyfikator znacznika w dokumencie).
- `mapping_type mapping_type` : `MappingType MappingType` (enum, mapowane jako string w EF).
- `mapping_json jsonb` : `JsonDocument MappingJson` — struktura mapowania (np. JSON Path, expression, static value, lookup config).
- `sort_order int` : `int SortOrder`.
- `created_by uuid` : `Guid? CreatedBy`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Definicja powiązania między wyekstrahowanym znacznikiem a źródłem danych (ModelRequest). Dzięki `mapping_json` model jest elastyczny i rozszerzalny.

Relacje:
- N:1 -> `project_versions`.
- N:1 -> `users` (creator).

Navigation properties:
- `ProjectVersion ProjectVersion`
- `User? Creator`

Metody biznesowe:
- `UpdateMapping(MappingType mappingType, JsonDocument mappingJson)` — aktualizuje mapowanie.
- `UpdateSortOrder(int sortOrder)` — aktualizuje kolejność sortowania.

Indeksy:
- Index on (`project_version_id`, `tag_name`) dla szybkiego wyszukiwania mapowań dla wersji.
- GIN na `mapping_json` dla wyszukiwań i warunków.

Przykład `mapping_json`:
```json
{ "json_path": "$.customer.name", "format": null }
```
lub
```json
{ "value": "Dział Finansów" }
```

---

## `Approval` (tabela `approvals`)
- Klasa: `D2ApiCreator.Domain.Entities.Approval`
- Konfiguracja EF: `ApprovalConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId`.
- `approver_id uuid` : `Guid? ApproverId` (FK -> users.id).
- `status approval_status` : `ApprovalStatus Status` (enum w C#, string w DB). **[POPRAWKA: zmiana ze string? na enum ApprovalStatus]**
- `comment text` : `string? Comment`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Przechowywanie zapytań/rekordów akceptacyjnych (DevOps approval). Przyjęty prosty model wystarcza do audytu i workflow akceptacji.

Relacje:
- N:1 -> `project_versions`.
- N:1 -> `users` (approver).

Navigation properties:
- `ProjectVersion ProjectVersion`
- `User? Approver`

Metody biznesowe:
- `Approve(string? comment = null)` — zatwierdza approval.
- `Reject(string? comment = null)` — odrzuca approval.

---

## `AuditLog` (tabela `audit_log`)
- Klasa: `D2ApiCreator.Domain.Entities.AuditLog`
- Konfiguracja EF: `AuditLogConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `entity text` : `string Entity` — nazwa encji (np. "project", "project_version").
- `entity_id uuid` : `Guid? EntityId`.
- `action text` : `string Action` — co się stało (np. "create_version").
- `payload jsonb` : `JsonDocument? Payload` — dodatkowe dane do reprodukcji zdarzenia.
- `actor_id uuid` : `Guid? ActorId`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Centralne logi audytowe dla krytycznych akcji (tworzenie wersji, ustawienie aktywnej wersji, upload), pomocne w diagnozie i audycie.

Navigation properties:
- Brak (autonomiczna tabela logów).

---

# Zależności i diagram relacji (tekstowy)

Relacje główne (skrót):

```
tenants (1) -> users (N)
tenants (1) -> projects (N)
projects (1) -> project_versions (N)
project_versions (1) -> files (N)
project_versions (1) -> mappings (N)
project_versions (1) -> approvals (N)
files (1) -> parse_results (N)
users (1) -> projects.created_by (N)
users (1) -> project_versions.created_by (N)
users (1) -> mappings.created_by (N)
users (1) -> approvals.approver_id (N)
```

Przykładowy ścieżka: Tenant -> Project -> ProjectVersion -> File -> ParseResult

---

# Poprawki wprowadzone w refaktoringu (2025-11-19)

1. **Tenant.Metadata**: zmiana typu z `JsonElement?` na `JsonDocument?` dla spójności.
2. **Approval.Status**: zmiana z `string?` na `ApprovalStatus` enum (dodano enum w `D2ApiCreator.Domain.Enums`).
3. **ProjectVersion.StepData**: inicjalizacja jako `JsonDocument.Parse("{}")` zamiast `default`.
4. **FileEntity.Size**: auto-set z `content?.Length` jeśli nie podano.
5. **Navigation properties**: dodane do wszystkich encji dla relacji EF Core.
6. **Metody biznesowe**: dodane w encjach (Activate, Deactivate, UpdateStatus, Approve, Reject, UpdateMapping itp.) zgodnie z DDD.
7. **EF Core configurations**: dodano relationships (HasOne/WithMany) w każdej konfiguracji.
8. **Partial unique index filter**: poprawka składni z `HasFilter("is_active")` na `HasFilter("is_active = true")`.
9. **ApplicationDbContext**: dodano DbSet<> dla wszystkich encji.

---

# Dlaczego tak zaprojektowano?
- Snapshot wersji (copy-on-write) daje prosty model audytowalny i łatwy rollback do poprzedniej wersji. Ułatwia też wdrażanie zmian w kreatorze bez ryzyka zepsucia historii.
- `step_data` jako `jsonb` zapewnia elastyczność: dodanie nowego kroku kreatora zwykle nie wymaga modyfikacji schematu bazy.
- `bytea` dla plików daje prostą spójność transakcyjną—upload pliku i zapis metadanych w jednej transakcji jest proste i bezpieczne. Jeśli rozmiary plików zaczną być problemem, pole `storage_ref` już jest przygotowane do migracji do S3.
- Mapowania jako `mapping_json` (jsonb) i `mapping_type` enum umożliwiają przechowywanie różnorodnych strategii mapowania bez zmian schematu.
- Partial unique index + trigger zapewniają silne gwarancje biznesowe (jedna aktywna wersja) i upraszczają pobieranie "active" bez kosztownych zapytań.
- **Navigation properties** umożliwiają łatwe traverse po relacjach w kodzie (Include, lazy loading opcjonalnie).
- **Metody biznesowe w encjach** (DDD) chronią spójność i enkapsulują logikę domenową.

---

# Miejsca w kodzie do dalszych rozszerzeń
- Worker parsujący DOCX -> `D2ApiCreator.Infrastructure/Services/` (zalecane: dodać `Job` table i `IHostedService` implementację)
- Serwis wersjonowania (kopiowanie mappings/files) -> `D2ApiCreator.Infrastructure/Services/VersioningService.cs`
- Repositories -> `D2ApiCreator.Infrastructure/Persistence/Repositories/` (można dodać specyficzne repozytoria dla `Project` i `ProjectVersion`)

---

# Szybkie odniesienia plikowe
- DDL (pełny): `D2ApiCreator.Infrastructure/Database/init_schema_d2api.sql`
- Flyway: `D2ApiCreator.Infrastructure/Database/Flyway/V1__init_schema_d2api.sql`
- Konfiguracje EF Core: `D2ApiCreator.Infrastructure/Persistence/Configurations/*.cs`
- Encje domenowe: `D2ApiCreator.Domain/Entities/*.cs`
- Enumy: `D2ApiCreator.Domain/Enums/*.cs` (ProjectStatus, MappingType, ApprovalStatus)
- ApplicationDbContext: `D2ApiCreator.Infrastructure/Persistence/ApplicationDbContext.cs`

---

**Status**: Model encji jest kompletny, przetestowany pod kątem kompilacji i gotowy do użycia. Następne kroki: worker parsujący, serwisy domenowe, testy integracyjne.

Uwaga: pliki z implementacją można znaleźć w repozytorium:
- encje domenowe: `D2ApiCreator.Domain/Entities/`
- konfiguracje EF Core: `D2ApiCreator.Infrastructure/Persistence/Configurations/`
- DDL / Flyway: `D2ApiCreator.Infrastructure/Database/init_schema_d2api.sql` i `.../Flyway/V1__init_schema_d2api.sql`.

---

## Zasady projektowe (krótkie przypomnienie)
- Główne Id używamy jako `uuid` (PG) i `Guid` w C#.
- Pliki DOCX są przechowywane jako `bytea` w kolumnie `files.content` (mapowane do `byte[]` w C#).
- Dane kroków kreatora przechowujemy w `project_versions.step_data` typu `jsonb` (w C# mapowane jako `JsonDocument`).
- Wersjonowanie: snapshot per version (copy-on-write) — pełne kopiowanie powiązanych danych (mappings, pliki) przy tworzeniu nowej wersji.
- Jedna aktywna wersja na projekt: `project_versions.is_active` + partial unique index + trigger zapewniający spójność.

---

# Lista encji i opis

Poniżej opisy każdej encji: tabela DB, klasa domenowa, pola, zależności i uwagi.

---

## `Tenant` (tabela `tenants`)
- Klasa: `D2ApiCreator.Domain.Entities.Tenant`
- Konfiguracja EF: `TenantConfiguration` (`D2ApiCreator.Infrastructure/Persistence/Configurations/TenantConfiguration.cs`)

Pola (DB : C#):
- `id uuid` : `Guid Id` — PK, domyślnie `gen_random_uuid()` po stronie DB.
- `name text` : `string Name` — nazwa tenanta.
- `metadata jsonb` : `JsonElement? Metadata` — dodatkowe metadane (opcjonalne).
- `created_at timestamptz` : `DateTime CreatedAt` — data utworzenia.

Cel / uzasadnienie:
- Izolacja danych wieloznaczna: tenanty grupują projekty i użytkowników.

Relacje:
- 1:N -> `projects` (projects.tenant_id).
- 1:N -> `users` (users.tenant_id).

Uwagi:
- Tabela lekka, może zawierać dodatkowe metadane JSON dla integracji.

---

## `User` (tabela `users`)
- Klasa: `D2ApiCreator.Domain.Entities.User`
- Konfiguracja EF: `UserConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `tenant_id uuid` : `Guid TenantId` (FK -> tenants.id).
- `username text` : `string Username` (unikalne per tenant).
- `email text` : `string? Email`.
- `display_name text` : `string? DisplayName`.
- `is_active boolean` : `bool IsActive`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Reprezentuje użytkownika aplikacji; używany jako referencja w `created_by` oraz `approver_id`.

Indeksy / constraints:
- UNIQUE (`tenant_id`, `username`) — zapewnia unikalne nazwy w ramach tenant.

---

## `Project` (tabela `projects`)
- Klasa: `D2ApiCreator.Domain.Entities.Project`
- Konfiguracja EF: `ProjectConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `tenant_id uuid` : `Guid TenantId` (FK -> tenants.id).
- `source text` : `string Source` — identyfikator pisma, unikalny per tenant.
- `name text` : `string Name` — nazwa pisma.
- `default_template_name text` : `string? DefaultTemplateName`.
- `created_by uuid` : `Guid? CreatedBy` (FK -> users.id).
- `created_at timestamptz` : `DateTime CreatedAt`.
- `retention_days int` : `int RetentionDays` (domyślnie 90).
- `description text` : `string? Description`.
- `current_active_version_id uuid` : `Guid? CurrentActiveVersionId` (cache do szybkiego dostępu).

Cel:
- Rekord nadrzędny dla zestawu wersji dokumentu. Trzyma metadane opisowe i wskazanie aktywnej wersji (kopiowany/aktualizowany przy zmianie aktywnej wersji).

Constraints / indeksy:
- UNIQUE (`tenant_id`, `source`) — enforcement scope per tenant.

Relacje:
- 1:N -> `project_versions` (project_versions.project_id).

Uwagi:
- `current_active_version_id` jest opcjonalnym cachem i może być utrzymywany przez trigger lub aplikację.

---

## `ProjectVersion` (tabela `project_versions`)
- Klasa: `D2ApiCreator.Domain.Entities.ProjectVersion`
- Konfiguracja EF: `ProjectVersionConfiguration`

Pola (DB : C#):
- `id uuid` : `Guid Id`.
- `project_id uuid` : `Guid ProjectId` (FK -> projects.id).
- `major int` : `int Major`.
- `minor int` : `int Minor`.
- `version_tag text` : `string VersionTag` (np. "1.0").
- `is_active boolean` : `bool IsActive`.
- `status project_status` : `ProjectStatus Status` (enum mapped as string w EF).
- `created_by uuid` : `Guid? CreatedBy`.
- `created_at timestamptz` : `DateTime CreatedAt`.
- `step_data jsonb` : `JsonDocument? StepData` — wolne pole JSONB przechowujące dane etapów kreatora.
- `notes text` : `string? Notes`.

Cel / uzasadnienie:
- Każda wersja jest snapshotem kompletnego stanu kreatora dla danego projektu (kroków, mapowań, wskazanych plików).
- `step_data` przechowuje dane poszczególnych kroków (np. krok1: metadane; krok2: wynik parsowania; krok3: mapowania options) w formacie JSON — to umożliwia dodawanie nowych kroków bez zmian schematu.
- Wersje są numerowane major/minor, `version_tag` jest wygodnym przedstawieniem.

Relacje:
- N:1 -> `projects`.
- 1:N -> `files`, `mappings`, `approvals`.

Constraints / indeksy:
- UNIQUE (`project_id`, `version_tag`).
- Partial unique index: `uq_project_active_version` (ensures only one row with `is_active = true` per `project_id`).
- Index: (`project_id`, `created_at`) for fast listing by project's versions.

Operacje typowe:
- Tworzenie nowej wersji (copy-on-write): kopiujemy `project_version` + powiązane `mappings` i `files` (zawartość bytea) do nowego rekordu.
- Ustawienie aktywnej wersji: atomowa transakcja, która wyłącza inne `is_active` i ustawia wybraną wersję jako `is_active=true`. Trigger dodatkowo utrzymuje `projects.current_active_version_id`.

---

## `FileEntity` (tabela `files`)
- Klasa: `D2ApiCreator.Domain.Entities.FileEntity` (zamiast nazwy `File` by uniknąć kolizji)
- Konfiguracja EF: `FileEntityConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId` (FK -> project_versions.id).
- `filename text` : `string Filename`.
- `content bytea` : `byte[]? Content` — przechowuje rzeczywisty plik DOCX w DB.
- `storage_ref text` : `string? StorageRef` (opcjonalne miejsce na przyszłą migrację do S3).
- `content_type text` : `string? ContentType`.
- `size bigint` : `long? Size`.
- `sha256 text` : `string? Sha256` — checksumy dla integralności.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel / uzasadnienie:
- Przechowujemy szablon DOCX w DB jako `bytea` (tak zażyczyłeś). Umożliwia to atomowy zapis w transakcji i prosty backup.
- `storage_ref` jest polem zapasowym w przypadku decyzji o przeniesieniu plików do zewnętrznego storage.

Relacje:
- N:1 -> `project_versions`.
- 1:1/1:N -> `parse_results` (może być wiele wyników parsowania, choć obecny model zakłada pojedynczy najnowszy wynik powiązany z plikiem).

Indeksy:
- Index on `project_version_id` (szybkie pobieranie plików powiązanych z wersją).

Uwagi:
- Przechowywanie dużych plików może zwiększyć rozmiar DB; rozważ archiwizację / przeniesienie starszych wersji do S3 w przyszłości.

---

## `ParseResult` (tabela `parse_results`)
- Klasa: `D2ApiCreator.Domain.Entities.ParseResult`
- Konfiguracja EF: `ParseResultConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `file_id uuid` : `Guid FileId` (FK -> files.id).
- `parse_json jsonb` : `JsonDocument? ParseJson` — struktura wykrytych znaczników i metadanych szablonu.
- `sample_request jsonb` : `JsonDocument? SampleRequest` — przykładowe dane (fake) dla wygenerowanego ModelRequest.
- `validation_errors jsonb` : `JsonDocument? ValidationErrors` — lista błędów lub ostrzeżeń wykrytych podczas walidacji szablonu.
- `parsed_at timestamptz` : `DateTime ParsedAt`.

Cel:
- Wynik procesu parsowania pliku DOCX (wykryte znaczniki, model request oraz przykładowe dane). Dane przechowujemy jako JSONB, co umożliwia zapytania po strukturze i indeksację GIN.

Relacje:
- N:1 -> `files`.

Indexy:
- GIN na `parse_json` dla szybkiego wyszukiwania znaczników.

---

## `Mapping` (tabela `mappings`)
- Klasa: `D2ApiCreator.Domain.Entities.Mapping`
- Konfiguracja EF: `MappingConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId` (FK -> project_versions.id).
- `tag_name text` : `string TagName` (np. identyfikator znacznika w dokumencie).
- `mapping_type mapping_type` : `MappingType MappingType` (enum, mapowane jako string w EF).
- `mapping_json jsonb` : `JsonDocument MappingJson` — struktura mapowania (np. JSON Path, expression, static value, lookup config).
- `sort_order int` : `int SortOrder`.
- `created_by uuid` : `Guid? CreatedBy`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Definicja powiązania między wyekstrahowanym znacznikiem a źródłem danych (ModelRequest). Dzięki `mapping_json` model jest elastyczny i rozszerzalny.

Indeksy:
- Index on (`project_version_id`, `tag_name`) dla szybkiego wyszukiwania mapowań dla wersji.
- GIN na `mapping_json` dla wyszukiwań i warunków.

Przykład `mapping_json`:
```json
{ "json_path": "$.customer.name", "format": null }
```
lub
```json
{ "value": "Dział Finansów" }
```

---

## `Approval` (tabela `approvals`)
- Klasa: `D2ApiCreator.Domain.Entities.Approval`
- Konfiguracja EF: `ApprovalConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `project_version_id uuid` : `Guid ProjectVersionId`.
- `approver_id uuid` : `Guid? ApproverId` (FK -> users.id).
- `status approval_status` : `string? Status` (w implementacji domenowej obecnie string; w DB enum `approval_status`).
- `comment text` : `string? Comment`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Przechowywanie zapytań/rekordów akceptacyjnych (DevOps approval). Przyjęty prosty model wystarcza do audytu i workflow akceptacji.

---

## `AuditLog` (tabela `audit_log`)
- Klasa: `D2ApiCreator.Domain.Entities.AuditLog`
- Konfiguracja EF: `AuditLogConfiguration`

Pola:
- `id uuid` : `Guid Id`.
- `entity text` : `string Entity` — nazwa encji (np. "project", "project_version").
- `entity_id uuid` : `Guid? EntityId`.
- `action text` : `string Action` — co się stało (np. "create_version").
- `payload jsonb` : `JsonDocument? Payload` — dodatkowe dane do reprodukcji zdarzenia.
- `actor_id uuid` : `Guid? ActorId`.
- `created_at timestamptz` : `DateTime CreatedAt`.

Cel:
- Centralne logi audytowe dla krytycznych akcji (tworzenie wersji, ustawienie aktywnej wersji, upload), pomocne w diagnozie i audycie.

---

# Zależności i diagram relacji (tekstowy)

Relacje główne (skrót):

- `tenants (1) -> users (N)`
- `tenants (1) -> projects (N)`
- `projects (1) -> project_versions (N)`
- `project_versions (1) -> files (N)`
- `files (1) -> parse_results (N)`
- `project_versions (1) -> mappings (N)`
- `project_versions (1) -> approvals (N)`

Przykładowy ścieżka: Tenant -> Project -> ProjectVersion -> File -> ParseResult

---

# Dlaczego tak zaprojektowano?
- Snapshot wersji (copy-on-write) daje prosty model audytowalny i łatwy rollback do poprzedniej wersji. Ułatwia też wdrażanie zmian w kreatorze bez ryzyka zepsucia historii.
- `step_data` jako `jsonb` zapewnia elastyczność: dodanie nowego kroku kreatora zwykle nie wymaga modyfikacji schematu bazy.
- `bytea` dla plików daje prostą spójność transakcyjną—upload pliku i zapis metadanych w jednej transakcji jest proste i bezpieczne. Jeśli rozmiary plików zaczną być problemem, pole `storage_ref` już jest przygotowane do migracji do S3.
- Mapowania jako `mapping_json` (jsonb) i `mapping_type` enum umożliwiają przechowywanie różnorodnych strategii mapowania bez zmian schematu.
- Partial unique index + trigger zapewniają silne gwarancje biznesowe (jedna aktywna wersja) i upraszczają pobieranie "active" bez kosztownych zapytań.

---

# Miejsca w kodzie do dalszych rozszerzeń
- Worker parsujący DOCX -> `D2ApiCreator.Infrastructure/Services/` (zalecane: dodać `Job` table i `IHostedService` implementację)
- Serwis wersjonowania (kopiowanie mappings/files) -> `D2ApiCreator.Infrastructure/Services/VersioningService.cs`
- Repositories -> `D2ApiCreator.Infrastructure/Persistence/Repositories/` (można dodać specyficzne repozytoria dla `Project` i `ProjectVersion`)

---

# Szybkie odniesienia plikowe
- DDL (pełny): `D2ApiCreator.Infrastructure/Database/init_schema_d2api.sql`
- Flyway: `D2ApiCreator.Infrastructure/Database/Flyway/V1__init_schema_d2api.sql`
- Konfiguracje EF Core: `D2ApiCreator.Infrastructure/Persistence/Configurations/*.cs`
- Encje domenowe: `D2ApiCreator.Domain/Entities/*.cs`

---

Jeśli chcesz, mogę teraz:
- dodać diagram ER (PNG) do repo z wygenerowanym obrazem; lub
- utworzyć `VersioningService` + `Jobs` table + prostego `IHostedService` worker do parsowania plików; lub
- wygenerować dokumentację API opisującą endpointy potrzebne do CRUD projektów i operacji wersji.

Powiedz, który z tych kroków wykonać dalej.
