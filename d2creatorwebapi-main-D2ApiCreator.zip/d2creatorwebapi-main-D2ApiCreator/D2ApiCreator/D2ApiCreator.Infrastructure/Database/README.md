D2ApiCreator - Database folder

Ten folder zawiera SQL inicjalizacyjny oraz skrypt Flyway dla modułu kreatora pism.

Pliki:
- init_schema_d2api.sql - idempotentny skrypt DDL tworzący wszystkie tabele, enumy, indeksy i trigger.
- Flyway/V1__init_schema_d2api.sql - wersja Flyway (migracja V1). Upewnij się, że zawiera pełne DDL przed wdrożeniem.

Instrukcja użycia (lokalnie, wymagany flyway):
1) Skonfiguruj plik flyway.conf z parametrami połączenia do DB.
2) Umieść plik V1__init_schema_d2api.sql w katalogu migracji Flyway.
3) Uruchom: flyway migrate

Uwaga:
- Skrypt używa rozszerzenia pgcrypto do gen_random_uuid(). Upewnij się, że masz prawa do CREATE EXTENSION jeśli uruchamiasz go na docelowej bazie.
- Pliki DOCX są przechowywane jako bytea w tabeli `files.content`.
- Triggery i partial unique index zapewniają jedną aktywną wersję na projekt.

Przydatne komendy SQL (psql):
- \\i init_schema_d2api.sql -- uruchom skrypt w psql

Autor: D2ApiCreator schema generator

