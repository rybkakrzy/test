# Quick Start Guide

## Uruchomienie projektu w 5 krokach

### 1. Uruchom PostgreSQL przez Docker

```powershell
docker-compose up -d
```

To uruchomi:
- PostgreSQL na porcie 5432
- pgAdmin na porcie 5050 (http://localhost:5050)
  - Email: admin@d2creator.com
  - Hasło: admin

### 2. Uruchom migracje bazy danych

```powershell
cd D2ApiCreator.Api
dotnet ef database update --project ..\D2ApiCreator.Infrastructure
```

Jeśli nie masz jeszcze żadnych migracji, stwórz pierwszą:

```powershell
dotnet ef migrations add InitialCreate --project ..\D2ApiCreator.Infrastructure
```

### 3. Uruchom aplikację

```powershell
cd D2ApiCreator.Api
dotnet run
```

lub w trybie watch (auto-reload):

```powershell
dotnet watch run
```

### 4. Otwórz Swagger UI

Przejdź do: `https://localhost:5001/swagger`

### 5. Przetestuj API

#### Przykładowe endpointy:

**Health Check:**
```
GET https://localhost:5001/api/health
```

**Example Query:**
```
GET https://localhost:5001/api/examples/YourName
```

lub

```
GET https://localhost:5001/api/examples?name=YourName
```

## Uruchomienie testów

### Wszystkie testy
```powershell
dotnet test
```

### Tylko testy jednostkowe
```powershell
dotnet test D2ApiCreator.Tests.Unit
```

### Tylko testy integracyjne
```powershell
dotnet test D2ApiCreator.Tests.Integration
```

## Dodanie nowego Feature (CQRS)

### 1. Stwórz Query/Command

W `D2ApiCreator.Application/Features/YourFeature/Queries/`:

```csharp
public record GetYourDataQuery : IRequest<YourResponse>
{
    public Guid Id { get; init; }
}

public record YourResponse
{
    public Guid Id { get; init; }
    public string Name { get; init; }
}
```

### 2. Stwórz Handler

```csharp
public class GetYourDataQueryHandler : IRequestHandler<GetYourDataQuery, YourResponse>
{
    public async Task<YourResponse> Handle(GetYourDataQuery request, CancellationToken cancellationToken)
    {
        // Your logic here
        return new YourResponse();
    }
}
```

### 3. Dodaj Validator

```csharp
public class GetYourDataQueryValidator : AbstractValidator<GetYourDataQuery>
{
    public GetYourDataQueryValidator()
    {
        RuleFor(x => x.Id).NotEmpty();
    }
}
```

### 4. Stwórz Controller

```csharp
public class YourController : BaseApiController
{
    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var query = new GetYourDataQuery { Id = id };
        var result = await Mediator.Send(query);
        return Ok(result);
    }
}
```

## Dodanie nowego Aggregate Root

### 1. Stwórz Entity w Domain

`D2ApiCreator.Domain/Entities/YourEntity.cs`:

```csharp
public class YourEntity : AggregateRoot<Guid>
{
    public string Name { get; private set; }
    
    private YourEntity() { }
    
    public static YourEntity Create(string name)
    {
        var entity = new YourEntity
        {
            Id = Guid.NewGuid(),
            Name = name
        };
        
        // Add domain event if needed
        // entity.AddDomainEvent(new YourEntityCreatedEvent(entity.Id));
        
        return entity;
    }
}
```

### 2. Dodaj Repository Interface

`D2ApiCreator.Domain/Repositories/IYourRepository.cs`:

```csharp
public interface IYourRepository : IRepository<YourEntity, Guid>
{
    // Add custom methods
}
```

### 3. Dodaj EF Configuration

`D2ApiCreator.Infrastructure/Persistence/Configurations/YourEntityConfiguration.cs`:

```csharp
public class YourEntityConfiguration : IEntityTypeConfiguration<YourEntity>
{
    public void Configure(EntityTypeBuilder<YourEntity> builder)
    {
        builder.ToTable("YourEntities");
        
        builder.HasKey(e => e.Id);
        
        builder.Property(e => e.Name)
            .IsRequired()
            .HasMaxLength(200);
    }
}
```

### 4. Dodaj DbSet w ApplicationDbContext

```csharp
public DbSet<YourEntity> YourEntities { get; set; }
```

### 5. Stwórz Migration

```powershell
dotnet ef migrations add AddYourEntity --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
dotnet ef database update --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
```

## Przydatne komendy

### Entity Framework

```powershell
# Dodaj nową migrację
dotnet ef migrations add MigrationName --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api

# Zaktualizuj bazę danych
dotnet ef database update --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api

# Cofnij ostatnią migrację
dotnet ef migrations remove --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api

# Zobacz SQL dla migracji
dotnet ef migrations script --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
```

### Docker

```powershell
# Uruchom kontenery
docker-compose up -d

# Zatrzymaj kontenery
docker-compose down

# Zobacz logi
docker-compose logs -f

# Zatrzymaj i usuń dane
docker-compose down -v
```

## Troubleshooting

### Problem z połączeniem do PostgreSQL

1. Sprawdź czy kontener działa:
```powershell
docker ps
```

2. Sprawdź logi:
```powershell
docker-compose logs postgres
```

3. Sprawdź connection string w `appsettings.json`

### Problem z migracjami

1. Usuń folder Migrations i bazę danych
2. Stwórz nową migrację od zera:
```powershell
dotnet ef migrations add InitialCreate --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
dotnet ef database update --project D2ApiCreator.Infrastructure --startup-project D2ApiCreator.Api
```

### Problem z NuGet packages

```powershell
dotnet restore
dotnet clean
dotnet build
```

