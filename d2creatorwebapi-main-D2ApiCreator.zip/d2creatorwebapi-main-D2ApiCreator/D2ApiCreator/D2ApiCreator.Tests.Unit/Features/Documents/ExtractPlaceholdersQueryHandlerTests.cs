using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Application.Features.Documents.Queries.ExtractPlaceholders;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using NSubstitute;

namespace D2ApiCreator.Tests.Unit.Features.Documents;

/// <summary>
/// Unit tests for ExtractPlaceholdersQueryHandler
/// </summary>
public class ExtractPlaceholdersQueryHandlerTests
{
    private readonly IDocumentPlaceholderService _documentPlaceholderService;
    private readonly ILogger<ExtractPlaceholdersQueryHandler> _logger;
    private readonly ExtractPlaceholdersQueryHandler _sut;

    public ExtractPlaceholdersQueryHandlerTests()
    {
        _documentPlaceholderService = Substitute.For<IDocumentPlaceholderService>();
        _logger = Substitute.For<ILogger<ExtractPlaceholdersQueryHandler>>();
        _sut = new ExtractPlaceholdersQueryHandler(_documentPlaceholderService, _logger);
    }

    [Fact]
    public async Task Handle_WithValidQuery_ShouldReturnDto()
    {
        // Arrange
        var stream = new MemoryStream();
        var fileName = "test.docx";
        var placeholders = new List<string> { "<%name%>", "<%email%>" };

        _documentPlaceholderService
            .ExtractPlaceholdersFromDocxAsync(stream, fileName)
            .Returns(placeholders);

        var query = new ExtractPlaceholdersQuery
        {
            FileStream = stream,
            FileName = fileName
        };

        // Act
        var result = await _sut.Handle(query, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Placeholders.Should().BeEquivalentTo(placeholders);
        result.TotalCount.Should().Be(2);
        result.FileName.Should().Be(fileName);
    }

    [Fact]
    public async Task Handle_ShouldCallServiceWithCorrectParameters()
    {
        // Arrange
        var stream = new MemoryStream();
        var fileName = "document.docx";
        var placeholders = new List<string> { "<%test%>" };

        _documentPlaceholderService
            .ExtractPlaceholdersFromDocxAsync(Arg.Any<Stream>(), Arg.Any<string>())
            .Returns(placeholders);

        var query = new ExtractPlaceholdersQuery
        {
            FileStream = stream,
            FileName = fileName
        };

        // Act
        await _sut.Handle(query, CancellationToken.None);

        // Assert
        await _documentPlaceholderService.Received(1).ExtractPlaceholdersFromDocxAsync(stream, fileName);
    }

    [Fact]
    public async Task Handle_WithEmptyPlaceholders_ShouldReturnEmptyDto()
    {
        // Arrange
        var stream = new MemoryStream();
        var fileName = "empty.docx";
        var placeholders = new List<string>();

        _documentPlaceholderService
            .ExtractPlaceholdersFromDocxAsync(stream, fileName)
            .Returns(placeholders);

        var query = new ExtractPlaceholdersQuery
        {
            FileStream = stream,
            FileName = fileName
        };

        // Act
        var result = await _sut.Handle(query, CancellationToken.None);

        // Assert
        result.Should().NotBeNull();
        result.Placeholders.Should().BeEmpty();
        result.TotalCount.Should().Be(0);
        result.FileName.Should().Be(fileName);
    }

    [Fact]
    public async Task Handle_ShouldLogInformation()
    {
        // Arrange
        var stream = new MemoryStream();
        var fileName = "test.docx";
        var placeholders = new List<string> { "<%test%>" };

        _documentPlaceholderService
            .ExtractPlaceholdersFromDocxAsync(stream, fileName)
            .Returns(placeholders);

        var query = new ExtractPlaceholdersQuery
        {
            FileStream = stream,
            FileName = fileName
        };

        // Act
        await _sut.Handle(query, CancellationToken.None);

        // Assert
        _logger.Received(1).Log(
            LogLevel.Information,
            Arg.Any<EventId>(),
            Arg.Is<object>(o => o.ToString()!.Contains("Extracting placeholders")),
            Arg.Any<Exception>(),
            Arg.Any<Func<object, Exception?, string>>());
    }

    [Fact]
    public async Task Handle_WithMultiplePlaceholders_ShouldReturnCorrectCount()
    {
        // Arrange
        var stream = new MemoryStream();
        var fileName = "multi.docx";
        var placeholders = new List<string> 
        { 
            "<%name%>", 
            "<%email%>", 
            "<%phone%>", 
            "<%address%>", 
            "<%city%>" 
        };

        _documentPlaceholderService
            .ExtractPlaceholdersFromDocxAsync(stream, fileName)
            .Returns(placeholders);

        var query = new ExtractPlaceholdersQuery
        {
            FileStream = stream,
            FileName = fileName
        };

        // Act
        var result = await _sut.Handle(query, CancellationToken.None);

        // Assert
        result.TotalCount.Should().Be(5);
        result.Placeholders.Should().HaveCount(5);
    }
}

