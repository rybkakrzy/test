# 🔐 Zarządzanie Secretami w D2ApiCreator

## 📋 Przegląd

Projekt wykorzystuje **hierarchiczny system konfiguracji** .NET:
1. `appsettings.json` - Podstawowa konfiguracja (BEZ secretów!)
2. `appsettings.Development.json` - Development (lokalne hasła OK)
3. `appsettings.Production.json` - Production (puste connection stringi)
4. **User Secrets** - Lokalne sekrety developera (NIE trafiają do Git!)
5. **Environment Variables** - Production secrets (Azure, Docker, etc.)

---

## 🔧 User Secrets (Development)

### Co to jest?
User Secrets to bezpieczny sposób przechowywania lokalnych secretów poza projektem.
Pliki są w: `%APPDATA%\Microsoft\UserSecrets\{UserSecretsId}\secrets.json`

### Inicjalizacja (już zrobione!)
```powershell
cd D2ApiCreator.Api
dotnet user-secrets init
```

### Ustawianie secretów

#### Connection String do PostgreSQL
```powershell
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=twoje_haslo"
```

#### Inne przykłady
```powershell
# JWT Secret
dotnet user-secrets set "Jwt:Secret" "super-secret-key-min-32-chars-long"

# External API Keys
dotnet user-secrets set "ExternalApi:ApiKey" "your-api-key-here"

# Email Settings
dotnet user-secrets set "Email:Password" "your-email-password"
```

### Przeglądanie secretów
```powershell
# Lista wszystkich
dotnet user-secrets list

# Usunięcie konkretnego
dotnet user-secrets remove "ConnectionStrings:DefaultConnection"

# Wyczyszczenie wszystkich
dotnet user-secrets clear
```

---

## 🐳 Docker (Development)

### docker-compose.yml zawiera wszystkie sekrety
```yaml
environment:
  POSTGRES_PASSWORD: postgres
```

### Connection string dla Docker
```powershell
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=postgres"
```

---

## ☁️ Production (Azure, AWS, etc.)

### Azure App Service

#### Przez Portal
1. Idź do: App Service → Configuration → Application settings
2. Dodaj nowy:
   - Name: `ConnectionStrings__DefaultConnection`
   - Value: `Host=your-server;Port=5432;Database=D2CreatorDb;Username=user;Password=***`

#### Przez Azure CLI
```bash
az webapp config connection-string set \
  --name your-app-name \
  --resource-group your-rg \
  --connection-string-type PostgreSQL \
  --settings DefaultConnection="Host=..."
```

#### Przez Azure Key Vault (RECOMMENDED!)
```bash
# 1. Dodaj secret do Key Vault
az keyvault secret set \
  --vault-name your-vault \
  --name "DbConnectionString" \
  --value "Host=..."

# 2. Użyj referencji w App Service
@Microsoft.KeyVault(SecretUri=https://your-vault.vault.azure.net/secrets/DbConnectionString/)
```

### Docker Production

#### docker-compose.production.yml
```yaml
services:
  api:
    environment:
      - ConnectionStrings__DefaultConnection=${DB_CONNECTION_STRING}
      - ASPNETCORE_ENVIRONMENT=Production
```

#### .env file (NIE commituj do Git!)
```env
DB_CONNECTION_STRING=Host=postgres;Port=5432;Database=D2CreatorDb;Username=postgres;Password=secure_password
```

#### Uruchomienie
```bash
docker-compose -f docker-compose.production.yml --env-file .env.production up -d
```

### Kubernetes

#### Secret
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: d2creator-secrets
type: Opaque
stringData:
  connection-string: "Host=postgres;Port=5432;Database=D2CreatorDb;Username=postgres;Password=***"
```

#### Deployment
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: d2creator-api
spec:
  template:
    spec:
      containers:
      - name: api
        env:
        - name: ConnectionStrings__DefaultConnection
          valueFrom:
            secretKeyRef:
              name: d2creator-secrets
              key: connection-string
```

---

## 🔒 Best Practices

### ✅ DO:
- Używaj User Secrets dla local development
- Używaj Environment Variables w production
- Używaj Azure Key Vault / AWS Secrets Manager dla production
- Przechowuj różne hasła dla dev/staging/prod
- Rotuj hasła regularnie
- Używaj Managed Identity gdzie możliwe (Azure)

### ❌ DON'T:
- NIE commituj `appsettings.Development.json` z hasłami do Git
- NIE hardcoduj secretów w kodzie
- NIE używaj tych samych haseł dev/prod
- NIE udostępniaj User Secrets między developerami
- NIE loguj connection stringów

---

## 📝 Hierarchia Konfiguracji (.NET)

Kolejność ładowania (później = wyższy priorytet):

1. `appsettings.json`
2. `appsettings.{Environment}.json`
3. **User Secrets** (Development only)
4. **Environment Variables**
5. **Command-line arguments**

### Przykład nadpisywania

**appsettings.json:**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;..."
  }
}
```

**User Secrets (Development):**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Password=dev_password"
  }
}
```

**Environment Variable (Production):**
```bash
export ConnectionStrings__DefaultConnection="Host=prod-server;Password=prod_password"
```

---

## 🛠️ Komendy Pomocnicze

### Sprawdzenie aktualnej konfiguracji
```csharp
// W Program.cs lub kontrolerze (tylko Development!)
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
Console.WriteLine($"Using connection: {connectionString}");
```

### Debugging konfiguracji
```powershell
# Zobacz wszystkie źródła konfiguracji
dotnet run --configuration Debug

# Sprawdź user secrets
dotnet user-secrets list

# Sprawdź zmienne środowiskowe
Get-ChildItem Env: | Where-Object { $_.Name -like "*ConnectionStrings*" }
```

---

## 📚 Przykładowe Scenariusze

### Scenariusz 1: Nowy developer w zespole

```powershell
# 1. Sklonuj repo
git clone https://github.com/your-repo/D2ApiCreator.git
cd D2ApiCreator/D2ApiCreator.Api

# 2. Ustaw swoje lokalne hasło
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=D2CreatorDb;Username=postgres;Password=my_password"

# 3. Uruchom
dotnet run
```

### Scenariusz 2: Deploy do Azure

```bash
# 1. Stwórz Key Vault
az keyvault create --name d2creator-kv --resource-group d2creator-rg

# 2. Dodaj secret
az keyvault secret set --vault-name d2creator-kv --name "DbConnectionString" --value "Host=..."

# 3. Skonfiguruj App Service
az webapp config appsettings set \
  --name d2creator-api \
  --resource-group d2creator-rg \
  --settings ConnectionStrings__DefaultConnection="@Microsoft.KeyVault(SecretUri=https://d2creator-kv.vault.azure.net/secrets/DbConnectionString/)"
```

### Scenariusz 3: CI/CD Pipeline

```yaml
# GitHub Actions / Azure DevOps
steps:
  - name: Deploy to Azure
    env:
      CONNECTION_STRING: ${{ secrets.DB_CONNECTION_STRING }}
    run: |
      az webapp config appsettings set \
        --settings ConnectionStrings__DefaultConnection="$CONNECTION_STRING"
```

---

## ⚠️ Troubleshooting

### Problem: Connection string nie działa

1. Sprawdź kolejność:
```powershell
dotnet user-secrets list
echo $env:ConnectionStrings__DefaultConnection
```

2. Sprawdź czy User Secrets jest zainicjalizowany:
```powershell
# Powinien być UserSecretsId w .csproj
Get-Content D2ApiCreator.Api.csproj | Select-String "UserSecretsId"
```

3. Sprawdź format environment variable:
```bash
# ✅ Poprawnie (double underscore!)
ConnectionStrings__DefaultConnection

# ❌ Źle
ConnectionStrings:DefaultConnection
```

### Problem: User Secrets nie ładuje się

Sprawdź czy jesteś w trybie Development:
```bash
$env:ASPNETCORE_ENVIRONMENT = "Development"
dotnet run
```

---

## 🎯 Quick Reference

### User Secrets Commands
```powershell
dotnet user-secrets init                    # Inicjalizacja
dotnet user-secrets set "key" "value"       # Dodaj/Zmień
dotnet user-secrets list                    # Lista wszystkich
dotnet user-secrets remove "key"            # Usuń jeden
dotnet user-secrets clear                   # Usuń wszystkie
```

### Environment Variables (PowerShell)
```powershell
$env:ConnectionStrings__DefaultConnection = "Host=..."
$env:ASPNETCORE_ENVIRONMENT = "Production"
```

### Environment Variables (Linux/Mac)
```bash
export ConnectionStrings__DefaultConnection="Host=..."
export ASPNETCORE_ENVIRONMENT=Production
```

---

**Bezpieczeństwo przede wszystkim! 🔒**

