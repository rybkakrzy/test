# Liquibase Database Migration

This directory contains Liquibase configuration and changelogs for D2Creator database migrations.

## 📁 Directory Structure

```
liquibase/
├── changelog-master.xml          # Main changelog file (includes all migrations)
├── liquibase.properties          # Local development configuration
├── liquibase.docker.properties   # Docker environment configuration
└── changelog/
    └── 001_initial_schema.sql    # Initial database schema
```

## 🚀 Quick Start

### Prerequisites

- Java 11 or higher (for Liquibase CLI)
- Liquibase CLI installed
- PostgreSQL running (locally or in Docker)

### Installation

Download Liquibase from: https://www.liquibase.org/download

Or install via package manager:

**Windows (Chocolatey):**
```bash
choco install liquibase
```

**macOS (Homebrew):**
```bash
brew install liquibase
```

**Linux:**
```bash
# Download and extract
wget https://github.com/liquibase/liquibase/releases/download/v4.25.0/liquibase-4.25.0.tar.gz
tar -xzf liquibase-4.25.0.tar.gz -C /opt/liquibase
export PATH=$PATH:/opt/liquibase
```

### PostgreSQL JDBC Driver

Download PostgreSQL JDBC driver and place in Liquibase lib directory:
```bash
# Download
wget https://jdbc.postgresql.org/download/postgresql-42.7.1.jar

# Place in Liquibase lib directory
# Windows: C:\ProgramData\chocolatey\lib\liquibase\tools\lib\
# macOS: /opt/homebrew/Cellar/liquibase/[version]/libexec/lib/
# Linux: /opt/liquibase/lib/
```

## 📋 Common Commands

### Update Database (Apply Migrations)

**Local development:**
```bash
cd c:\Projekty\Jit\Kreator\d2creatordb
liquibase --defaults-file=liquibase/liquibase.properties update
```

**Docker environment:**
```bash
cd c:\Projekty\Jit\Kreator\d2creatordb
liquibase --defaults-file=liquibase/liquibase.docker.properties update
```

### Check Status

```bash
liquibase --defaults-file=liquibase/liquibase.properties status
```

### Validate Changelog

```bash
liquibase --defaults-file=liquibase/liquibase.properties validate
```

### Rollback

**Rollback last changeset:**
```bash
liquibase --defaults-file=liquibase/liquibase.properties rollback-count 1
```

**Rollback to specific tag:**
```bash
liquibase --defaults-file=liquibase/liquibase.properties rollback v1.0
```

**Rollback to specific date:**
```bash
liquibase --defaults-file=liquibase/liquibase.properties rollback-to-date 2025-11-20
```

### Generate Documentation

```bash
liquibase --defaults-file=liquibase/liquibase.properties db-doc ./docs
```

### Generate Changelog from Existing Database

```bash
liquibase --defaults-file=liquibase/liquibase.properties generate-changelog
```

### Diff Between Databases

```bash
liquibase --defaults-file=liquibase/liquibase.properties diff \
  --reference-url=jdbc:postgresql://localhost:5432/D2CreatorDb_Dev \
  --reference-username=postgres \
  --reference-password=postgres
```

## 📝 Creating New Migrations

### Method 1: SQL Format (Recommended)

Create a new file: `liquibase/changelog/002_add_feature.sql`

```sql
--liquibase formatted sql

--changeset your-name:002-add-feature
--comment: Add new feature table

CREATE TABLE feature (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

--rollback DROP TABLE IF EXISTS feature;
```

Add to `changelog-master.xml`:
```xml
<include file="db/changelog/002_add_feature.sql" relativeToChangelogFile="false"/>
```

### Method 2: XML Format

```xml
<changeSet id="002" author="your-name">
    <createTable tableName="feature">
        <column name="id" type="uuid" defaultValueComputed="uuid_generate_v4()">
            <constraints primaryKey="true"/>
        </column>
        <column name="name" type="varchar(200)">
            <constraints nullable="false"/>
        </column>
    </createTable>
</changeSet>
```

## 🐳 Docker Integration

### Dockerfile with Liquibase

Create `Dockerfile.liquibase`:

```dockerfile
FROM liquibase/liquibase:4.25

# Copy changelog files
COPY liquibase/ /liquibase/

# Set working directory
WORKDIR /liquibase

# Default command
CMD ["--defaults-file=/liquibase/liquibase.docker.properties", "update"]
```

### Docker Compose Integration

Add to `docker-compose.yml`:

```yaml
liquibase:
  build:
    context: ./d2creatordb
    dockerfile: Dockerfile.liquibase
  container_name: d2creator_liquibase
  networks:
    - podman
  depends_on:
    d2-postgres:
      condition: service_healthy
  environment:
    - LIQUIBASE_COMMAND_URL=jdbc:postgresql://d2-postgres:5432/D2CreatorDb
    - LIQUIBASE_COMMAND_USERNAME=postgres
    - LIQUIBASE_COMMAND_PASSWORD=postgres
```

### Run Liquibase in Docker

```bash
docker-compose run --rm liquibase update
docker-compose run --rm liquibase status
docker-compose run --rm liquibase rollback-count 1
```

## 🔧 Configuration Files

### liquibase.properties (Local)

For local development against `localhost:5432`:
```properties
url=jdbc:postgresql://localhost:5432/D2CreatorDb
username=postgres
password=postgres
```

### liquibase.docker.properties (Docker)

For Docker environment against `d2-postgres:5432`:
```properties
url=jdbc:postgresql://d2-postgres:5432/D2CreatorDb
username=postgres
password=postgres
```

## 📊 Best Practices

### 1. Naming Convention

```
[number]_[description].sql
001_initial_schema.sql
002_add_users_table.sql
003_add_projects_indexes.sql
```

### 2. Changeset ID Convention

```sql
--changeset [author]:[number]-[description]
--changeset d2creator:001-initial-schema
--changeset john.doe:002-add-feature
```

### 3. Always Include Rollback

```sql
--changeset author:id
-- Your changes here
CREATE TABLE ...

--rollback DROP TABLE ...
```

### 4. Use Contexts for Environments

```sql
--changeset author:id context:development
INSERT INTO users VALUES (...);

--changeset author:id context:production
-- Production-only changes
```

### 5. Preconditions

```sql
--changeset author:id
--preconditions onFail:MARK_RAN
--precondition-sql-check expectedResult:0 SELECT COUNT(*) FROM information_schema.tables WHERE table_name='users'

CREATE TABLE users (...);
```

## 🔍 Troubleshooting

### Database Lock

If migrations fail with lock error:
```bash
liquibase --defaults-file=liquibase/liquibase.properties release-locks
```

### Clear Checksums

If checksum validation fails:
```bash
liquibase --defaults-file=liquibase/liquibase.properties clear-checksums
```

### View Changelog Tables

```sql
SELECT * FROM databasechangelog ORDER BY dateexecuted DESC;
SELECT * FROM databasechangeloglock;
```

## 📚 Additional Resources

- [Liquibase Documentation](https://docs.liquibase.com/)
- [SQL Format](https://docs.liquibase.com/concepts/changelogs/sql-format.html)
- [Best Practices](https://docs.liquibase.com/concepts/bestpractices.html)
- [PostgreSQL Support](https://docs.liquibase.com/start/tutorials/postgresql.html)

## 🔐 Security

**Important:** Never commit credentials to version control!

Use environment variables:
```bash
export LIQUIBASE_COMMAND_URL=jdbc:postgresql://...
export LIQUIBASE_COMMAND_USERNAME=postgres
export LIQUIBASE_COMMAND_PASSWORD=secret
```

Or use `.env` file (add to `.gitignore`):
```bash
liquibase --defaults-file=liquibase/liquibase.properties \
  --url=${DB_URL} \
  --username=${DB_USER} \
  --password=${DB_PASSWORD} \
  update
```

---

**Last Updated:** 2025-11-23
