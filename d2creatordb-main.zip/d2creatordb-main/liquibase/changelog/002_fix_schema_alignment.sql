--liquibase formatted sql

--changeset d2creator:002-fix-schema-alignment
--comment: Fix schema to align with domain model entities

-- =====================================================
-- FIX MAPPINGS TABLE
-- =====================================================
-- Rename columns to match Mapping entity
ALTER TABLE mappings RENAME COLUMN field_name TO tag_name;
ALTER TABLE mappings RENAME COLUMN mapper_type TO mapping_type;
ALTER TABLE mappings RENAME COLUMN mapping_config TO mapping_json;
ALTER TABLE mappings RENAME COLUMN display_order TO sort_order;
ALTER TABLE mappings DROP COLUMN IF EXISTS is_active;
ALTER TABLE mappings DROP COLUMN IF EXISTS updated_at;

-- Add created_by column
ALTER TABLE mappings ADD COLUMN created_by UUID;
ALTER TABLE mappings ADD CONSTRAINT fk_mappings_created_by FOREIGN KEY (created_by) 
    REFERENCES users(id) ON DELETE SET NULL;

-- Update constraint name
ALTER TABLE mappings DROP CONSTRAINT IF EXISTS uq_version_field;
ALTER TABLE mappings ADD CONSTRAINT uq_project_version_tag UNIQUE (project_version_id, tag_name);

-- =====================================================
-- FIX PARSE_RESULTS TABLE
-- =====================================================
-- Remove old columns
ALTER TABLE parse_results DROP COLUMN IF EXISTS is_valid;
ALTER TABLE parse_results DROP COLUMN IF EXISTS errors;
ALTER TABLE parse_results DROP COLUMN IF EXISTS warnings;
ALTER TABLE parse_results DROP COLUMN IF EXISTS metadata;
ALTER TABLE parse_results DROP COLUMN IF EXISTS placeholders;
ALTER TABLE parse_results DROP COLUMN IF EXISTS created_at;

-- Add new columns to match ParseResult entity
ALTER TABLE parse_results ADD COLUMN parse_json JSONB;
ALTER TABLE parse_results ADD COLUMN sample_request JSONB;
ALTER TABLE parse_results ADD COLUMN validation_errors JSONB;
ALTER TABLE parse_results ADD COLUMN parsed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- =====================================================
-- FIX APPROVALS TABLE
-- =====================================================
-- Rename columns
ALTER TABLE approvals RENAME COLUMN comments TO comment;
ALTER TABLE approvals DROP COLUMN IF EXISTS requested_at;
ALTER TABLE approvals DROP COLUMN IF EXISTS responded_at;

-- Add created_at column
ALTER TABLE approvals ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- =====================================================
-- FIX AUDIT_LOG TABLE
-- =====================================================
-- Rename columns
ALTER TABLE audit_log RENAME COLUMN entity_type TO entity;
ALTER TABLE audit_log RENAME COLUMN user_id TO actor_id;
ALTER TABLE audit_log RENAME COLUMN changes TO payload;

-- Remove unused columns
ALTER TABLE audit_log DROP COLUMN IF EXISTS ip_address;
ALTER TABLE audit_log DROP COLUMN IF EXISTS user_agent;

-- Update entity_id to allow NULL (Guid? in model)
ALTER TABLE audit_log ALTER COLUMN entity_id DROP NOT NULL;

-- Update constraint
ALTER TABLE audit_log DROP CONSTRAINT IF EXISTS fk_audit_log_user;
ALTER TABLE audit_log ADD CONSTRAINT fk_audit_log_actor FOREIGN KEY (actor_id) 
    REFERENCES users(id) ON DELETE SET NULL;

-- Remove action constraint (not needed - will be validated in application)
ALTER TABLE audit_log DROP CONSTRAINT IF EXISTS chk_action;

-- =====================================================
-- FIX USERS TABLE
-- =====================================================
-- Add tenant_id column if not exists (based on UserConfiguration)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'users' AND column_name = 'tenant_id') THEN
        ALTER TABLE users ADD COLUMN tenant_id UUID;
        ALTER TABLE users ADD CONSTRAINT fk_users_tenant FOREIGN KEY (tenant_id) 
            REFERENCES tenants(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Rename full_name to display_name (based on User entity)
ALTER TABLE users RENAME COLUMN full_name TO display_name;

-- Update unique constraint
DROP INDEX IF EXISTS ux_users_tenant_username;
CREATE UNIQUE INDEX ux_users_tenant_username ON users(tenant_id, username);

-- =====================================================
-- UPDATE INDEXES
-- =====================================================

-- Remove old indexes
DROP INDEX IF EXISTS idx_project_versions_project_id;
DROP INDEX IF EXISTS idx_project_versions_status;
DROP INDEX IF EXISTS idx_project_versions_is_active;

-- Add index from ProjectVersionConfiguration
CREATE INDEX IF NOT EXISTS idx_project_versions_project_id_created_at 
    ON project_versions(project_id, created_at);

