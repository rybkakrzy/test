--liquibase formatted sql

--changeset d2creator:004-fix-timestamp-columns
--comment: Change timestamp columns to timestamp with time zone for PostgreSQL compatibility

-- =====================================================
-- FIX PROJECT_VERSIONS TIMESTAMPS
-- =====================================================
ALTER TABLE project_versions 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

ALTER TABLE project_versions 
    ALTER COLUMN updated_at TYPE TIMESTAMP WITH TIME ZONE USING updated_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX PROJECTS TIMESTAMPS
-- =====================================================
ALTER TABLE projects 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

ALTER TABLE projects 
    ALTER COLUMN updated_at TYPE TIMESTAMP WITH TIME ZONE USING updated_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX TENANTS TIMESTAMPS
-- =====================================================
ALTER TABLE tenants 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

ALTER TABLE tenants 
    ALTER COLUMN updated_at TYPE TIMESTAMP WITH TIME ZONE USING updated_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX USERS TIMESTAMPS
-- =====================================================
ALTER TABLE users 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

ALTER TABLE users 
    ALTER COLUMN updated_at TYPE TIMESTAMP WITH TIME ZONE USING updated_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX FILES TIMESTAMPS
-- =====================================================
ALTER TABLE files 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX APPROVALS TIMESTAMPS
-- =====================================================
ALTER TABLE approvals 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX PARSE_RESULTS TIMESTAMPS
-- =====================================================
ALTER TABLE parse_results 
    ALTER COLUMN parsed_at TYPE TIMESTAMP WITH TIME ZONE USING parsed_at AT TIME ZONE 'UTC';

-- =====================================================
-- FIX AUDIT_LOG TIMESTAMPS
-- =====================================================
ALTER TABLE audit_log 
    ALTER COLUMN created_at TYPE TIMESTAMP WITH TIME ZONE USING created_at AT TIME ZONE 'UTC';
