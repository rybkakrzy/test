--liquibase formatted sql

--changeset d2creator:003-change-status-to-varchar
--comment: Change status columns from PostgreSQL ENUM to VARCHAR for better compatibility

-- =====================================================
-- CHANGE PROJECT_VERSIONS STATUS TO VARCHAR
-- =====================================================
-- First, alter the column type from ENUM to VARCHAR
ALTER TABLE project_versions 
    ALTER COLUMN status TYPE VARCHAR(50) USING status::text;

-- Set default value
ALTER TABLE project_versions 
    ALTER COLUMN status SET DEFAULT 'Draft';

-- =====================================================
-- CHANGE APPROVALS STATUS TO VARCHAR
-- =====================================================
-- Alter the column type from ENUM to VARCHAR
ALTER TABLE approvals 
    ALTER COLUMN status TYPE VARCHAR(50) USING status::text;

-- Set default value
ALTER TABLE approvals 
    ALTER COLUMN status SET DEFAULT 'Requested';
