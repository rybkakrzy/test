export const environment = {
  production: false,
  name: 'local',
  apiUrl: 'http://localhost:5000/api',
};
