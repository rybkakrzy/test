export const environment = {
  production: false,
  name: 'uat',
  apiUrl: 'https://api-uat.example.com/api',
};
