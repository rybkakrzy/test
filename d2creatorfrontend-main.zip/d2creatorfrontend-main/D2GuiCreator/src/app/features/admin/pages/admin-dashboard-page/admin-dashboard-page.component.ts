import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { PageLayoutComponent } from '../../../../shared/ui/page-layout/page-layout.component';

@Component({
  selector: 'app-admin-dashboard-page',
  standalone: true,
  imports: [CommonModule, PageLayoutComponent],
  templateUrl: './admin-dashboard-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminDashboardPageComponent {}
