export interface RecipientDto {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface BusinessLineDto {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface TenantDto {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

export interface StatusDto {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

/**
 * Wynik odświeżenia pojedynczego słownika
 */
export interface RefreshResult {
  dictionaryName: string;
  itemCount: number;
  totalCount: number;
  refreshedAt: string;
}

/**
 * Wynik odświeżenia wszystkich słowników
 */
export interface RefreshAllResult {
  recipients: RefreshResult;
  businessLines: RefreshResult;
  tenants: RefreshResult;
  statuses: RefreshResult;
  refreshedAt: string;
}
