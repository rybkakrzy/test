import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export type ValidationNoteType = 'info' | 'error' | 'warning' | 'success';

export interface ValidationNote {
  id: string;
  type: ValidationNoteType;
  message: string;
  details?: string[];
}

@Component({
  selector: 'app-validation-notes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './validation-notes.component.html',
  styleUrl: './validation-notes.component.scss'
})
export class ValidationNotesComponent {
  @Input() notes: ValidationNote[] = [];
  @Input() title: string = 'Uwagi do szablonu dokumentu';
  @Input() pageSize: number = 4;

  currentPage = 0;

  get totalPages(): number {
    return Math.ceil(this.notes.length / this.pageSize);
  }

  get paginatedNotes(): ValidationNote[] {
    const startIndex = this.currentPage * this.pageSize;
    return this.notes.slice(startIndex, startIndex + this.pageSize);
  }

  get hasPrevPage(): boolean {
    return this.currentPage > 0;
  }

  get hasNextPage(): boolean {
    return this.currentPage < this.totalPages - 1;
  }

  getTypeLabel(type: ValidationNoteType): string {
    const labels: Record<ValidationNoteType, string> = {
      info: 'Informacje',
      error: 'Błąd',
      warning: 'Ostrzeżenie',
      success: 'Sukces'
    };
    return labels[type];
  }

  removeNote(noteId: string): void {
    const noteIndex = this.notes.findIndex(note => note.id === noteId);
    this.notes = this.notes.filter(note => note.id !== noteId);
    
    // Jeśli usunęliśmy ostatni element na stronie, cofnij się do poprzedniej
    if (this.paginatedNotes.length === 0 && this.currentPage > 0) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.hasNextPage) {
      this.currentPage++;
    }
  }

  prevPage(): void {
    if (this.hasPrevPage) {
      this.currentPage--;
    }
  }

  goToPage(page: number): void {
    if (page >= 0 && page < this.totalPages) {
      this.currentPage = page;
    }
  }
}
