import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, signal, inject } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ValidationNotesComponent, ValidationNote } from '../../components/validation-notes/validation-notes.component';
import { DocumentService, DocumentValidationResult, PlaceholderExtractionResult } from '../../services/document.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-template-and-schema-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ValidationNotesComponent],
  templateUrl: './template-and-schema-step.component.html',
  styleUrls: ['./template-and-schema-step.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TemplateAndSchemaStepComponent {
  @Input() group!: FormGroup;

  @Output() instructionRequested = new EventEmitter<void>();

  private readonly documentService = inject(DocumentService);

  readonly isDragging = signal(false);
  readonly isUploading = signal(false);
  readonly isValidating = signal(false);
  readonly isExtractingPlaceholders = signal(false);
  readonly isShowingApiRequest = signal(false);
  
  // Przechowywanie pliku i wyników
  private uploadedFile: File | null = null;
  private extractedPlaceholders: string[] = [];
  validationNotes: ValidationNote[] = [];
  generatedSchema: Record<string, any> | null = null;

  get templateIdControl() {
    return this.group.get('templateId');
  }

  get dataSchemaIdControl() {
    return this.group.get('dataSchemaId');
  }

  onInstructionClick(): void {
    this.instructionRequested.emit();
    // Otwórz PDF z instrukcją w nowej karcie
    window.open('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', '_blank');
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      return;
    }

    this.processFile(input.files[0]);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(true);
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);

    const files = event.dataTransfer?.files;
    if (!files || files.length === 0) {
      return;
    }

    const file = files[0];
    
    // Sprawdź rozszerzenie pliku
    if (!file.name.toLowerCase().endsWith('.docx')) {
      alert('Nieprawidłowy format pliku. Dopuszczalny format: DOCX');
      return;
    }

    this.processFile(file);
  }

  private processFile(file: File): void {
    if (!this.group) {
      return;
    }

    // Sprawdź rozszerzenie
    if (!file.name.toLowerCase().endsWith('.docx')) {
      alert('Nieprawidłowy format pliku. Dopuszczalny format: DOCX');
      return;
    }

    // Sprawdź rozmiar (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      alert('Plik jest za duży. Maksymalny rozmiar: 10MB');
      return;
    }

    // Zapisz plik i nazwę
    this.uploadedFile = file;
    this.group.patchValue({
      templateId: file.name
    });
    this.group.markAsDirty();
    this.group.markAsTouched();

    // Wyślij plik do API
    this.uploadTemplateToApi(file);
  }

  private uploadTemplateToApi(file: File): void {
    this.isUploading.set(true);
    this.isValidating.set(true);
    this.isExtractingPlaceholders.set(true);
    
    // Wykonaj walidację i ekstrakcję równolegle
    forkJoin({
      validation: this.documentService.validateTemplate(file),
      placeholders: this.documentService.extractPlaceholders(file)
    }).subscribe({
      next: ({ validation, placeholders }) => {
        this.isUploading.set(false);
        this.isValidating.set(false);
        this.isExtractingPlaceholders.set(false);
        
        // Przetwórz wyniki walidacji
        this.processValidationResult(validation);
        
        // Przetwórz wyniki ekstrakcji znaczników
        this.processPlaceholdersResult(placeholders);
        
        console.log('✅ Walidacja i ekstrakcja zakończone pomyślnie');
        console.log('📋 Validation:', validation);
        console.log('🏷️ Placeholders:', placeholders);
      },
      error: (error) => {
        this.isUploading.set(false);
        this.isValidating.set(false);
        this.isExtractingPlaceholders.set(false);
        console.error('❌ Błąd podczas przetwarzania pliku:', error);
        
        // Pokaż komunikat błędu użytkownikowi
        this.validationNotes = [{
          id: 'error-1',
          type: 'error',
          message: 'Nie udało się przetworzyć dokumentu. Sprawdź połączenie z API.',
          details: [error.message || 'Nieznany błąd']
        }];
      }
    });
  }

  private processValidationResult(validation: DocumentValidationResult): void {
    const notes: ValidationNote[] = [];
    
    // Dodaj błędy
    validation.errors.forEach((error, index) => {
      notes.push({
        id: `error-${index}`,
        type: 'error',
        message: error.message,
        details: error.location ? [error.location] : []
      });
    });
    
    // Dodaj ostrzeżenia
    validation.warnings.forEach((warning, index) => {
      notes.push({
        id: `warning-${index}`,
        type: 'warning',
        message: warning.message,
        details: warning.location ? [warning.location] : []
      });
    });
    
    // Jeśli dokument jest poprawny, dodaj info
    if (validation.isValid && notes.length === 0) {
      notes.push({
        id: 'success-1',
        type: 'success',
        message: 'Dokument przeszedł walidację pomyślnie',
        details: validation.metadata ? [
          `Liczba stron: ${validation.metadata.pageCount}`,
          `Rozmiar: ${Math.round(validation.metadata.fileSizeBytes / 1024)} KB`
        ] : []
      });
    }
    
    this.validationNotes = notes;
  }

  private processPlaceholdersResult(result: PlaceholderExtractionResult): void {
    this.extractedPlaceholders = result.placeholders;
    
    // Generuj schemat na podstawie wyekstrahowanych znaczników
    const schema: Record<string, string> = {};
    result.placeholders.forEach(placeholder => {
      // Usuń <% i %> i zapisz jako klucz
      const key = placeholder.replace(/<%|%>/g, '').trim();
      schema[key] = 'text'; // Domyślnie text, można rozbudować o wykrywanie typu
    });
    
    this.generatedSchema = schema;
    this.group.patchValue({
      dataSchemaId: JSON.stringify(schema, null, 2)
    });
    
    // Dodaj notatkę informacyjną o znalezionych znacznikach
    if (result.placeholders.length > 0) {
      this.validationNotes.push({
        id: 'placeholders-info',
        type: 'info',
        message: `Znaleziono ${result.placeholders.length} znaczników w dokumencie`,
        details: result.placeholders.slice(0, 5) // Pokaż pierwsze 5
      });
    } else {
      this.validationNotes.push({
        id: 'no-placeholders',
        type: 'warning',
        message: 'Nie znaleziono żadnych znaczników w formacie <%...%>',
        details: []
      });
    }
  }

  private generateSampleSchema(): void {
    // Przykładowy schemat - do usunięcia po podpięciu API
    const sampleSchema = {
      "E_CZY_ANONIM": "text",
      "E_ZWROT_GRZECZNOSCIOWY": "text",
      "E_NUMER_ZGLOSZENIA_WN": "text",
      "E_DATA_ROZPATRZENIA_STRING": "text",
      "SYSTEM_DATE_TIME_STRING": "text",
      "E_IMIE": "text",
      "E_NAZWISKO": "text",
      "E_ULICA_NUMER": "text",
      "TECH_KOD_POCZTOWY": "text",
      "E_MIEJSCOWOSC": "text",
      "E_KRAJ": "text",
      "K_KRAJ": "text",
      "B_PRACOWNIK": "text",
      "B_JEDNOSTKA_ETYKIETA": "text",
      "B_STANOWISKO_STRING": "text"
    };
    
    this.generatedSchema = sampleSchema;
    this.group.patchValue({
      dataSchemaId: JSON.stringify(sampleSchema, null, 2)
    });
  }

  removeFile(): void {
    this.uploadedFile = null;
    this.validationNotes = [];
    this.generatedSchema = null;
    this.isShowingApiRequest.set(false);
    this.group.patchValue({
      templateId: '',
      dataSchemaId: ''
    });
    this.group.markAsDirty();
    this.group.markAsTouched();
  }

  getUploadedFile(): File | null {
    return this.uploadedFile;
  }

  copySchemaToClipboard(): void {
    const schemaText = this.group.get('dataSchemaId')?.value;
    if (schemaText) {
      navigator.clipboard.writeText(schemaText).then(() => {
        console.log('Schema skopiowana do schowka');
        // TODO: Można dodać toast notification
      }).catch(err => {
        console.error('Błąd podczas kopiowania:', err);
      });
    }
  }

  viewApiRequest(): void {
    if (!this.generatedSchema) {
      return;
    }

    const currentValue = this.group.get('dataSchemaId')?.value;
    
    if (this.isShowingApiRequest()) {
      // Przełącz z powrotem na schemat danych
      this.isShowingApiRequest.set(false);
      this.group.patchValue({
        dataSchemaId: JSON.stringify(this.generatedSchema, null, 2)
      });
    } else {
      // Pokaż API Request
      this.isShowingApiRequest.set(true);
      const apiRequest = this.generateApiRequest(this.generatedSchema);
      this.group.patchValue({
        dataSchemaId: JSON.stringify(apiRequest, null, 2)
      });
    }
  }

  private generateApiRequest(schema: Record<string, any>): any {
    // Generowanie przykładowego API Request z wartościami z schematu
    const dataObject: Record<string, string> = {};
    
    Object.keys(schema).forEach(key => {
      // Generuj przykładowe wartości w zależności od typu
      const type = schema[key];
      switch (type) {
        case 'text':
          dataObject[key] = `Przykładowa wartość dla ${key}`;
          break;
        case 'number':
          dataObject[key] = '123';
          break;
        case 'date':
          dataObject[key] = '2025-01-01';
          break;
        case 'boolean':
          dataObject[key] = 'true';
          break;
        default:
          dataObject[key] = `Wartość ${key}`;
      }
    });

    return {
      method: 'POST',
      endpoint: '/api/documents/generate',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer {token}'
      },
      body: {
        templateId: this.group.get('templateId')?.value || 'template-id',
        language: 'pl',
        format: 'pdf',
        data: dataObject
      }
    };
  }

  private generateSampleValidationNotes(): void {
    // Przykładowe uwagi - do usunięcia po podpięciu API
    this.validationNotes = [
      {
        id: '1',
        type: 'info',
        message: 'Znaleziono 3 tabele które nie mają powiązania ze znacznikiem. Zignoruj jeżeli są to tabele ze statymi danymi.',
        details: []
      },
      {
        id: '2',
        type: 'error',
        message: 'Wykryliśmy niedozwolone znaczniki mapowań! Aby móc kontynuować należy je poprawić zgodnie z instrukcją:',
        details: [
          '<%imię i nazwisko klienta%>',
          '<%kod pocztowy i miasto%>'
        ]
      },
      {
        id: '3',
        type: 'warning',
        message: 'Text text text',
        details: []
      }
    ];
  }
}
