import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, OnInit, signal } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FieldMapping, MapperType } from '../../data-access/letter-wizard.model';
import { MappingDialogComponent } from '../../components/mapping-dialog/mapping-dialog.component';
import { MapperService } from '../../services/mapper.service';

@Component({
  selector: 'app-configuration-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MappingDialogComponent],
  templateUrl: './configuration-step.component.html',
  styleUrl: './configuration-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfigurationStepComponent implements OnInit {
  @Input() group!: FormGroup;

  isDialogOpen = signal(false);
  editingIndex = signal<number | null>(null);
  mapperTypes = signal<MapperType[]>([]);

  mappings = signal<FieldMapping[]>([
    {
      name: 'E_CTY_ANONIMN',
      mapperType: 'choice-list',
      mappingJson: '{"value":"24.58_E_CTY_ANONIMN","replacement-property-expression":"form","default":"E_CTY_ANONIMN"}'
    },
    {
      name: 'E_ZWNDT_GRZECZNOSCIOWY',
      mapperType: 'evaluation',
      mappingJson: '{"E_ZWNDT_GRZECZNOSCIOWY":"replacement-property-expression":"form","default":"E_ZWNDT_GRZECZNOSCIOWY"}'
    }
  ]);

  constructor(private mapperService: MapperService) {}

  ngOnInit(): void {
    // Pobierz dostępne typy maperów
    this.mapperService.getMapperTypes().subscribe(types => {
      this.mapperTypes.set(types);
    });
  }

  addMapping(): void {
    this.editingIndex.set(null);
    this.isDialogOpen.set(true);
  }

  editMapping(index: number): void {
    this.editingIndex.set(index);
    this.isDialogOpen.set(true);
  }

  deleteMapping(index: number): void {
    const currentMappings = this.mappings();
    this.mappings.set(currentMappings.filter((_, i) => i !== index));
  }

  closeDialog(): void {
    this.isDialogOpen.set(false);
    this.editingIndex.set(null);
  }

  saveMapping(mapping: FieldMapping): void {
    const currentMappings = [...this.mappings()];
    const editIndex = this.editingIndex();

    if (editIndex !== null) {
      // Edycja istniejącego mapowania
      currentMappings[editIndex] = mapping;
    } else {
      // Dodanie nowego mapowania
      currentMappings.push(mapping);
    }

    this.mappings.set(currentMappings);
    this.closeDialog();
  }

  getEditingMapping(): FieldMapping | undefined {
    const index = this.editingIndex();
    return index !== null ? this.mappings()[index] : undefined;
  }

  getMapperTypeName(mapperKey: string): string {
    return this.mapperTypes().find(mt => mt.key === mapperKey)?.name || mapperKey;
  }
}
