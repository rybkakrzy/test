import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { LetterWizardData } from '../../data-access/letter-wizard.model';

@Component({
  selector: 'app-summary-step',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './summary-step.component.html',
  styleUrls: ['./summary-step.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SummaryStepComponent {
  @Input() data!: LetterWizardData;

  getEnvironmentsText(): string {
    const environments = this.data.general?.environments;
    if (!environments || environments.length === 0) {
      return '-';
    }
    return environments.join(', ').toUpperCase();
  }
}
