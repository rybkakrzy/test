import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectListTableComponent } from '../../components/project-list-table/project-list-table.component';
import { PageLayoutComponent } from '../../../../shared/ui/page-layout/page-layout.component';
import { EmptyStateComponent } from '../../../../shared/ui/empty-state/empty-state.component';
import { Project } from '../../../../shared/models/project.model';
import { createGuid } from '../../../../core/utils/guid.util';
import { WizardDataService, ProjectResponse } from '../../../letter-wizard/services/wizard-data.service';

@Component({
  selector: 'app-project-list-page',
  standalone: true,
  imports: [
    CommonModule,
    PageLayoutComponent,
    EmptyStateComponent,
    ProjectListTableComponent
  ],
  templateUrl: './project-list-page.component.html',
  styleUrls: ['./project-list-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectListPageComponent implements OnInit {
  private readonly wizardDataService = inject(WizardDataService);
  private readonly router = inject(Router);

  readonly projects = signal<Project[]>([]);
  readonly isLoading = signal(false);

  ngOnInit(): void {
    this.loadProjects();
  }

  private loadProjects(): void {
    this.isLoading.set(true);
    
    this.wizardDataService.getProjects().subscribe({
      next: (apiProjects: ProjectResponse[]) => {
        console.log('✅ Projects loaded from API:', apiProjects);
        
        // Map API response to UI model
        const mappedProjects: Project[] = apiProjects.map(p => ({
          id: p.id,
          name: p.name,
          ownerName: p.createdBy || 'Unknown',
          status: this.mapStatus(p.currentActiveVersionId),
          createdAt: p.createdAt
        }));

        this.projects.set(mappedProjects);
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading projects:', error);
        this.isLoading.set(false);
        // Keep empty list on error
        this.projects.set([]);
      }
    });
  }

  private mapStatus(currentActiveVersionId: string | null): 'Draft' | 'InProgress' | 'Completed' {
    // Simple status mapping - you can enhance this based on your needs
    if (!currentActiveVersionId) {
      return 'Draft';
    }
    return 'InProgress';
  }

  onCreateProject(): void {
    const newProjectId = createGuid();

    this.router.navigate(['/projects', newProjectId, 'wizard'], {
      state: { isNewProject: true }
    });
  }

  onOpenProject(project: Project): void {
    this.router.navigate(['/projects', project.id]);
  }
}
