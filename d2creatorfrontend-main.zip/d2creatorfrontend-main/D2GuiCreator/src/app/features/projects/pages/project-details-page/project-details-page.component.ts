import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageLayoutComponent } from '../../../../shared/ui/page-layout/page-layout.component';
import { WizardDataService, ProjectResponse, ProjectVersionResponse } from '../../../letter-wizard/services/wizard-data.service';

@Component({
  selector: 'app-project-details-page',
  standalone: true,
  imports: [CommonModule, PageLayoutComponent],
  templateUrl: './project-details-page.component.html',
  styleUrls: ['./project-details-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectDetailsPageComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly wizardDataService = inject(WizardDataService);

  readonly projectId = signal<string | null>(null);
  readonly project = signal<ProjectResponse | null>(null);
  readonly versions = signal<ProjectVersionResponse[]>([]);
  readonly isLoading = signal(false);
  readonly isLoadingVersions = signal(false);

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('projectId');
    this.projectId.set(id);
    
    if (id) {
      this.loadProject(id);
    }
  }

  private loadProject(id: string): void {
    this.isLoading.set(true);
    
    this.wizardDataService.getProject(id).subscribe({
      next: (project) => {
        console.log('✅ Project loaded:', project);
        this.project.set(project);
        this.isLoading.set(false);
        
        // Load versions
        this.loadVersions(id);
      },
      error: (error) => {
        console.error('❌ Error loading project:', error);
        this.isLoading.set(false);
      }
    });
  }

  private loadVersions(projectId: string): void {
    this.isLoadingVersions.set(true);
    
    this.wizardDataService.getProjectVersions(projectId).subscribe({
      next: (versions) => {
        console.log('✅ Versions loaded:', versions);
        this.versions.set(versions);
        this.isLoadingVersions.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading versions:', error);
        this.isLoadingVersions.set(false);
      }
    });
  }

  goBackToList(): void {
    this.router.navigate(['/projects']);
  }

  startWizard(): void {
    const id = this.projectId();
    const proj = this.project();
    
    if (!id || !proj) {
      return;
    }

    console.log('🚀 Starting wizard for project:', id);

    // Try to get versions to resume from last step
    this.wizardDataService.getProjectVersions(id).subscribe({
      next: (versions) => {
        if (versions && versions.length > 0) {
          // Sort by creation date to get the latest
          const latestVersion = versions.sort((a, b) => 
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          )[0];
          
          console.log('📝 Resuming with latest version:', latestVersion.id);
          
          this.router.navigate(['/projects', id, 'wizard'], {
            queryParams: { 
              versionId: latestVersion.id,
              mode: 'edit'
            }
          });
        } else {
          // No versions - start fresh
          console.log('✨ No versions found, starting new wizard');
          this.router.navigate(['/projects', id, 'wizard']);
        }
      },
      error: (error) => {
        console.error('❌ Error loading versions, starting fresh:', error);
        // On error, just start fresh wizard
        this.router.navigate(['/projects', id, 'wizard']);
      }
    });
  }

  activateVersion(versionId: string): void {
    const projectId = this.projectId();
    
    if (!projectId || !versionId) {
      return;
    }

    if (!confirm('Czy na pewno chcesz aktywować tę wersję projektu?')) {
      return;
    }

    console.log('🔄 Activating version:', versionId);

    this.wizardDataService.activateProjectVersion(projectId, versionId).subscribe({
      next: (result) => {
        console.log('✅ Version activated:', result);
        alert('Wersja została aktywowana pomyślnie');
        
        // Reload project and versions
        if (projectId) {
          this.loadProject(projectId);
        }
      },
      error: (error) => {
        console.error('❌ Error activating version:', error);
        alert('Wystąpił błąd podczas aktywacji wersji');
      }
    });
  }

  editVersion(versionId: string): void {
    const projectId = this.projectId();
    
    if (!projectId || !versionId) {
      return;
    }

    this.router.navigate(['/projects', projectId, 'wizard'], {
      queryParams: { 
        versionId: versionId,
        mode: 'edit'
      }
    });
  }

  viewVersions(): void {
    // TODO: Implement version history view
    console.log('📚 View versions - not implemented yet');
  }

  exportProject(): void {
    // TODO: Implement project export
    console.log('💾 Export project - not implemented yet');
  }
}
