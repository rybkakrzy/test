import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, interval, of, switchMap, timer } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiConnectionService {
  private readonly isConnected = signal<boolean>(true);
  private readonly checkInterval = 10000; // 10 sekund
  private readonly retryInterval = 5000; // 5 sekund gdy rozłączone

  readonly isApiConnected = this.isConnected.asReadonly();

  constructor(private readonly http: HttpClient) {
    this.startHealthCheck();
  }

  /**
   * Wywołaj ręcznie po wykryciu błędu połączenia
   */
  markAsDisconnected(): void {
    this.isConnected.set(false);
    // Natychmiastowe sprawdzenie po 2 sekundach
    timer(2000).pipe(
      switchMap(() => this.checkApiHealth())
    ).subscribe(isHealthy => {
      this.isConnected.set(isHealthy);
    });
  }

  /**
   * Wywołaj po udanym połączeniu
   */
  markAsConnected(): void {
    this.isConnected.set(true);
  }

  private startHealthCheck(): void {
    // Pierwsze sprawdzenie od razu
    this.checkApiHealth().subscribe(isHealthy => {
      this.isConnected.set(isHealthy);
    });

    // Sprawdzaj regularnie co 10 sekund
    interval(this.checkInterval).pipe(
      switchMap(() => this.checkApiHealth())
    ).subscribe(isHealthy => {
      this.isConnected.set(isHealthy);
    });
  }

  private checkApiHealth() {
    // Używamy kontrolera health który zwraca JSON
    const healthUrl = `${environment.apiUrl}/v1/health`;
    
    console.log('[ApiConnection] Checking health at:', healthUrl);
    
    return this.http.get(healthUrl).pipe(
      switchMap((response) => {
        console.log('[ApiConnection] Health check SUCCESS:', response);
        return of(true);
      }),
      catchError((error) => {
        console.log('[ApiConnection] Health check FAILED:', error);
        return of(false);
      })
    );
  }
}
