export type ProjectStatus = 'Draft' | 'InProgress' | 'Completed';

export interface Project {
  id: string;
  name: string;
  ownerName: string;
  status: ProjectStatus;
  createdAt: string;
}
