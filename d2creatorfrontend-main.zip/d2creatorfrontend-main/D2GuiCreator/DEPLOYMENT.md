# Wdrożenie aplikacji D2 GUI Creator w Podman

## Wymagania

- Podman zainstalowany w systemie
- (Opcjonalnie) podman-compose dla użycia plików compose

## Metoda 1: Bezpośrednie polecenia Podman

### Windows

```cmd
build-and-run.bat
```

### Linux/macOS

```bash
chmod +x build-and-run.sh
./build-and-run.sh
```

## Metoda 2: Ręczne komendy

### Budowanie obrazu

```bash
podman build -t d2-gui-creator:latest .
```

### Uruchomienie kontenera

```bash
podman run -d \
  --name d2-gui-creator \
  -p 8080:80 \
  --restart unless-stopped \
  d2-gui-creator:latest
```

## Metoda 3: Użycie podman-compose

```bash
podman-compose up -d
```

Lub z Docker Compose:

```bash
docker-compose up -d
```

## Dostęp do aplikacji

Po uruchomieniu aplikacja będzie dostępna pod adresem:
- http://localhost:8080

## Zarządzanie kontenerem

### Sprawdzenie statusu

```bash
podman ps
```

### Zatrzymanie kontenera

```bash
podman stop d2-gui-creator
```

### Uruchomienie zatrzymanego kontenera

```bash
podman start d2-gui-creator
```

### Usunięcie kontenera

```bash
podman stop d2-gui-creator
podman rm d2-gui-creator
```

### Usunięcie obrazu

```bash
podman rmi d2-gui-creator:latest
```

### Wyświetlanie logów

```bash
podman logs d2-gui-creator
```

### Wyświetlanie logów na żywo

```bash
podman logs -f d2-gui-creator
```

## Zmienne środowiskowe

Obecnie aplikacja używa standardowych ustawień nginx. Możesz dodać zmienne środowiskowe w pliku `podman-compose.yml` lub podczas uruchamiania kontenera:

```bash
podman run -d \
  --name d2-gui-creator \
  -p 8080:80 \
  -e API_URL=https://api.example.com \
  d2-gui-creator:latest
```

## Troubleshooting

### Port już zajęty

Jeśli port 8080 jest zajęty, zmień mapowanie portów:

```bash
podman run -d --name d2-gui-creator -p 3000:80 d2-gui-creator:latest
```

### Problemy z buildem

Wyczyść cache i zbuduj ponownie:

```bash
podman build --no-cache -t d2-gui-creator:latest .
```

## Aktualizacja aplikacji

1. Zatrzymaj i usuń obecny kontener:
   ```bash
   podman stop d2-gui-creator
   podman rm d2-gui-creator
   ```

2. Usuń stary obraz:
   ```bash
   podman rmi d2-gui-creator:latest
   ```

3. Zbuduj i uruchom nową wersję:
   ```bash
   podman build -t d2-gui-creator:latest .
   podman run -d --name d2-gui-creator -p 8080:80 d2-gui-creator:latest
   ```
