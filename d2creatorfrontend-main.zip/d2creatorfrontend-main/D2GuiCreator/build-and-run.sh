#!/bin/bash

# Build image with Podman
podman build -t d2-gui-creator:latest .

# Stop and remove existing container if it exists
podman stop d2-gui-creator 2>/dev/null || true
podman rm d2-gui-creator 2>/dev/null || true

# Run container
podman run -d \
  --name d2-gui-creator \
  -p 8080:80 \
  --restart unless-stopped \
  d2-gui-creator:latest

echo "Application is running at http://localhost:8080"
