# Aktualizacja ExternalDataService - Integracja z Nową Strukturą API

## 🎯 Cel aktualizacji

Dostosowanie frontendu Angular do nowej struktury API słowników wprowadzonej w backendzie:
- Nowy routing: `/api/v1/dictionaries/*`
- Nowe endpointy refresh dla każdego słownika
- Główny endpoint do odświeżania wszystkich słowników

## 📝 Zmiany w plikach

### 1. `external-data.model.ts`

**Dodano nowe interfejsy:**

```typescript
/**
 * Wynik odświeżenia pojedynczego słownika
 */
export interface RefreshResult {
  dictionaryName: string;
  itemCount: number;
  totalCount: number;
  refreshedAt: string;
}

/**
 * Wynik odświeżenia wszystkich słowników
 */
export interface RefreshAllResult {
  recipients: RefreshResult;
  businessLines: RefreshResult;
  tenants: RefreshResult;
  statuses: RefreshResult;
  refreshedAt: string;
}
```

### 2. `external-data.service.ts`

#### ✅ Zaktualizowano Base URL

**Przed:**
```typescript
private readonly baseUrl = `${environment.apiUrl}/v1`;
```

**Po:**
```typescript
private readonly baseUrl = `${environment.apiUrl}/v1/dictionaries`;
```

#### ✅ Zaktualizowano wszystkie URL endpointów

| Zasób | Stary URL | Nowy URL |
|-------|-----------|----------|
| Recipients | `/v1/Recipients` | `/v1/dictionaries/recipients` |
| Business Lines | `/v1/BusinessLines` | `/v1/dictionaries/businesslines` |
| Tenants | `/v1/Tenants` | `/v1/dictionaries/tenants` |
| Statuses | `/v1/Statuses` | `/v1/dictionaries/statuses` |

#### ✨ Dodano nowe metody refresh

**1. Odświeżanie pojedynczych słowników:**

```typescript
// Odświeża cache odbiorców na backendzie
refreshRecipients(): Observable<RecipientDto[]> {
  return this.http.post<RecipientDto[]>(
    `${this.baseUrl}/recipients/refresh`, 
    {}
  ).pipe(
    tap(() => this.recipientsCache$ = undefined)
  );
}

// Analogicznie dla:
refreshBusinessLines(): Observable<BusinessLineDto[]>
refreshTenants(): Observable<TenantDto[]>
refreshStatuses(): Observable<StatusDto[]>
```

**2. Odświeżanie wszystkich słowników jednocześnie:**

```typescript
refreshAllDictionaries(): Observable<RefreshAllResult> {
  const baseApiUrl = `${environment.apiUrl}/v1/dictionaries`;
  return this.http.post<RefreshAllResult>(
    `${baseApiUrl}/refresh-all`, 
    {}
  ).pipe(
    tap(() => this.clearCache())
  );
}
```

#### 🔄 Rozszerzono metodę clearCache

Dodano logging dla lepszego debugowania:

```typescript
clearCache(): void {
  this.recipientsCache$ = undefined;
  this.businessLinesCache$ = undefined;
  this.tenantsCache$ = undefined;
  this.statusesCache$ = undefined;
  console.log('🧹 Frontend cache cleared');
}
```

## 💡 Przykłady użycia

### Scenariusz 1: Standardowe pobieranie danych (z cache)

```typescript
export class MyComponent implements OnInit {
  recipients = signal<RecipientDto[]>([]);
  
  constructor(private externalDataService: ExternalDataService) {}
  
  ngOnInit() {
    // Pobiera z cache lub z API (jeśli cache pusty)
    this.externalDataService.getActiveRecipients()
      .subscribe(data => this.recipients.set(data));
  }
}
```

### Scenariusz 2: Wymuszenie odświeżenia danych

```typescript
export class AdminComponent {
  constructor(private externalDataService: ExternalDataService) {}
  
  // Metoda 1: Parametr forceRefresh
  refreshUsingParameter() {
    this.externalDataService.getActiveRecipients(true)
      .subscribe(data => console.log('Fresh data:', data));
  }
  
  // Metoda 2: Dedykowany endpoint refresh (REKOMENDOWANE)
  refreshUsingEndpoint() {
    this.externalDataService.refreshRecipients()
      .subscribe(data => {
        console.log('Backend cache refreshed:', data);
        // Cache frontendowy został automatycznie wyczyszczony
      });
  }
}
```

### Scenariusz 3: Odświeżenie wszystkich słowników

```typescript
export class AdminDashboardComponent {
  isRefreshing = signal(false);
  
  constructor(private externalDataService: ExternalDataService) {}
  
  refreshAllDictionaries() {
    this.isRefreshing.set(true);
    
    this.externalDataService.refreshAllDictionaries()
      .pipe(finalize(() => this.isRefreshing.set(false)))
      .subscribe(result => {
        console.log('✅ All dictionaries refreshed!');
        console.log('Recipients:', result.recipients.itemCount, 'items');
        console.log('Business Lines:', result.businessLines.itemCount, 'items');
        console.log('Tenants:', result.tenants.itemCount, 'items');
        console.log('Statuses:', result.statuses.itemCount, 'items');
        console.log('Refreshed at:', result.refreshedAt);
      });
  }
}
```

### Scenariusz 4: Czyszczenie cache po stronie frontendu

```typescript
export class SettingsComponent {
  constructor(private externalDataService: ExternalDataService) {}
  
  clearLocalCache() {
    // Czyści tylko cache Observable (shareReplay)
    // Nie wywołuje API, nie dotyka cache backendu
    this.externalDataService.clearCache();
    console.log('Local cache cleared. Next request will fetch fresh data.');
  }
}
```

## 🔍 Różnice: forceRefresh vs refresh()

| Aspekt | `forceRefresh: true` | `refresh()` |
|--------|---------------------|-------------|
| **Cel** | Pomija cache frontendowy | Odświeża cache backendowy |
| **Wywołanie API** | `GET /dictionaries/recipients` | `POST /dictionaries/recipients/refresh` |
| **Cache backend** | Używa istniejącego | Wymusza ponowne pobranie z systemu zewnętrznego |
| **Cache frontend** | Omija Observable cache | Automatycznie czyści Observable cache |
| **Kiedy używać** | Potrzebujesz świeżych danych dla jednego komponentu | Admin chce odświeżyć dane dla wszystkich użytkowników |

## 🎨 Propozycja UI dla Admin Panel

```html
<!-- admin-dictionaries.component.html -->
<div class="dictionaries-management">
  <h2>Zarządzanie Słownikami</h2>
  
  <!-- Odświeżanie pojedynczych słowników -->
  <div class="dictionary-controls">
    <button (click)="refreshRecipients()" [disabled]="isRefreshing()">
      🔄 Odśwież Odbiorców
    </button>
    
    <button (click)="refreshBusinessLines()" [disabled]="isRefreshing()">
      🔄 Odśwież Linie Biznesowe
    </button>
    
    <button (click)="refreshTenants()" [disabled]="isRefreshing()">
      🔄 Odśwież Tenantów
    </button>
    
    <button (click)="refreshStatuses()" [disabled]="isRefreshing()">
      🔄 Odśwież Statusy
    </button>
  </div>
  
  <!-- Odświeżanie wszystkich jednocześnie -->
  <div class="refresh-all">
    <button 
      class="primary-button" 
      (click)="refreshAll()" 
      [disabled]="isRefreshing()">
      ♻️ Odśwież Wszystkie Słowniki
    </button>
  </div>
  
  <!-- Status info -->
  @if (lastRefresh()) {
    <div class="info">
      Ostatnie odświeżenie: {{ lastRefresh() | date:'medium' }}
    </div>
  }
</div>
```

```typescript
// admin-dictionaries.component.ts
export class AdminDictionariesComponent {
  private externalDataService = inject(ExternalDataService);
  
  isRefreshing = signal(false);
  lastRefresh = signal<string | null>(null);
  
  refreshRecipients() {
    this.isRefreshing.set(true);
    this.externalDataService.refreshRecipients()
      .pipe(finalize(() => this.isRefreshing.set(false)))
      .subscribe(() => {
        this.lastRefresh.set(new Date().toISOString());
        console.log('✅ Recipients refreshed');
      });
  }
  
  refreshAll() {
    this.isRefreshing.set(true);
    this.externalDataService.refreshAllDictionaries()
      .pipe(finalize(() => this.isRefreshing.set(false)))
      .subscribe(result => {
        this.lastRefresh.set(result.refreshedAt);
        console.log('✅ All dictionaries refreshed');
      });
  }
}
```

## ✅ Status

- ✅ Base URL zaktualizowany
- ✅ Wszystkie GET endpointy zaktualizowane
- ✅ Dodane metody refresh dla pojedynczych słowników
- ✅ Dodana metoda refreshAllDictionaries
- ✅ Dodane typy RefreshResult i RefreshAllResult
- ✅ Rozszerzona metoda clearCache z loggingiem
- ✅ Brak błędów kompilacji
- ⏳ Admin UI do odświeżania (do zaimplementowania)

## 🚀 Testowanie

```bash
# Uruchom aplikację
cd d2creatorfrontend/D2GuiCreator
npm start

# W konsoli przeglądarki sprawdź:
# 1. URL API - powinno być: /api/v1/dictionaries/recipients
# 2. Logging z serwisu:
#    🌐 ExternalDataService initialized
#    📍 API Base URL: http://localhost:5000/api/v1/dictionaries
#    📡 Calling API: http://localhost:5000/api/v1/dictionaries/recipients
```

## 📚 Powiązane dokumenty

- Backend: `/d2creatorwebapi/D2ApiCreator/DICTIONARY_CONTROLLERS_REFACTORING.md`
- Ogólna implementacja: `/EXTERNAL_DATA_CACHE_IMPLEMENTATION.md`
