/**
 * Worker interface for field mapping configuration
 */
export interface Worker {
  id: string;
  projectVersionId: string;
  name: string;
  workerType: string;
  configJson: string;
  createdAt: string;
  updatedAt?: string;
}

/**
 * DTO for generating workers from document analysis
 */
export interface GenerateWorkersRequest {
  projectVersionId: string;
  placeholders: string[];
  contentControls: Record<string, string>;
}

/**
 * Parsed worker configuration
 */
export interface WorkerConfig {
  placeholder?: string;
  controlName?: string;
  controlType?: string;
  source: string;
  type: string;
  defaultValue: string;
  description: string;
}
