export interface WorkerFormData {
  name: string;
  workerType: string;
  description: string;
  defaultValue: string;
}
