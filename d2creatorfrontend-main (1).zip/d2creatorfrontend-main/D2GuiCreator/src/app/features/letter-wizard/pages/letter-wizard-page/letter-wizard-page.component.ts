import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, signal, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { WizardStepHeaderComponent } from '../../components/wizard-step-header/wizard-step-header.component';
import { WizardStepperComponent } from '../../components/wizard-stepper/wizard-stepper.component';
import { WizardFooterComponent } from '../../components/wizard-footer/wizard-footer.component';
import { DocumentDescriptionStepComponent } from '../../steps/document-description-step/document-description-step.component';
import { TemplateAndSchemaStepComponent } from '../../steps/template-and-schema-step/template-and-schema-step.component';
import { ConfigurationStepComponent } from '../../steps/configuration-step/configuration-step.component';
import { SummaryStepComponent } from '../../steps/summary-step/summary-step.component';
import { LetterWizardFacade } from '../../data-access/letter-wizard.facade';
import { LetterWizardData, LetterWizardStepKey } from '../../data-access/letter-wizard.model';
import { WizardStepperItem } from '../../components/wizard-stepper/wizard-stepper.model';
import { WizardDataService } from '../../services/wizard-data.service';
import { PlaceholderExtractionResult } from '../../services/document.service';
import { ExternalDataService } from '../../services/external-data.service';
import { RecipientDto, BusinessLineDto, StatusDto } from '../../data-access/external-data.model';

@Component({
  selector: 'app-letter-wizard-page',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    WizardStepHeaderComponent,
    WizardStepperComponent,
    WizardFooterComponent,
    DocumentDescriptionStepComponent,
    TemplateAndSchemaStepComponent,
    ConfigurationStepComponent,
    SummaryStepComponent
  ],
  templateUrl: './letter-wizard-page.component.html',
  styleUrls: ['./letter-wizard-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LetterWizardPageComponent {
  @ViewChild(TemplateAndSchemaStepComponent) templateAndSchemaStep?: TemplateAndSchemaStepComponent;

  readonly form: FormGroup;
  readonly isSaving = signal(false);
  readonly lastSaved = signal<string | null>(null);
  
  readonly recipients = signal<RecipientDto[]>([]);
  readonly businessLines = signal<BusinessLineDto[]>([]);
  readonly statuses = signal<StatusDto[]>([]);

  readonly stepOrder: LetterWizardStepKey[] = [
    'documentDescription',
    'templateAndSchema',
    'configuration',
    'summary'
  ];

  readonly currentStepIndex = signal(0);

  readonly currentStepKey = computed<LetterWizardStepKey>(
    () => this.stepOrder[this.currentStepIndex()]
  );

  readonly stepperItems = computed<WizardStepperItem[]>(() => {
    const activeIndex = this.currentStepIndex();
    const completedSteps = this.facade.completedSteps();

    const labelMap: Record<LetterWizardStepKey, string> = {
      documentDescription: 'Opis dokumentu',
      templateAndSchema: 'Szablon i schemat danych',
      configuration: 'Konfiguracja',
      summary: 'Podsumowanie'
    };

    return this.stepOrder.map((key, index) => {
      let status: 'todo' | 'in-progress' | 'accepted' = 'todo';

      if (index === activeIndex) {
        // Aktualny krok - zawsze w trakcie (pomarańczowy)
        status = 'in-progress';
      } else if (completedSteps.includes(key)) {
        // Krok został ukończony - zaakceptowany (zielony)
        status = 'accepted';
      } else if (index < activeIndex) {
        // Krok był przeglądany ale niekoniecznie ukończony - też zaakceptowany
        status = 'accepted';
      }

      return {
        key,
        index: index + 1,
        label: labelMap[key],
        status
      };
    });
  });

  readonly stepTitle = computed(() => {
    const isEditMode = this.facade.isEditMode();
    return isEditMode ? 'Edycja dokumentu' : 'Nowy dokument';
  });

  readonly stepDescription = computed(() => {
    const map: Record<LetterWizardStepKey, string> = {
      documentDescription: 'Wskaż istotne dane o dokumencie.',
      templateAndSchema: 'Wybierz szablon i schemat danych.',
      configuration: 'Skonfiguruj sposób działania dokumentu.',
      summary: 'Sprawdź i zatwierdź konfigurację dokumentu.'
    };
    return map[this.currentStepKey()];
  });

  projectId: string | null = null;

  constructor(
    private readonly fb: FormBuilder,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly facade: LetterWizardFacade,
    private readonly wizardDataService: WizardDataService,
    private readonly externalDataService: ExternalDataService
  ) {
    this.form = this.fb.group({
      general: this.fb.group({
        documentName: ['', Validators.required],
        sourceIdentifier: [''],
        applicationName: ['', Validators.required],
        recipient: [null, Validators.required],
        retentionDays: [90, [Validators.required, Validators.min(1)]],
        environments: this.fb.control<string[]>([])
      }),
      business: this.fb.group({
        processName: ['', Validators.required],
        businessLine: [null, Validators.required],
        tenant: [null], // Optional - can create personal projects or team projects
        processOwner: ['', Validators.required],
        processVersion: ['', Validators.required],
        processStep: ['', Validators.required],
        status: ['', Validators.required]
      }),
      templateAndSchema: this.fb.group({
        templateId: [''],
        dataSchemaId: [''],
        defaultLanguage: [''],
        outputFormat: ['pdf']
      }),
      configuration: this.fb.group({
        autoSendEnabled: [false],
        requiresApproval: [false],
        approvalRole: [''],
        visibilityScope: ['internal']
      })
    });

    this.projectId = this.route.snapshot.paramMap.get('projectId');
    const versionId = this.route.snapshot.queryParamMap.get('versionId');
    const mode = this.route.snapshot.queryParamMap.get('mode');
    
    if (this.projectId) {
      if (versionId && mode === 'edit') {
        // Tryb edycji - ładuj dane z API
        console.log('🔄 Loading existing project for edit:', this.projectId, versionId);
        
        this.facade.loadProjectData(this.projectId, versionId).subscribe({
          next: (success) => {
            if (success) {
              console.log('✅ Project data loaded successfully');
              
              // Populate form with loaded data
              const wizardData = this.facade.state()?.data;
              if (wizardData) {
                console.log('📋 Filling form with loaded data:', wizardData);
                this.form.patchValue(wizardData);
                
                // Force change detection
                this.form.updateValueAndValidity();
              }

              // Set current step from facade
              const currentStep = this.facade.currentStep();
              if (currentStep) {
                const stepIndex = this.stepOrder.indexOf(currentStep);
                this.currentStepIndex.set(stepIndex >= 0 ? stepIndex : 0);
                console.log('🎯 Current step set to:', currentStep, 'index:', stepIndex);
              }
            } else {
              console.error('❌ Failed to load project data');
              alert('Nie udało się załadować danych projektu');
              this.router.navigate(['/projects']);
            }
          },
          error: (error) => {
            console.error('❌ Error loading project:', error);
            alert('Wystąpił błąd podczas ładowania projektu');
            this.router.navigate(['/projects']);
          }
        });
      } else {
        // Tryb tworzenia nowego
        this.facade.initNew(this.projectId);
      }
    }
    
    this.loadDictionaries();
  }
  
  private loadDictionaries(): void {
    this.externalDataService.getRecipients().subscribe({
      next: (data) => this.recipients.set(data),
      error: (err) => console.error('❌ Error loading recipients:', err)
    });
    
    this.externalDataService.getBusinessLines().subscribe({
      next: (data: BusinessLineDto[]) => this.businessLines.set(data),
      error: (err: any) => console.error('❌ Error loading business lines:', err)
    });
    
    this.externalDataService.getStatuses().subscribe({
      next: (data: StatusDto[]) => this.statuses.set(data),
      error: (err: any) => console.error('❌ Error loading statuses:', err)
    });
  }

  onPlaceholdersExtracted(result: PlaceholderExtractionResult): void {
    console.log('📋 Placeholders extracted, storing for worker generation');
    this.facade.storePlaceholderExtractionResult(result);
  }

  onStepperClick(item: WizardStepperItem): void {
    // Pozwól na kliknięcie tylko zaakceptowanych kroków lub aktualnego
    if (item.status === 'todo') {
      return;
    }
    
    const targetIndex = item.index - 1;
    if (targetIndex < 0 || targetIndex >= this.stepOrder.length) {
      return;
    }
    
    // Zapisz aktualny stan przed zmianą kroku
    const value = this.form.getRawValue() as LetterWizardData;
    this.facade.updateData(value);
    
    // Przejdź do wybranego kroku
    this.currentStepIndex.set(targetIndex);
    this.facade.moveToStep(this.stepOrder[targetIndex]);
  }

  onSave(): void {
    const value = this.form.getRawValue() as LetterWizardData;
    this.facade.updateData(value);
    
    this.isSaving.set(true);
    console.log('💾 Zapisywanie bieżącego stanu kreatora...');

    // Zapisz dane w zależności od aktualnego kroku
    const currentStep = this.currentStepKey();
    
    if (currentStep === 'documentDescription') {
      // Krok 1 - zapis podstawowych danych projektu
      this.facade.saveFirstStepData().subscribe({
        next: (result) => {
          this.isSaving.set(false);
          if (result) {
            const now = new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
            this.lastSaved.set(now);
            console.log('✅ Stan kreatora zapisany pomyślnie');
          } else {
            console.error('❌ Błąd zapisu');
            alert('Wystąpił błąd podczas zapisywania');
          }
        },
        error: (error) => {
          this.isSaving.set(false);
          console.error('❌ Błąd podczas zapisywania:', error);
          alert('Wystąpił błąd podczas zapisywania');
        }
      });
    } else if (currentStep === 'templateAndSchema') {
      // Krok 2 - zapis szablonu
      const uploadedFile = this.templateAndSchemaStep?.getUploadedFile();
      
      this.facade.saveSecondStepData(uploadedFile || null).subscribe({
        next: (result) => {
          this.isSaving.set(false);
          if (result) {
            const now = new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
            this.lastSaved.set(now);
            console.log('✅ Stan kreatora zapisany pomyślnie');
          } else {
            console.error('❌ Błąd zapisu');
            alert('Wystąpił błąd podczas zapisywania');
          }
        },
        error: (error) => {
          this.isSaving.set(false);
          console.error('❌ Błąd podczas zapisywania:', error);
          alert('Wystąpił błąd podczas zapisywania');
        }
      });
    } else {
      // Pozostałe kroki - po prostu aktualizuj stepData
      const projectId = this.facade.state()?.meta.projectId;
      const versionId = this.facade.state()?.meta.id;
      
      if (projectId && versionId) {
        this.wizardDataService.updateProjectVersionStepData(projectId, versionId, value).subscribe({
          next: () => {
            this.isSaving.set(false);
            const now = new Date().toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
            this.lastSaved.set(now);
            console.log('✅ Stan kreatora zapisany pomyślnie');
          },
          error: (error) => {
            this.isSaving.set(false);
            console.error('❌ Błąd podczas zapisywania:', error);
            alert('Wystąpił błąd podczas zapisywania');
          }
        });
      } else {
        this.isSaving.set(false);
        console.error('❌ Brak ID projektu lub wersji');
        alert('Nie można zapisać - brak ID projektu');
      }
    }
  }

  onNext(): void {
    // Walidacja dla kroku "Opis dokumentu"
    if (this.currentStepKey() === 'documentDescription') {
      // Oznacz wszystkie pola jako touched aby pokazać błędy
      this.generalGroup.markAllAsTouched();
      this.businessGroup.markAllAsTouched();
      
      // Sprawdź czy formularze są poprawne
      if (this.generalGroup.invalid || this.businessGroup.invalid) {
        console.warn('⚠️ Formularz zawiera błędy walidacji');
        return; // Zatrzymaj przejście do następnego kroku
      }

      // Po walidacji pierwszego kroku - zapisz dane do backendu
      const value = this.form.getRawValue() as LetterWizardData;
      this.facade.updateData(value);

      console.log('💾 Zapisuję dane pierwszego kroku...');
      this.facade.saveFirstStepData().subscribe({
        next: (result) => {
          if (result) {
            console.log('✅ Dane pierwszego kroku zapisane pomyślnie');
            console.log('   Project ID:', result.project.id);
            console.log('   Version ID:', result.version.id);
            
            // Oznacz krok jako ukończony i przejdź dalej
            const idx = this.currentStepIndex();
            const key = this.currentStepKey();
            this.facade.markStepCompleted(key);
            this.currentStepIndex.set(idx + 1);
            this.facade.moveToStep(this.stepOrder[idx + 1]);
          } else {
            console.error('❌ Błąd zapisu - brak wyniku');
            alert('Wystąpił błąd podczas zapisywania danych. Sprawdź konsolę.');
          }
        },
        error: (error) => {
          console.error('❌ Błąd podczas zapisywania danych pierwszego kroku:', error);
          alert('Wystąpił błąd podczas zapisywania danych. Sprawdź konsolę.');
        }
      });
      return;
    }

    // Walidacja dla kroku "Szablon i schemat danych"
    if (this.currentStepKey() === 'templateAndSchema') {
      // Oznacz formularz jako touched
      this.templateAndSchemaGroup.markAllAsTouched();

      // Sprawdź czy plik został wybrany
      const templateId = this.templateAndSchemaGroup.get('templateId')?.value;
      if (!templateId) {
        console.warn('⚠️ Nie wybrano pliku szablonu');
        alert('Proszę wybrać plik szablonu dokumentu (.docx)');
        return;
      }

      // Sprawdź czy schemat został wygenerowany
      const dataSchemaId = this.templateAndSchemaGroup.get('dataSchemaId')?.value;
      if (!dataSchemaId) {
        console.warn('⚠️ Schemat danych nie został wygenerowany');
        alert('Schemat danych nie został wygenerowany. Spróbuj ponownie wczytać plik.');
        return;
      }

      // Pobierz plik z komponentu kroku
      const uploadedFile = this.templateAndSchemaStep?.getUploadedFile();
      
      // Jeśli nie ma pliku ale mamy templateId (tryb edycji), to OK - plik już jest w systemie
      if (!uploadedFile && !templateId) {
        console.warn('⚠️ Nie znaleziono wczytanego pliku');
        alert('Nie znaleziono wczytanego pliku. Spróbuj ponownie.');
        return;
      }

      // Zaktualizuj dane w facade
      const value = this.form.getRawValue() as LetterWizardData;
      this.facade.updateData(value);

      console.log('💾 Zapisuję dane drugiego kroku...');
      if (uploadedFile) {
        console.log('   Plik:', uploadedFile.name);
      } else {
        console.log('   Plik już zapisany (templateId):', templateId);
      }
      console.log('   Schemat:', dataSchemaId.substring(0, 100) + '...');

      this.facade.saveSecondStepData(uploadedFile || null).subscribe({
        next: (result) => {
          if (result) {
            console.log('✅ Dane drugiego kroku zapisane pomyślnie');
            if (result.fileUpload) {
              console.log('   File ID:', result.fileUpload.fileId);
            }
            console.log('   Step data updated');
            
            // Oznacz krok jako ukończony i przejdź dalej
            const idx = this.currentStepIndex();
            const key = this.currentStepKey();
            this.facade.markStepCompleted(key);
            this.currentStepIndex.set(idx + 1);
            this.facade.moveToStep(this.stepOrder[idx + 1]);
          } else {
            console.error('❌ Błąd zapisu - brak wyniku');
            alert('Wystąpił błąd podczas zapisywania danych. Sprawdź konsolę.');
          }
        },
        error: (error) => {
          console.error('❌ Błąd podczas zapisywania danych drugiego kroku:', error);
          alert('Wystąpił błąd podczas zapisywania danych. Sprawdź konsolę.');
        }
      });
      return;
    }

    // Dla pozostałych kroków - standardowe przejście
    const value = this.form.getRawValue() as LetterWizardData;
    this.facade.updateData(value);

    const idx = this.currentStepIndex();
    const key = this.currentStepKey();

    this.facade.markStepCompleted(key);

    if (idx < this.stepOrder.length - 1) {
      this.currentStepIndex.set(idx + 1);
      this.facade.moveToStep(this.stepOrder[idx + 1]);
    } else {
      console.log('✅ Wizard finished', value);
      
      // Pobierz projectId z facade state
      const projectId = this.facade.getCreatedProjectId() || this.projectId;
      
      if (projectId) {
        console.log('📍 Navigating to project:', projectId);
        this.router.navigate(['/projects']);
      } else {
        console.warn('⚠️ No project ID available, navigating to projects list');
        this.router.navigate(['/projects']);
      }
    }
  }

  onBack(): void {
    const idx = this.currentStepIndex();
    if (idx === 0) {
      return;
    }
    this.currentStepIndex.set(idx - 1);
    this.facade.moveToStep(this.stepOrder[idx - 1]);
  }

  onCancel(): void {
    if (this.projectId) {
      this.router.navigate(['/projects', this.projectId]);
    } else {
      this.router.navigate(['/projects']);
    }
  }

  get generalGroup(): FormGroup {
    return this.form.get('general') as FormGroup;
  }

  get businessGroup(): FormGroup {
    return this.form.get('business') as FormGroup;
  }

  get templateAndSchemaGroup(): FormGroup {
    return this.form.get('templateAndSchema') as FormGroup;
  }

  get configurationGroup(): FormGroup {
    return this.form.get('configuration') as FormGroup;
  }
}
