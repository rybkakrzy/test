import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, OnInit, signal, inject, computed } from '@angular/core';
import { FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { WorkerService } from '../../services/worker.service';
import type { Worker } from '../../models/worker.model';
import { WorkerFormData } from '../../models/worker-form.model';
import { LetterWizardFacade } from '../../data-access/letter-wizard.facade';
import { WorkerDialogComponent } from '../../components/worker-dialog/worker-dialog.component';
import { ButtonComponent } from '../../../../shared/ui/button/button.component';

@Component({
  selector: 'app-configuration-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, WorkerDialogComponent, ButtonComponent],
  templateUrl: './configuration-step.component.html',
  styleUrl: './configuration-step.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfigurationStepComponent implements OnInit {
  @Input() group!: FormGroup;

  private readonly workerService = inject(WorkerService);
  private readonly facade = inject(LetterWizardFacade);

  isLoadingWorkers = signal(false);
  isDialogOpen = signal(false);
  editingWorker = signal<Worker | undefined>(undefined);
  workers = signal<Worker[]>([]);
  
  // Wyszukiwanie i stronicowanie
  searchName = signal('');
  searchWorkerType = signal('');
  searchConfig = signal('');
  currentPage = signal(1);
  pageSize = signal(10);
  
  // Computed: filtrowane workers
  filteredWorkers = computed(() => {
    const workers = this.workers();
    const nameSearch = this.searchName().toLowerCase();
    const typeSearch = this.searchWorkerType().toLowerCase();
    const configSearch = this.searchConfig().toLowerCase();
    
    return workers.filter(w => {
      const matchesName = !nameSearch || w.name.toLowerCase().includes(nameSearch);
      const matchesType = !typeSearch || w.workerType.toLowerCase().includes(typeSearch);
      const matchesConfig = !configSearch || w.configJson.toLowerCase().includes(configSearch);
      
      return matchesName && matchesType && matchesConfig;
    });
  });
  
  // Computed: całkowita liczba stron
  totalPages = computed(() => 
    Math.ceil(this.filteredWorkers().length / this.pageSize())
  );
  
  // Computed: workers na bieżącej stronie
  paginatedWorkers = computed(() => {
    const filtered = this.filteredWorkers();
    const page = this.currentPage();
    const size = this.pageSize();
    const start = (page - 1) * size;
    return filtered.slice(start, start + size);
  });
  
  // Computed: informacje o zakresie
  displayRange = computed(() => {
    const total = this.filteredWorkers().length;
    if (total === 0) return '0-0 z 0';
    const page = this.currentPage();
    const size = this.pageSize();
    const start = (page - 1) * size + 1;
    const end = Math.min(start + size - 1, total);
    return `${start}-${end} z ${total}`;
  });

  constructor() {}

  ngOnInit(): void {
    // Pobierz workers dla bieżącego projektu
    this.loadWorkers();
  }

  private loadWorkers(): void {
    const versionId = this.facade.getCreatedVersionId();
    if (!versionId) {
      console.warn('⚠️ No version ID available, cannot load workers');
      return;
    }

    this.isLoadingWorkers.set(true);
    this.workerService.getWorkersByProjectVersion(versionId).subscribe({
      next: (workers) => {
        console.log('✅ Workers loaded:', workers.length);
        this.workers.set(workers);
        this.isLoadingWorkers.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading workers:', error);
        this.isLoadingWorkers.set(false);
      }
    });
  }

  parseWorkerConfig(configJson: string): any {
    try {
      return JSON.parse(configJson);
    } catch {
      return {};
    }
  }
  
  onSearchNameChange(term: string): void {
    this.searchName.set(term);
    this.currentPage.set(1);
  }
  
  onSearchWorkerTypeChange(term: string): void {
    this.searchWorkerType.set(term);
    this.currentPage.set(1);
  }
  
  onSearchConfigChange(term: string): void {
    this.searchConfig.set(term);
    this.currentPage.set(1);
  }
  
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }
  
  previousPage(): void {
    this.goToPage(this.currentPage() - 1);
  }
  
  nextPage(): void {
    this.goToPage(this.currentPage() + 1);
  }
  
  changePageSize(size: number): void {
    this.pageSize.set(size);
    this.currentPage.set(1);
  }

  getPageNumbers(): number[] {
    const total = this.totalPages();
    const current = this.currentPage();
    const delta = 2;
    const range: number[] = [];
    
    for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) {
      range.push(i);
    }
    
    if (current - delta > 2) {
      range.unshift(-1);
    }
    if (current + delta < total - 1) {
      range.push(-1);
    }
    
    range.unshift(1);
    if (total > 1) {
      range.push(total);
    }
    
    return range;
  }

  addWorker(): void {
    this.editingWorker.set(undefined);
    this.isDialogOpen.set(true);
  }

  editWorker(worker: Worker): void {
    this.editingWorker.set(worker);
    this.isDialogOpen.set(true);
  }

  deleteWorker(worker: Worker): void {
    if (!confirm(`Czy na pewno chcesz usunąć worker "${worker.name}"?`)) {
      return;
    }

    this.workerService.deleteWorker(worker.id).subscribe({
      next: () => {
        console.log('✅ Worker deleted');
        this.loadWorkers();
      },
      error: (error) => {
        console.error('❌ Error deleting worker:', error);
        alert('Wystąpił błąd podczas usuwania workera');
      }
    });
  }

  closeDialog(): void {
    this.isDialogOpen.set(false);
    this.editingWorker.set(undefined);
  }

  saveWorker(formData: WorkerFormData): void {
    const versionId = this.facade.getCreatedVersionId();
    if (!versionId) {
      console.error('No version ID available');
      return;
    }

    const editingWorker = this.editingWorker();
    
    if (editingWorker) {
      // Update existing worker
      this.workerService.updateWorker(editingWorker.id, formData).subscribe({
        next: () => {
          console.log('✅ Worker updated');
          this.closeDialog();
          this.loadWorkers();
        },
        error: (error) => {
          console.error('❌ Error updating worker:', error);
          alert('Wystąpił błąd podczas aktualizacji workera');
        }
      });
    } else {
      // Create new worker
      this.workerService.createWorker(versionId, formData).subscribe({
        next: () => {
          console.log('✅ Worker created');
          this.closeDialog();
          this.loadWorkers();
        },
        error: (error) => {
          console.error('❌ Error creating worker:', error);
          alert('Wystąpił błąd podczas tworzenia workera');
        }
      });
    }
  }
}
