import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, OnInit, signal, inject, computed } from '@angular/core';
import { LetterWizardData } from '../../data-access/letter-wizard.model';
import { RecipientDto, BusinessLineDto, StatusDto } from '../../data-access/external-data.model';
import { ButtonComponent } from '../../../../shared/ui/button/button.component';
import { WorkerService } from '../../services/worker.service';
import { LetterWizardFacade } from '../../data-access/letter-wizard.facade';
import type { Worker } from '../../models/worker.model';

@Component({
  selector: 'app-summary-step',
  standalone: true,
  imports: [CommonModule, ButtonComponent],
  templateUrl: './summary-step.component.html',
  styleUrls: ['./summary-step.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SummaryStepComponent implements OnInit {
  @Input() data!: LetterWizardData;
  @Input() recipients: RecipientDto[] = [];
  @Input() businessLines: BusinessLineDto[] = [];
  @Input() statuses: StatusDto[] = [];

  private readonly workerService = inject(WorkerService);
  private readonly facade = inject(LetterWizardFacade);
  
  workers = signal<Worker[]>([]);
  isLoadingWorkers = signal(false);
  
  // Pagination
  currentPage = signal(1);
  pageSize = signal(10);
  
  totalPages = computed(() => {
    return Math.ceil(this.workers().length / this.pageSize());
  });
  
  paginatedWorkers = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize();
    const end = start + this.pageSize();
    return this.workers().slice(start, end);
  });

  detectedElements = computed(() => {
    const result = this.facade.getPlaceholderExtractionResult();
    if (!result) return [];
    
    const elements: Array<{name: string, type: string}> = [];
    
    // Dodaj placeholders
    if (result.placeholders) {
      result.placeholders.forEach(p => {
        // Sprawdź czy placeholder już ma <% i %>, jeśli nie - dodaj
        const name = p.startsWith('<%') ? p : `<%${p}%>`;
        elements.push({
          name: name,
          type: 'placeholder'
        });
      });
    }
    
    // Dodaj content controls
    if (result.contentControls) {
      Object.entries(result.contentControls).forEach(([key, value]) => {
        elements.push({
          name: key,
          type: value as string
        });
      });
    }
    
    return elements;
  });

  ngOnInit(): void {
    this.loadWorkers();
  }

  private loadWorkers(): void {
    const versionId = this.facade.getCreatedVersionId();
    if (!versionId) {
      console.warn('⚠️ No version ID available, cannot load workers');
      return;
    }

    this.isLoadingWorkers.set(true);
    this.workerService.getWorkersByProjectVersion(versionId).subscribe({
      next: (workers) => {
        console.log('✅ Workers loaded for summary:', workers.length);
        this.workers.set(workers);
        this.isLoadingWorkers.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading workers:', error);
        this.isLoadingWorkers.set(false);
      }
    });
  }

  getEnvironmentsText(): string {
    const environments = this.data.general?.environments;
    if (!environments || environments.length === 0) {
      return '-';
    }
    
    const envMap: Record<string, string> = {
      'dev': 'DEV',
      'test': 'TEST',
      'uat': 'UAT',
      'prod': 'PROD'
    };
    
    return environments.map(env => envMap[env] || env.toUpperCase()).join(', ');
  }
  
  getBusinessLineText(): string {
    const code = this.data.business?.businessLine;
    if (!code) return '-';
    
    const businessLine = this.businessLines.find(bl => bl.code === code);
    return businessLine?.name || code;
  }
  
  getRecipientText(): string {
    const code = this.data.general?.recipient;
    if (!code) return '-';
    
    const recipient = this.recipients.find(r => r.code === code);
    return recipient?.name || code;
  }
  
  getStatusText(): string {
    const code = this.data.business?.status;
    if (!code) return '-';
    
    const status = this.statuses.find(s => s.code === code);
    return status?.name || code;
  }
  
  getVisibilityScopeText(): string {
    const scope = this.data.configuration?.visibilityScope;
    if (!scope) return '-';
    
    const scopeMap: Record<string, string> = {
      'internal': 'Wewnętrzny',
      'external': 'Zewnętrzny',
      'public': 'Publiczny'
    };
    
    return scopeMap[scope] || scope;
  }
  
  getTemplateText(): string {
    const templateId = this.data.templateAndSchema?.templateId;
    if (!templateId) return '-';
    
    // Jeśli to GUID, wyświetl "Szablon wczytany"
    const guidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (guidPattern.test(templateId)) {
      return 'Szablon wczytany z pliku';
    }
    
    return templateId;
  }

  // Pagination methods
  previousPage(): void {
    if (this.currentPage() > 1) {
      this.currentPage.set(this.currentPage() - 1);
    }
  }

  nextPage(): void {
    if (this.currentPage() < this.totalPages()) {
      this.currentPage.set(this.currentPage() + 1);
    }
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }

  getPageNumbers(): number[] {
    const total = this.totalPages();
    const current = this.currentPage();
    const pages: number[] = [];

    if (total <= 7) {
      // Show all pages if 7 or fewer
      for (let i = 1; i <= total; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);

      if (current > 3) {
        pages.push(-1); // Ellipsis
      }

      // Show pages around current
      const start = Math.max(2, current - 1);
      const end = Math.min(total - 1, current + 1);
      
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }

      if (current < total - 2) {
        pages.push(-1); // Ellipsis
      }

      // Always show last page
      pages.push(total);
    }

    return pages;
  }
}
