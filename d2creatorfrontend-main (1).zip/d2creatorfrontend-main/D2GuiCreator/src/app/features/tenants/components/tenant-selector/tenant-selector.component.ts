import { Component, Input, Output, EventEmitter, signal, OnInit, inject, forwardRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { TenantService, Tenant } from '../../services/tenant.service';
import { ButtonComponent } from '../../../../shared/ui/button/button.component';

@Component({
  selector: 'app-tenant-selector',
  standalone: true,
  imports: [CommonModule, FormsModule, ButtonComponent],
  templateUrl: './tenant-selector.component.html',
  styleUrls: ['./tenant-selector.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TenantSelectorComponent),
      multi: true
    }
  ]
})
export class TenantSelectorComponent implements ControlValueAccessor, OnInit {
  private readonly tenantService = inject(TenantService);

  @Input() corporateKey = 'TEMP_USER'; // TODO: Get from auth service
  @Input() userId = '00000000-0000-0000-0000-000000000000'; // TODO: Get from auth service
  @Output() createNewTenant = new EventEmitter<void>();

  readonly tenants = signal<Tenant[]>([]);
  readonly filteredTenants = signal<Tenant[]>([]);
  readonly isLoading = signal(false);
  readonly isOpen = signal(false);
  readonly searchTerm = signal('');
  
  selectedTenant: Tenant | null = null;
  
  private onChange: (value: string | null) => void = () => {};
  private onTouched: () => void = () => {};

  ngOnInit(): void {
    this.loadTenants();
  }

  writeValue(value: string | null): void {
    if (value) {
      const tenant = this.tenants().find(t => t.id === value);
      this.selectedTenant = tenant || null;
    } else {
      this.selectedTenant = null;
    }
  }

  registerOnChange(fn: (value: string | null) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  loadTenants(): void {
    this.isLoading.set(true);
    this.tenantService.getTenants(this.corporateKey).subscribe({
      next: (tenants) => {
        this.tenants.set(tenants);
        this.filteredTenants.set(tenants);
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Error loading tenants:', error);
        this.isLoading.set(false);
      }
    });
  }

  onSearchChange(value: string): void {
    this.searchTerm.set(value);
    
    if (!value.trim()) {
      this.filteredTenants.set(this.tenants());
      return;
    }

    const filtered = this.tenants().filter(t =>
      t.name.toLowerCase().includes(value.toLowerCase())
    );
    this.filteredTenants.set(filtered);
  }

  toggleDropdown(): void {
    this.isOpen.set(!this.isOpen());
    if (this.isOpen()) {
      this.onTouched();
    }
  }

  selectTenant(tenant: Tenant): void {
    this.selectedTenant = tenant;
    this.onChange(tenant.id);
    this.isOpen.set(false);
    this.searchTerm.set('');
    this.filteredTenants.set(this.tenants());
  }

  clearSelection(): void {
    this.selectedTenant = null;
    this.onChange(null);
  }

  onCreateNew(): void {
    this.createNewTenant.emit();
    this.isOpen.set(false);
  }

  getDisplayText(): string {
    if (this.selectedTenant) {
      return `${this.selectedTenant.name} (${this.selectedTenant.memberCount})`;
    }
    return 'Wybierz zespół projektowy...';
  }
}
