import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, signal, OnChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Project, ProjectStatus } from '../../../../shared/models/project.model';

@Component({
  selector: 'app-project-list-table',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './project-list-table.component.html',
  styleUrls: ['./project-list-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectListTableComponent implements OnChanges {
  @Input() projects: Project[] = [];
  @Output() projectClick = new EventEmitter<Project>();

  filters = {
    id: '',
    name: '',
    source: '',
    template: '',
    editor: '',
    date: ''
  };

  filteredProjects = signal<Project[]>([]);

  ngOnChanges(): void {
    this.applyFilters();
  }

  onFilterChange(): void {
    this.applyFilters();
  }

  private applyFilters(): void {
    let filtered = [...this.projects];

    if (this.filters.id) {
      filtered = filtered.filter(p => 
        p.id.toLowerCase().includes(this.filters.id.toLowerCase())
      );
    }

    if (this.filters.name) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(this.filters.name.toLowerCase())
      );
    }

    if (this.filters.source) {
      const source = this.getSource({ id: '', name: '', ownerName: '', status: 'Draft', createdAt: '' });
      // Filter by source if available in project data
    }

    if (this.filters.editor) {
      filtered = filtered.filter(p => 
        p.ownerName.toLowerCase().includes(this.filters.editor.toLowerCase())
      );
    }

    if (this.filters.date) {
      filtered = filtered.filter(p => 
        p.createdAt.includes(this.filters.date)
      );
    }

    this.filteredProjects.set(filtered);
  }

  onRowClick(project: Project): void {
    this.projectClick.emit(project);
  }

  getSource(project: Project): string {
    // Return actual source from project or construct from name
    return (project as any).source || 'DOC2_' + project.name.substring(0, 10).replace(/\s/g, '_');
  }

  getTemplate(project: Project): string {
    // Return actual template name from active version
    return (project as any).activeVersionTemplateName || 'szablon_dokumentu.docx';
  }

  getStatusLabel(status: ProjectStatus): string {
    const labels: Record<ProjectStatus, string> = {
      'Draft': 'Szkic',
      'InProgress': 'W trakcie',
      'Completed': 'Zakończony'
    };
    return labels[status] || status;
  }
}
