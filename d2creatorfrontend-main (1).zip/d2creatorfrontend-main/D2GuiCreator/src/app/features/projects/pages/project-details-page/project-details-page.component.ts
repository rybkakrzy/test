import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnInit, inject, signal, computed } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageLayoutComponent } from '../../../../shared/ui/page-layout/page-layout.component';
import { WizardDataService, ProjectResponse, ProjectVersionResponse } from '../../../letter-wizard/services/wizard-data.service';
import { ButtonComponent } from '../../../../shared/ui/button/button.component';
import { WorkerService } from '../../../letter-wizard/services/worker.service';
import type { Worker } from '../../../letter-wizard/models/worker.model';

@Component({
  selector: 'app-project-details-page',
  standalone: true,
  imports: [CommonModule, PageLayoutComponent, ButtonComponent],
  templateUrl: './project-details-page.component.html',
  styleUrls: ['./project-details-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectDetailsPageComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly wizardDataService = inject(WizardDataService);
  private readonly workerService = inject(WorkerService);

  readonly projectId = signal<string | null>(null);
  readonly project = signal<ProjectResponse | null>(null);
  readonly versions = signal<ProjectVersionResponse[]>([]);
  readonly latestVersion = signal<ProjectVersionResponse | null>(null);
  readonly workers = signal<Worker[]>([]);
  readonly isLoading = signal(false);
  readonly isLoadingVersions = signal(false);
  readonly isLoadingWorkers = signal(false);

  // Pagination
  readonly currentPage = signal(1);
  readonly pageSize = signal(10);
  
  readonly totalPages = computed(() => {
    return Math.ceil(this.workers().length / this.pageSize());
  });
  
  readonly paginatedWorkers = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize();
    const end = start + this.pageSize();
    return this.workers().slice(start, end);
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('projectId');
    this.projectId.set(id);
    
    if (id) {
      this.loadProject(id);
    }
  }

  private loadProject(id: string): void {
    this.isLoading.set(true);
    
    this.wizardDataService.getProject(id).subscribe({
      next: (project) => {
        console.log('✅ Project loaded:', project);
        this.project.set(project);
        this.isLoading.set(false);
        
        // Load versions
        this.loadVersions(id);
      },
      error: (error) => {
        console.error('❌ Error loading project:', error);
        this.isLoading.set(false);
      }
    });
  }

  private loadVersions(projectId: string): void {
    this.isLoadingVersions.set(true);
    
    this.wizardDataService.getProjectVersions(projectId).subscribe({
      next: (versions) => {
        console.log('✅ Versions loaded:', versions);
        this.versions.set(versions);
        
        // Find latest version (highest version number or most recent)
        if (versions && versions.length > 0) {
          const latest = versions.sort((a, b) => 
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          )[0];
          
          this.latestVersion.set(latest);
          console.log('📋 Latest version:', latest);
          
          // Load workers for latest version
          this.loadWorkers(latest.id);
        }
        
        this.isLoadingVersions.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading versions:', error);
        this.isLoadingVersions.set(false);
      }
    });
  }

  private loadWorkers(versionId: string): void {
    this.isLoadingWorkers.set(true);
    this.workerService.getWorkersByProjectVersion(versionId).subscribe({
      next: (workers) => {
        console.log('✅ Workers loaded:', workers);
        this.workers.set(workers);
        this.isLoadingWorkers.set(false);
      },
      error: (error) => {
        console.error('❌ Error loading workers:', error);
        this.isLoadingWorkers.set(false);
      }
    });
  }

  goBackToList(): void {
    this.router.navigate(['/projects']);
  }

  startWizard(): void {
    const id = this.projectId();
    const proj = this.project();
    
    if (!id || !proj) {
      return;
    }

    console.log('🚀 Starting wizard for project:', id);

    // Try to get versions to resume from last step
    this.wizardDataService.getProjectVersions(id).subscribe({
      next: (versions) => {
        if (versions && versions.length > 0) {
          // Sort by creation date to get the latest
          const latestVersion = versions.sort((a, b) => 
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          )[0];
          
          console.log('📝 Resuming with latest version:', latestVersion.id);
          
          this.router.navigate(['/projects', id, 'wizard'], {
            queryParams: { 
              versionId: latestVersion.id,
              mode: 'edit'
            }
          });
        } else {
          // No versions - start fresh
          console.log('✨ No versions found, starting new wizard');
          this.router.navigate(['/projects', id, 'wizard']);
        }
      },
      error: (error) => {
        console.error('❌ Error loading versions, starting fresh:', error);
        // On error, just start fresh wizard
        this.router.navigate(['/projects', id, 'wizard']);
      }
    });
  }

  activateVersion(versionId: string): void {
    const projectId = this.projectId();
    
    if (!projectId || !versionId) {
      return;
    }

    if (!confirm('Czy na pewno chcesz aktywować tę wersję projektu?')) {
      return;
    }

    console.log('🔄 Activating version:', versionId);

    this.wizardDataService.activateProjectVersion(projectId, versionId).subscribe({
      next: (result) => {
        console.log('✅ Version activated:', result);
        alert('Wersja została aktywowana pomyślnie');
        
        // Reload project and versions
        if (projectId) {
          this.loadProject(projectId);
        }
      },
      error: (error) => {
        console.error('❌ Error activating version:', error);
        alert('Wystąpił błąd podczas aktywacji wersji');
      }
    });
  }

  editVersion(versionId: string): void {
    const projectId = this.projectId();
    
    if (!projectId || !versionId) {
      return;
    }

    this.router.navigate(['/projects', projectId, 'wizard'], {
      queryParams: { 
        versionId: versionId,
        mode: 'edit'
      }
    });
  }

  viewVersions(): void {
    // TODO: Implement version history view
    console.log('📚 View versions - not implemented yet');
  }

  exportProject(): void {
    // TODO: Implement project export
    console.log('💾 Export project - not implemented yet');
  }

  // Helper methods for displaying data
  getStepData(key: string): any {
    const latest = this.latestVersion();
    return latest?.stepData?.[key] || null;
  }

  getProcessData(): any {
    return this.getStepData('business') || {};
  }

  getGeneralData(): any {
    return this.getStepData('general') || {};
  }

  getDetectedElements(): Array<{name: string, type: string}> {
    const latest = this.latestVersion();
    console.log('🔍 Getting detected elements from latest version:', latest);
    console.log('📋 StepData:', latest?.stepData);
    console.log('📋 TemplateAndSchema:', latest?.stepData?.templateAndSchema);
    
    const detectedElements = latest?.stepData?.templateAndSchema?.detectedElements;
    console.log('📋 Detected elements:', detectedElements);
    
    const elements: Array<{name: string, type: string}> = [];

    // Try to get from detectedElements first
    if (detectedElements) {
      // Add placeholders
      if (detectedElements.placeholders) {
        console.log('📌 Processing placeholders:', detectedElements.placeholders);
        detectedElements.placeholders.forEach((p: string) => {
          const name = p.startsWith('<%') ? p : `<%${p}%>`;
          elements.push({
            name: name,
            type: 'placeholder'
          });
        });
      }

      // Add content controls
      if (detectedElements.contentControls) {
        console.log('📌 Processing content controls:', detectedElements.contentControls);
        Object.entries(detectedElements.contentControls).forEach(([key, value]) => {
          elements.push({
            name: key,
            type: value as string
          });
        });
      }
    } else {
      // Fallback: extract unique elements from workers
      console.log('⚠️ No detected elements found, using workers as fallback');
      const workers = this.workers();
      const uniqueElements = new Set<string>();
      
      workers.forEach(worker => {
        try {
          const config = JSON.parse(worker.configJson);
          
          // Extract from "Podstaw wartość" type
          if (config['search-for'] || config['search_for']) {
            const searchFor = config['search-for'] || config['search_for'];
            uniqueElements.add(JSON.stringify({ name: searchFor, type: 'placeholder' }));
          }
          
          // Extract from "Stan" type
          if (config['tag-name'] || config['tag_name']) {
            const tagName = config['tag-name'] || config['tag_name'];
            uniqueElements.add(JSON.stringify({ name: tagName, type: 'boolean' }));
          }
        } catch (e) {
          console.warn('Failed to parse worker config:', worker.configJson);
        }
      });
      
      uniqueElements.forEach(elem => {
        const parsed = JSON.parse(elem);
        elements.push(parsed);
      });
    }

    console.log('✅ Final elements array:', elements);
    return elements;
  }

  // Pagination methods
  previousPage(): void {
    if (this.currentPage() > 1) {
      this.currentPage.set(this.currentPage() - 1);
    }
  }

  nextPage(): void {
    if (this.currentPage() < this.totalPages()) {
      this.currentPage.set(this.currentPage() + 1);
    }
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }

  getPageNumbers(): number[] {
    const total = this.totalPages();
    const current = this.currentPage();
    const pages: number[] = [];

    if (total <= 7) {
      // Show all pages if 7 or fewer
      for (let i = 1; i <= total; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      pages.push(1);

      if (current > 3) {
        pages.push(-1); // Ellipsis
      }

      // Show pages around current
      const start = Math.max(2, current - 1);
      const end = Math.min(total - 1, current + 1);
      
      for (let i = start; i <= end; i++) {
        pages.push(i);
      }

      if (current < total - 2) {
        pages.push(-1); // Ellipsis
      }

      // Always show last page
      pages.push(total);
    }

    return pages;
  }
}
