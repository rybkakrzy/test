import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
} from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { AppBuildInfo, AppConfigService } from '../../services/app-config.service';
import { EnvironmentBannerComponent } from '../environment-banner/environment-banner.component';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, EnvironmentBannerComponent],
  templateUrl: './app-shell.component.html',
  styleUrls: ['./app-shell.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppShellComponent {
   readonly currentUserName = computed(
    () => this.authService.getCurrentUser()?.name ?? 'User'
  );

  readonly buildInfo: AppBuildInfo;

  constructor(
    private readonly authService: AuthService,
    private readonly appConfig: AppConfigService
  ) {
    this.buildInfo = this.appConfig.getBuildInfo();
  }
}
