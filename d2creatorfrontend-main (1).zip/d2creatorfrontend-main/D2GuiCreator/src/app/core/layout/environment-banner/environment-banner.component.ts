import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '../../../../environments/environment';
import { ApiConnectionService } from '../../services/api-connection.service';

type EnvironmentType = 'local' | 'dev' | 'uat' | 'preprd' | 'prd';
type BannerType = 'error' | 'local' | 'dev' | 'uat' | 'preprd' | 'none';

@Component({
  selector: 'app-environment-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './environment-banner.component.html',
  styleUrls: ['./environment-banner.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EnvironmentBannerComponent {
  private readonly apiConnectionService = inject(ApiConnectionService);
  
  readonly isProduction = environment.production;
  readonly environmentName = environment.name.toUpperCase();
  readonly envType = environment.name as EnvironmentType;
  
  readonly isApiConnected = this.apiConnectionService.isApiConnected;

  readonly showBanner = computed(() => {
    // Pokaż banner jeśli:
    // 1. Brak połączenia z API (zawsze)
    // 2. Środowisko nieprodukcyjne
    return !this.isApiConnected() || !this.isProduction;
  });

  readonly bannerType = computed((): BannerType => {
    if (!this.isApiConnected()) {
      return 'error'; // Czerwony - brak połączenia
    }
    if (!this.isProduction) {
      // Zwracamy typ środowiska dla odpowiedniego koloru
      return this.envType as BannerType;
    }
    return 'none';
  });

  readonly bannerMessage = computed(() => {
    if (!this.isApiConnected()) {
      return 'Brak połączenia z API — Aplikacja nie może nawiązać połączenia z serwerem';
    }
    return `Aplikacja pracuje w środowisku nieprodukcyjnym: ${this.environmentName}`;
  });
}
