import { Routes } from '@angular/router';
import { AppShellComponent } from './core/layout/app-shell/app-shell.component';

export const APP_ROUTES: Routes = [
  {
    path: '',
    component: AppShellComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'projects'
      },
      {
        path: 'projects',
        loadChildren: () =>
          import('./features/projects/projects.routes').then(
            m => m.PROJECTS_ROUTES
          )
      },
      {
        path: 'teams',
        loadComponent: () =>
          import('./features/tenants/pages/my-teams-page/my-teams-page.component').then(
            m => m.MyTeamsPageComponent
          )
      },
      {
        path: 'error',
        loadChildren: () =>
          import('./features/error/error.routes').then(
            m => m.ERROR_ROUTES
          )
      },
      {
        path: '**',
        redirectTo: 'error/not-found'
      }
    ]
  }
];
