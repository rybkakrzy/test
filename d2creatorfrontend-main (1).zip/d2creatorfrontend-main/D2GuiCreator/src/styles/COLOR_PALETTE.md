# Paleta Kolorów - D2GuiCreator

## Proporcje użycia kolorów (zgodnie z Color Ratio)

### 🟠 Orange (50% - Kolor Dominujący)
- **Primary Color**: `$color-primary` = `#FF6200`
- **Użycie**: 
  - Główne przyciski akcji (Dalej, Wyślij)
  - Nagłówki stron i sekcji
  - Scrollbary
  - Elementy interaktywne drag & drop
  - Ikony i wskaźniki aktywnego stanu
  - Linki i elementy podświetlone
  - Spinnery i loadery

**Warianty**:
- Hover: `$color-primary-hover` (ciemniejszy o 8%)
- Tło światło: `$color-primary-light` (jaśniejszy o 35%)

---

### 💖 Raspberry (20% - Akcenty Wyraziste)
- **Accent Color**: `$color-accent` = `#D40199`
- **Użycie**:
  - Przyciski drugorzędne (Zapisz)
  - Przyciski pomocnicze (Instrukcja)
  - Wskaźniki i etykiety
  - Elementy wymagające uwagi
  - Dekoracyjne akcenty

**Warianty**:
- Ciemniejszy: `$color-accent-hover` = `#8F096A`
- Tło światło: `$color-accent-light` = `#FFE6F5`

---

### ☀️ Sun (15% - Akcenty Ciepłe)
- **Tertiary Color**: `$color-tertiary` = `#FFE100`
- **Użycie**:
  - Przyciski pomocnicze specjalne (API Request, Generowanie testów)
  - Wskaźniki ostrzeżeń
  - Elementy informacyjne
  - Dekoracje i podkreślenia

**Warianty**:
- Ciemniejszy: `$color-tertiary-hover` = `#C08C00`
- Tło światło: `$color-tertiary-light` = `#FFFCE5`

---

### 🍷 Maroon (15% - Akcenty Ciemne)
- **Secondary Color**: `$color-secondary` = `#4D0020`
- **Użycie**:
  - Przyciski anulowania (Ghost buttons)
  - Elementy nawigacji
  - Tekst nagłówków alternatywnych
  - Bordery elementów neutralnych

**Warianty**:
- Ciemniejszy: `$color-secondary-hover` = `#340016`
- Tło światło: `$color-secondary-light` = `#FFE5F5`

---

## System Przycisków

### Dostępne Klasy Przycisków

Wszystkie style przycisków są dostępne globalnie w pliku `_buttons.scss`.

#### Przyciski Główne (według proporcji palety)

| Klasa | Kolor | Użycie | Przykład | Hover |
|-------|-------|--------|----------|-------|
| `.btn-primary` | Orange (50%) | Główne akcje | Wyślij, Dalej | Przyciemnienie |
| `.btn-secondary` | Violet | Akcje drugorzędne | Zapisz | Wypełnienie kolorem |
| `.btn-tertiary` | Sun (15%) | Akcje pomocnicze | Generuj, API | Wypełnienie kolorem |
| `.btn-ghost` | Violet | Anulowanie | Anuluj, Zamknij | Wypełnienie kolorem |
| `.btn-neutral` | Czarny | Nawigacja | Wstecz | Szare tło |

#### Przyciski Dodatkowe

| Klasa | Opis |
|-------|------|
| `.btn-outline` | Neutralny przycisk z obramowaniem |
| `.btn-text` | Przycisk tekstowy bez obramowania |
| `.btn-danger` | Usuwanie i błędy (czerwony) |
| `.btn-success` | Sukces i zatwierdzenie (zielony) |

#### Modyfikatory Rozmiaru

```scss
.btn--sm     // Mały przycisk
.btn--lg     // Duży przycisk
.btn--xl     // Ekstra duży przycisk
```

#### Modyfikatory Szerokości

```scss
.btn--full   // Pełna szerokość (100%)
.btn--auto   // Automatyczna szerokość
```

#### Przyciski z Ikonami

```html
<button class="btn-primary">
  <span class="btn__icon">
    <svg><!-- ikona --></svg>
  </span>
  Zapisz
</button>

<!-- Tylko ikona -->
<button class="btn-primary btn--icon-only">
  <span class="btn__icon">
    <svg><!-- ikona --></svg>
  </span>
</button>
```

#### Grupowanie Przycisków

```html
<div class="btn-group">
  <button class="btn-ghost">Anuluj</button>
  <button class="btn-secondary">Zapisz</button>
  <button class="btn-primary">Wyślij</button>
</div>

<!-- Wyrównanie -->
.btn-group--end      // Do prawej
.btn-group--center   // Do środka
.btn-group--between  // Z odstępami
.btn-group--compact  // Zwarte
```

#### Stany

```scss
:disabled            // Automatycznie obsłużone
.btn--loading        // Stan ładowania z spinnerem
```

### Przykłady Użycia

Zobacz plik `BUTTONS_EXAMPLES.html` dla pełnych przykładów HTML.

---

## Klasy Pomocnicze

### Kolory Tekstu
```scss
.u-text-primary    // Pomarańczowy
.u-text-accent     // Raspberry
.u-text-tertiary   // Żółty
.u-text-secondary  // Maroon
.u-text-muted      // Szary
```

### Kolory Tła
```scss
.u-bg-primary      // Pomarańczowy
.u-bg-accent       // Raspberry
.u-bg-tertiary     // Żółty
.u-bg-secondary    // Maroon
```

### Kolory Obramowania
```scss
.u-border-primary   // Pomarańczowy
.u-border-accent    // Raspberry
.u-border-tertiary  // Żółty
.u-border-secondary // Maroon
```

---

## Mapowanie Komponentów

### Orange (50%)
- ✅ Przyciski Primary (wizard-footer__button--primary)
- ✅ Aktywny krok w stepperze (wizard-stepper__item.in-progress)
- ✅ Scrollbar
- ✅ Dropzone ikony i bordery
- ✅ Nagłówki kroków (wizard-step-header__title)
- ✅ Focus states na inputach
- ✅ Schema editor toolbar

### Raspberry (20%)
- ✅ Przyciski Secondary (wizard-footer__button--secondary)
- ✅ Przyciski instrukcji (instruction-button)

### Sun (15%)
- ✅ API Request button
- ✅ Test Generation button

### Maroon (15%)
- ✅ Przyciski Ghost/Anuluj (wizard-footer__button--ghost)

---

## Przykłady Użycia

```scss
// Przycisk główny - Orange (dominujący)
.button-primary {
  background: tokens.$color-primary;
  color: white;
  
  &:hover {
    background: tokens.$color-primary-hover;
  }
}

// Przycisk zapisu - Raspberry (akcent)
.button-save {
  border: 2px solid tokens.$color-accent;
  color: tokens.$color-accent;
  
  &:hover {
    background: tokens.$color-accent-light;
  }
}

// Przycisk pomocniczy - Sun (akcent ciepły)
.button-help {
  border: 2px solid tokens.$color-tertiary-hover;
  color: tokens.$color-tertiary-hover;
}

// Przycisk anulowania - Maroon (akcent ciemny)
.button-cancel {
  border: 2px solid tokens.$color-secondary;
  color: tokens.$color-secondary;
}
```

---

## Paleta Pełna

Oprócz głównych kolorów aplikacyjnych dostępne są również:
- **Violet** (fioletowy) - do użycia w razie potrzeby
- **Sky** (niebieski) - elementy informacyjne
- **Blush** (różowy) - dekoracje
- **Green** (zielony) - sukces, zaakceptowane
- **Red** (czerwony) - błędy

Szczegóły w pliku `_tokens.scss`.
