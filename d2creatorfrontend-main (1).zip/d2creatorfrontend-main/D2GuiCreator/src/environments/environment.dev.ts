export const environment = {
  production: false,
  name: 'dev',
  apiUrl: 'http://localhost:5000/api',
};
