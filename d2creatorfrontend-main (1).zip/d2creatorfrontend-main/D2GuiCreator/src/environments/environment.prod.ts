export const environment = {
  production: true,
  name: 'prd',
  apiUrl: '/api',
};
