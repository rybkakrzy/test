export const environment = {
  production: false,
  name: 'preprd',
  apiUrl: 'https://api-preprd.example.com/api',
};
