# Zmiany w Kolorystyce Aplikacji

## 📊 Nowy System Kolorów

Dostosowano paletę kolorów aplikacji zgodnie z proporcjami ze screenshota:

### Proporcje:
- 🟠 **Orange** - 50% (kolor dominujący)
- 💖 **Raspberry** - 20% (akcenty wyraziste)  
- ☀️ **Sun** - 15% (akcenty ciepłe)
- 🍷 **Maroon** - 15% (akcenty ciemne)

---

## 🎨 Zmodyfikowane Pliki

### 1. **Tokeny Kolorów** (`src/styles/_tokens.scss`)
Dodano nowe zmienne:
- `$color-primary` / `$color-primary-hover` / `$color-primary-light` (Orange)
- `$color-accent` / `$color-accent-hover` / `$color-accent-light` (Raspberry)
- `$color-tertiary` / `$color-tertiary-hover` / `$color-tertiary-light` (Sun)
- `$color-secondary` / `$color-secondary-hover` / `$color-secondary-light` (Maroon)

### 2. **Utilities** (`src/styles/_utilities.scss`)
Dodano klasy pomocnicze:
- `.u-text-primary`, `.u-bg-primary`, `.u-border-primary`
- `.u-text-accent`, `.u-bg-accent`, `.u-border-accent`
- `.u-text-tertiary`, `.u-bg-tertiary`, `.u-border-tertiary`
- `.u-text-secondary`, `.u-bg-secondary`, `.u-border-secondary`

### 3. **Komponenty Wizarda**

#### Wizard Footer (`wizard-footer.component.scss`)
- ✅ Przycisk Primary → Orange (Dalej/Wyślij)
- ✅ Przycisk Secondary → Raspberry (Zapisz)
- ✅ Przycisk Ghost → Maroon (Anuluj)

#### Wizard Stepper (`wizard-stepper.component.scss`)
- ✅ Aktywny krok → Orange

#### Wizard Step Header (`wizard-step-header.component.scss`)
- ✅ Tytuł i przycisk zamknięcia → Orange

### 4. **Kroki Wizarda**

#### Template and Schema Step (`template-and-schema-step.component.scss`)
- ✅ Dropzone → Orange (bordera, ikony, hover)
- ✅ Przycisk Instrukcja → Raspberry
- ✅ API Request Button → Sun (żółty)
- ✅ Schema Editor Toolbar → Orange
- ✅ Spinner → Orange

#### Document Description Step (`document-description-step.component.scss`)
- ✅ Focus state inputów → Orange

#### Summary Step (`summary-step.component.scss`)
- ✅ Test Generation Button → Sun (żółty)
- ✅ Textarea focus → Orange
- ✅ Ikona → Orange

### 5. **Inne Komponenty**

#### Validation Notes (`validation-notes.component.scss`)
- ✅ Paginacja hover → Orange

#### Scrollbar (`styles.scss`)
- ✅ Kolor scrollbara → Orange

---

## 📋 Mapowanie Kolorów

| Element | Kolor | Proporcja |
|---------|-------|-----------|
| Główne przyciski akcji | Orange | 50% |
| Aktywny krok stepper | Orange | |
| Nagłówki stron | Orange | |
| Dropzone | Orange | |
| Focus states | Orange | |
| Scrollbar | Orange | |
| Przyciski Zapisz | Raspberry | 20% |
| Przyciski Instrukcja | Raspberry | |
| API Request | Sun | 15% |
| Test Generation | Sun | |
| Przyciski Anuluj | Maroon | 15% |

---

## 🔘 Nowy System Przycisków

### Utworzone Pliki:
- **`src/styles/_buttons.scss`** - Kompletny system przycisków
- **`src/styles/BUTTONS_EXAMPLES.html`** - Przykłady użycia

### Dostępne Klasy:

#### Zgodnie z proporcjami palety:
```html
<!-- Orange 50% - Główne akcje -->
<button class="btn-primary">Wyślij</button>

<!-- Raspberry 20% - Akcje drugorzędne -->
<button class="btn-secondary">Zapisz szkic</button>
<button class="btn-secondary--filled">Eksportuj</button>

<!-- Sun 15% - Akcje pomocnicze -->
<button class="btn-tertiary">Generuj</button>
<button class="btn-tertiary--filled">API Request</button>

<!-- Maroon 15% - Anulowanie -->
<button class="btn-ghost">Anuluj</button>
```

#### Dodatkowe style:
```html
<button class="btn-outline">Neutralny</button>
<button class="btn-text">Link</button>
<button class="btn-danger">Usuń</button>
<button class="btn-success">Zatwierdź</button>
```

#### Modyfikatory:
```html
<!-- Rozmiary -->
<button class="btn-primary btn--sm">Mały</button>
<button class="btn-primary btn--lg">Duży</button>

<!-- Szerokość -->
<button class="btn-primary btn--full">Pełna szerokość</button>

<!-- Tylko ikona -->
<button class="btn-primary btn--icon-only">
  <span class="btn__icon"><svg>...</svg></span>
</button>

<!-- Ładowanie -->
<button class="btn-primary btn--loading">Przetwarzanie...</button>
```

#### Grupowanie:
```html
<div class="btn-group">
  <button class="btn-ghost">Anuluj</button>
  <button class="btn-secondary">Zapisz</button>
  <button class="btn-primary">Wyślij</button>
</div>

<div class="btn-group btn-group--end">...</div>
<div class="btn-group btn-group--between">...</div>
```

### Jak używać w nowych komponentach:

Zamiast tworzyć własne style przycisków, użyj gotowych klas:

**Przed:**
```html
<button style="background: #FF6200; color: white;">Dalej</button>
```

**Po:**
```html
<button class="btn-primary">Dalej</button>
```

**Wszystkie style są globalne** - nie musisz importować żadnych dodatkowych plików!

---

## ✅ Rezultat

Aplikacja teraz używa kolorów zgodnie z paletą i proporcjami przedstawionymi na screenshocie:
- Orange (#FF6200) jako kolor dominujący - 50%
- Raspberry (#D40199) jako główny akcent - 20%
- Sun (#FFE100) jako akcent ciepły - 15%
- Maroon (#4D0020) jako akcent ciemny - 15%

Wszystkie kolory są zdefiniowane w tokenach, co ułatwia przyszłe zmiany i zapewnia spójność w całej aplikacji.

---

## 📚 Dokumentacja

Szczegółowa dokumentacja palety kolorów znajduje się w pliku:
`src/styles/COLOR_PALETTE.md`
