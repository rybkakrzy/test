-- 007: Make tenant_id optional in projects table
-- Author: AI Assistant
-- Description: Allow projects to be created without a tenant (personal projects)
--              Projects can later be assigned to a team

-- Make tenant_id nullable
ALTER TABLE projects 
    ALTER COLUMN tenant_id DROP NOT NULL;

-- Drop the unique constraint that includes tenant_id
ALTER TABLE projects 
    DROP CONSTRAINT IF EXISTS uq_tenant_source;

-- Create new unique constraint on source only (globally unique)
ALTER TABLE projects 
    ADD CONSTRAINT uq_projects_source UNIQUE (source);

-- Update the foreign key to allow NULL
ALTER TABLE projects 
    DROP CONSTRAINT IF EXISTS fk_projects_tenant;

ALTER TABLE projects 
    ADD CONSTRAINT fk_projects_tenant 
        FOREIGN KEY (tenant_id) 
        REFERENCES tenants(id) 
        ON DELETE SET NULL;

-- Add index for faster queries filtering by tenant
CREATE INDEX IF NOT EXISTS idx_projects_tenant_nullable 
    ON projects(tenant_id) 
    WHERE tenant_id IS NOT NULL;

-- Add comment
COMMENT ON COLUMN projects.tenant_id IS 'Optional team/tenant assignment. NULL for personal projects.';
