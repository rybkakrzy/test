-- liquibase formatted sql

-- changeset kreator:007-add-workers-table

-- Workers table for field mapping configuration
CREATE TABLE workers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_version_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    worker_type VARCHAR(100) NOT NULL,
    config_json JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    
    CONSTRAINT fk_workers_project_version FOREIGN KEY (project_version_id) 
        REFERENCES project_versions(id) ON DELETE CASCADE
);

-- Index for faster queries by project_version_id
CREATE INDEX idx_workers_project_version ON workers(project_version_id);

-- Index for GIN queries on config_json
CREATE INDEX idx_workers_config_json ON workers USING gin(config_json);

-- Comments for documentation
COMMENT ON TABLE workers IS 'Mapping workers for template placeholders and content controls';
COMMENT ON COLUMN workers.name IS 'Name of the placeholder or control being mapped';
COMMENT ON COLUMN workers.worker_type IS 'Type of worker: "Podstaw wartość" for placeholders, "Stan" for text controls';
COMMENT ON COLUMN workers.config_json IS 'JSON configuration for the worker mapping';

-- rollback DROP TABLE workers;
