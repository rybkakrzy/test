# Liquibase Integration - Summary

## ✅ Co zostało utworzone

### 📁 Struktura plików

```
d2creatordb/
├── liquibase/
│   ├── changelog-master.xml              ✅ Główny plik changelog
│   ├── liquibase.properties              ✅ Konfiguracja lokalna
│   ├── liquibase.docker.properties       ✅ Konfiguracja Docker
│   ├── README.md                         ✅ Dokumentacja techniczna
│   └── changelog/
│       ├── 001_initial_schema.sql        ✅ Schemat początkowy (sformatowany dla Liquibase)
│       ├── 002_add_audit_log.sql         ✅ Przykład: Audit log
│       └── 003_add_settings.sql          ✅ Przykład: App settings
├── Dockerfile.liquibase                   ✅ Obraz Docker dla Liquibase
├── liquibase-manager.bat                  ✅ Skrypt zarządzania (Windows)
├── LIQUIBASE_GUIDE.md                     ✅ Przewodnik użycia
├── README.md                              ✅ Zaktualizowany główny README
└── .gitignore                             ✅ Ignorowanie plików Liquibase
```

### 🐳 Docker Integration

**docker-compose.yml** został zaktualizowany:

```yaml
# PostgreSQL - bez automatycznych skryptów SQL
d2-postgres:
  volumes:
    - postgres_data:/var/lib/postgresql/data
    # USUNIĘTO: ./d2creatordb/migrations:/docker-entrypoint-initdb.d

# DODANO: Liquibase service
liquibase:
  build:
    context: ./d2creatordb
    dockerfile: Dockerfile.liquibase
  depends_on:
    d2-postgres:
      condition: service_healthy

# API czeka na zakończenie Liquibase
d2-api:
  depends_on:
    d2-postgres:
      condition: service_healthy
    liquibase:
      condition: service_completed_successfully
```

## 🔄 Jak to działa

### Sekwencja uruchamiania

1. **PostgreSQL** startuje pierwszy
   - Health check: `pg_isready`
   - Status: `healthy`

2. **Liquibase** uruchamia się gdy PostgreSQL jest healthy
   - Łączy się z bazą
   - Sprawdza tabelę `databasechangelog`
   - Wykonuje nowe changesets
   - Kończy pracę (restart: no)
   - Status: `service_completed_successfully`

3. **Backend API** startuje po Liquibase
   - EF Core działa bez migracji
   - Używa gotowej bazy danych

4. **Frontend** startuje ostatni

### Tracking migracji

Liquibase tworzy dwie tabele systemowe:

**databasechangelog:**
```sql
SELECT id, author, filename, dateexecuted, orderexecuted 
FROM databasechangelog 
ORDER BY dateexecuted DESC;
```

**databasechangeloglock:**
```sql
SELECT * FROM databasechangeloglock;
```

## 📝 Format changesetów

### Liquibase SQL Format

```sql
--liquibase formatted sql

--changeset author:id-description
--comment: Detailed comment

CREATE TABLE example (...);

--rollback DROP TABLE IF EXISTS example;
```

### Elementy kluczowe:

- `--liquibase formatted sql` - WYMAGANE na początku pliku
- `--changeset` - Definicja changesetu
- `author:id` - Unikalny identyfikator
- `--comment` - Opis zmiany
- `--rollback` - Skrypt cofania zmiany

## 🚀 Workflow

### 1. Tworzenie nowej migracji

```bash
# Utwórz plik
echo "" > liquibase/changelog/004_add_feature.sql

# Edytuj plik (dodaj SQL z formatem Liquibase)
# ...

# Dodaj do changelog-master.xml
# <include file="db/changelog/004_add_feature.sql" .../>
```

### 2. Lokalne testowanie

```bash
cd c:\Projekty\Jit\Kreator\d2creatordb

# Walidacja
liquibase-manager.bat validate

# Status (co zostanie wykonane)
liquibase-manager.bat status

# Uruchom
liquibase-manager.bat update

# W razie problemu - rollback
liquibase-manager.bat rollback-count 1
```

### 3. Docker

```bash
# Przebuduj obraz Liquibase
docker-compose build liquibase

# Uruchom migracje
docker-compose up liquibase

# Sprawdź logi
docker-compose logs liquibase
```

### 4. Production

```bash
# Tag przed zmianami
liquibase tag version-1.0

# Update
liquibase update

# W razie problemów - rollback do tagu
liquibase rollback version-1.0
```

## 🔧 Komendy

### Skrypt liquibase-manager.bat

| Komenda | Opis |
|---------|------|
| `update` | Uruchom migracje (lokalne) |
| `update-docker` | Uruchom migracje (Docker) |
| `status` | Sprawdź status migracji |
| `validate` | Waliduj pliki changelog |
| `rollback-count N` | Cofnij N ostatnich changesetów |
| `clear-checksums` | Wyczyść cache checksumów |
| `release-locks` | Zwolnij blokady bazy |
| `db-doc` | Generuj dokumentację |

### Przykłady użycia

```bash
# Status
liquibase-manager.bat status

# Update
liquibase-manager.bat update

# Rollback ostatniej zmiany
liquibase-manager.bat rollback-count 1

# Dokumentacja
liquibase-manager.bat db-doc
```

## 📊 Przykładowe migracje

### 001_initial_schema.sql
- Tabele: users, projects, project_versions, files, parse_results, mappings, approvals
- Enums: project_status, approval_status
- Indexes, constraints, triggers
- Sample data (admin, testuser)

### 002_add_audit_log.sql (przykład)
- Tabela: audit_log
- Tracking zmian w systemie
- JSONB dla changes
- Indexes dla wydajności

### 003_add_settings.sql (przykład)
- Tabela: app_settings
- Konfiguracja aplikacji
- Wartości domyślne
- Encrypted settings support

## 🔍 Troubleshooting

### Problem: Lock na bazie

```bash
liquibase-manager.bat release-locks
```

### Problem: Checksum mismatch

```bash
liquibase-manager.bat clear-checksums
liquibase-manager.bat update
```

### Problem: Liquibase nie uruchamia się w Docker

```bash
# Sprawdź logi
docker-compose logs liquibase

# Rebuild
docker-compose build --no-cache liquibase
docker-compose up liquibase
```

### Problem: Connection refused

```bash
# Sprawdź czy PostgreSQL jest healthy
docker-compose ps d2-postgres

# Sprawdź health check
docker-compose exec d2-postgres pg_isready -U postgres
```

## 🎯 Best Practices

### ✅ DO:

1. **Zawsze dodawaj rollback:**
   ```sql
   --rollback DROP TABLE IF EXISTS table_name;
   ```

2. **Używaj transakcji:**
   - Liquibase domyślnie używa transakcji per changeset

3. **Testuj przed commitowaniem:**
   ```bash
   liquibase update
   # test...
   liquibase rollback-count 1
   ```

4. **Używaj preconditions:**
   ```sql
   --preconditions onFail:MARK_RAN
   --precondition-sql-check expectedResult:0 SELECT COUNT(*)...
   ```

5. **Wersjonuj nazwy plików:**
   ```
   001_initial_schema.sql
   002_add_feature.sql
   003_add_indexes.sql
   ```

### ❌ DON'T:

1. **Nie modyfikuj wykonanych changesetów** - to zmieni checksum!
2. **Nie usuwaj changesetów** z historii
3. **Nie commituj credentials** do repo
4. **Nie wykonuj migracji ręcznie** - używaj Liquibase

## 📚 Dokumentacja

- [LIQUIBASE_GUIDE.md](LIQUIBASE_GUIDE.md) - Kompletny przewodnik
- [liquibase/README.md](liquibase/README.md) - Dokumentacja techniczna
- [Liquibase Docs](https://docs.liquibase.com/)

## 🔐 Bezpieczeństwo

### Credentials

**NIE commituj:**
```properties
# ❌ BAD
password=secret123
```

**Używaj zmiennych środowiskowych:**
```bash
# ✅ GOOD
set LIQUIBASE_COMMAND_PASSWORD=secret
liquibase-manager.bat update
```

### Production

1. Używaj dedykowanego użytkownika DB
2. Loguj wszystkie zmiany
3. Backup przed migracją
4. Testuj na staging
5. Plan rollbacku

## ✨ Zalety Liquibase

1. ✅ **Wersjonowanie** - pełna historia zmian
2. ✅ **Rollback** - bezpieczne cofanie
3. ✅ **Tracking** - wie co zostało wykonane
4. ✅ **Walidacja** - sprawdza przed wykonaniem
5. ✅ **Różne środowiska** - dev, test, prod
6. ✅ **Team collaboration** - współpraca zespołowa
7. ✅ **CI/CD ready** - łatwa automatyzacja
8. ✅ **Database agnostic** - działa z wieloma bazami

## 🆚 Liquibase vs EF Core Migrations

| Feature | Liquibase | EF Core |
|---------|-----------|---------|
| Język | SQL/XML/JSON/YAML | C# |
| Rollback | ✅ Tak | ⚠️ Ograniczone |
| Cross-platform | ✅ Tak | ⚠️ .NET only |
| Database agnostic | ✅ Tak | ✅ Tak |
| Version control | ✅ Doskonałe | ✅ Dobre |
| Team collaboration | ✅ Łatwe | ⚠️ Może być trudne |
| Complex SQL | ✅ Pełne wsparcie | ⚠️ Ograniczone |
| Learning curve | ⚠️ Średni | ✅ Łatwy dla .NET devs |

## 📈 Co dalej?

1. **CI/CD Integration** - Automatyczne migracje w pipeline
2. **Monitoring** - Logi i alerty
3. **Backup automation** - Przed każdą migracją
4. **Staging environment** - Test przed production
5. **Documentation** - Automatyczna dokumentacja bazy

---

**Created:** 2025-11-23  
**Version:** 1.0  
**Status:** ✅ Production Ready
