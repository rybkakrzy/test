-- =====================================================
-- D2 CREATOR DATABASE - COMPLETE INITIALIZATION SCRIPT
-- =====================================================
-- This script creates a complete database schema with all migrations applied
-- Created: 2025-12-04
-- Author: D2 Creator Team
-- Description: Single file to initialize the entire D2 Creator database
-- =====================================================

-- =====================================================
-- EXTENSIONS
-- =====================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- TABLES
-- =====================================================

-- Tenants table
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    metadata JSONB,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE
);

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(200) NOT NULL UNIQUE,
    full_name VARCHAR(200),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT chk_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- Tenant members table
CREATE TABLE tenant_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL,
    corporate_key VARCHAR(255) NOT NULL,
    added_by UUID NOT NULL,
    added_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_tenant_members_tenant 
        FOREIGN KEY (tenant_id) 
        REFERENCES tenants(id) 
        ON DELETE CASCADE,
    
    CONSTRAINT uq_tenant_corporate_key 
        UNIQUE (tenant_id, corporate_key)
);

-- Projects table (tenant_id is now NULLABLE per migration 008)
CREATE TABLE projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID,
    source VARCHAR(200) NOT NULL,
    name VARCHAR(500) NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    retention_days INTEGER NOT NULL DEFAULT 90,
    default_template_name VARCHAR(500),
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    description TEXT,
    current_active_version_id UUID,
    
    CONSTRAINT chk_retention_days CHECK (retention_days BETWEEN 1 AND 3650),
    CONSTRAINT chk_source_length CHECK (LENGTH(source) >= 1),
    CONSTRAINT chk_name_length CHECK (LENGTH(name) >= 1),
    CONSTRAINT uq_projects_source UNIQUE (source),
    CONSTRAINT fk_projects_tenant FOREIGN KEY (tenant_id) 
        REFERENCES tenants(id) ON DELETE SET NULL,
    CONSTRAINT fk_projects_created_by FOREIGN KEY (created_by) 
        REFERENCES users(id) ON DELETE SET NULL
);

-- Project versions table
CREATE TABLE project_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL,
    major INTEGER NOT NULL DEFAULT 1,
    minor INTEGER NOT NULL DEFAULT 0,
    version_tag VARCHAR(50) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT false,
    status VARCHAR(50) NOT NULL DEFAULT 'Draft',
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    step_data JSONB,
    notes TEXT,
    
    CONSTRAINT chk_version_numbers CHECK (major >= 0 AND minor >= 0),
    CONSTRAINT uq_project_version UNIQUE (project_id, major, minor),
    CONSTRAINT fk_project_versions_project FOREIGN KEY (project_id) 
        REFERENCES projects(id) ON DELETE CASCADE,
    CONSTRAINT fk_project_versions_created_by FOREIGN KEY (created_by) 
        REFERENCES users(id) ON DELETE SET NULL
);

-- Files table
CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_version_id UUID NOT NULL,
    filename VARCHAR(500) NOT NULL,
    content BYTEA,
    storage_ref VARCHAR(1000),
    content_type VARCHAR(200),
    size BIGINT,
    sha256 VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_filename_length CHECK (LENGTH(filename) >= 1),
    CONSTRAINT chk_size_positive CHECK (size IS NULL OR size > 0),
    CONSTRAINT fk_files_project_version FOREIGN KEY (project_version_id) 
        REFERENCES project_versions(id) ON DELETE CASCADE
);

-- Parse results table (updated schema per migration 002)
CREATE TABLE parse_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_id UUID NOT NULL,
    parse_json JSONB,
    sample_request JSONB,
    validation_errors JSONB,
    parsed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_parse_results_file FOREIGN KEY (file_id) 
        REFERENCES files(id) ON DELETE CASCADE
);

-- Workers table (added in migration 007)
CREATE TABLE workers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_version_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    worker_type VARCHAR(100) NOT NULL,
    config_json JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT fk_workers_project_version FOREIGN KEY (project_version_id) 
        REFERENCES project_versions(id) ON DELETE CASCADE
);

-- Mappings table (updated per migration 002)
CREATE TABLE mappings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_version_id UUID NOT NULL,
    tag_name VARCHAR(200) NOT NULL,
    mapping_type VARCHAR(100) NOT NULL,
    mapping_json JSONB NOT NULL,
    sort_order INTEGER,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_tag_name_length CHECK (LENGTH(tag_name) >= 1),
    CONSTRAINT uq_project_version_tag UNIQUE (project_version_id, tag_name),
    CONSTRAINT fk_mappings_project_version FOREIGN KEY (project_version_id) 
        REFERENCES project_versions(id) ON DELETE CASCADE,
    CONSTRAINT fk_mappings_created_by FOREIGN KEY (created_by) 
        REFERENCES users(id) ON DELETE SET NULL
);

-- Approvals table (updated per migrations 002 and 003)
CREATE TABLE approvals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_version_id UUID NOT NULL,
    approver_id UUID NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Requested',
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT fk_approvals_project_version FOREIGN KEY (project_version_id) 
        REFERENCES project_versions(id) ON DELETE CASCADE,
    CONSTRAINT fk_approvals_approver FOREIGN KEY (approver_id) 
        REFERENCES users(id) ON DELETE RESTRICT
);

-- Audit log table
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    user_id UUID,
    changes JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_action CHECK (action IN ('CREATE', 'UPDATE', 'DELETE', 'VIEW')),
    CONSTRAINT fk_audit_log_user FOREIGN KEY (user_id) 
        REFERENCES users(id) ON DELETE SET NULL
);

-- Application settings table
CREATE TABLE app_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(200) NOT NULL UNIQUE,
    value TEXT,
    value_type VARCHAR(50) NOT NULL DEFAULT 'string',
    category VARCHAR(100),
    description TEXT,
    is_encrypted BOOLEAN NOT NULL DEFAULT false,
    is_system BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT chk_key_format CHECK (key ~ '^[a-zA-Z0-9._-]+$'),
    CONSTRAINT chk_value_type CHECK (value_type IN ('string', 'number', 'boolean', 'json'))
);

-- =====================================================
-- CIRCULAR REFERENCE CONSTRAINT
-- =====================================================

ALTER TABLE projects 
ADD CONSTRAINT fk_projects_current_active_version 
FOREIGN KEY (current_active_version_id) 
REFERENCES project_versions(id) ON DELETE SET NULL;

-- =====================================================
-- INDEXES
-- =====================================================

-- Tenants indexes
CREATE INDEX idx_tenants_name ON tenants(name);
CREATE INDEX idx_tenants_is_active ON tenants(is_active);

-- Tenant members indexes
CREATE INDEX idx_tenant_members_tenant_id ON tenant_members(tenant_id);
CREATE INDEX idx_tenant_members_corporate_key ON tenant_members(corporate_key);

-- Projects indexes
CREATE INDEX idx_projects_tenant_id ON projects(tenant_id) WHERE tenant_id IS NOT NULL;
CREATE INDEX idx_projects_source ON projects(source);
CREATE INDEX idx_projects_created_by ON projects(created_by);
CREATE INDEX idx_projects_created_at ON projects(created_at DESC);
CREATE INDEX idx_projects_metadata_gin ON projects USING gin(metadata);

-- Project versions indexes
CREATE INDEX idx_project_versions_project_id ON project_versions(project_id);
CREATE INDEX idx_project_versions_status ON project_versions(status);
CREATE INDEX idx_project_versions_is_active ON project_versions(is_active);
CREATE INDEX idx_project_versions_created_at ON project_versions(created_at DESC);
CREATE INDEX idx_project_versions_step_data ON project_versions USING gin(step_data);

-- Files indexes
CREATE INDEX idx_files_project_version_id ON files(project_version_id);
CREATE INDEX idx_files_filename ON files(filename);
CREATE INDEX idx_files_sha256 ON files(sha256);
CREATE INDEX idx_files_created_at ON files(created_at DESC);

-- Parse results indexes
CREATE INDEX idx_parse_results_file_id ON parse_results(file_id);

-- Workers indexes
CREATE INDEX idx_workers_project_version ON workers(project_version_id);
CREATE INDEX idx_workers_config_json ON workers USING gin(config_json);

-- Mappings indexes
CREATE INDEX idx_mappings_project_version_id ON mappings(project_version_id);
CREATE INDEX idx_mappings_tag_name ON mappings(tag_name);

-- Approvals indexes
CREATE INDEX idx_approvals_project_version_id ON approvals(project_version_id);
CREATE INDEX idx_approvals_approver_id ON approvals(approver_id);
CREATE INDEX idx_approvals_status ON approvals(status);
CREATE INDEX idx_approvals_created_at ON approvals(created_at DESC);

-- Users indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);

-- Audit log indexes
CREATE INDEX idx_audit_log_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_log_user_id ON audit_log(user_id);
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at DESC);
CREATE INDEX idx_audit_log_action ON audit_log(action);
CREATE INDEX idx_audit_log_changes ON audit_log USING gin(changes);

-- App settings indexes
CREATE INDEX idx_app_settings_key ON app_settings(key);
CREATE INDEX idx_app_settings_category ON app_settings(category);

-- =====================================================
-- FUNCTIONS
-- =====================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- TRIGGERS
-- =====================================================

CREATE TRIGGER trg_tenants_updated_at
BEFORE UPDATE ON tenants
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_projects_updated_at
BEFORE UPDATE ON projects
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_project_versions_updated_at
BEFORE UPDATE ON project_versions
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_workers_updated_at
BEFORE UPDATE ON workers
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_app_settings_updated_at
BEFORE UPDATE ON app_settings
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_approvals_updated_at
BEFORE UPDATE ON approvals
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- INITIAL DATA
-- =====================================================

-- Default tenants
INSERT INTO tenants (id, name, description, is_active)
VALUES 
    ('00000000-0000-0000-0000-000000000001', 'NL', 'Netherlands tenant', true),
    ('00000000-0000-0000-0000-000000000002', 'PL', 'Poland tenant', true),
    ('00000000-0000-0000-0000-000000000003', 'DE', 'Germany tenant', true)
ON CONFLICT (name) DO NOTHING;

-- Default users
INSERT INTO users (id, username, email, full_name, is_active)
VALUES 
    ('10000000-0000-0000-0000-000000000001', 'admin', 'admin@d2creator.com', 'System Administrator', true),
    ('10000000-0000-0000-0000-000000000002', 'testuser', 'test@d2creator.com', 'Test User', true)
ON CONFLICT (username) DO NOTHING;

-- Default settings
INSERT INTO app_settings (key, value, value_type, category, description, is_system)
VALUES 
    ('app.version', '1.0.0', 'string', 'system', 'Application version', true),
    ('app.maintenance_mode', 'false', 'boolean', 'system', 'Maintenance mode flag', false),
    ('document.default_retention_days', '90', 'number', 'document', 'Default retention period in days', false),
    ('document.max_file_size_mb', '50', 'number', 'document', 'Maximum file upload size in MB', false)
ON CONFLICT (key) DO NOTHING;

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON TABLE tenants IS 'Multi-tenant organization data';
COMMENT ON TABLE tenant_members IS 'Members of each tenant/team';
COMMENT ON TABLE projects IS 'Projects with metadata stored in JSONB';
COMMENT ON TABLE project_versions IS 'Versioned project data with step_data in JSONB';
COMMENT ON TABLE files IS 'Template files and attachments';
COMMENT ON TABLE workers IS 'Mapping workers for template placeholders and content controls';
COMMENT ON TABLE audit_log IS 'Audit log for tracking all entity changes';
COMMENT ON TABLE app_settings IS 'Application configuration settings';

COMMENT ON COLUMN projects.tenant_id IS 'Optional team/tenant assignment. NULL for personal projects.';
COMMENT ON COLUMN projects.metadata IS 'Flexible metadata: ApplicationName, ProcessName, ProcessOwner, BusinessLineId, ProcessVersion, ProcessStep, StatusId, RecipientId';
COMMENT ON COLUMN workers.name IS 'Name of the placeholder or control being mapped';
COMMENT ON COLUMN workers.worker_type IS 'Type of worker: "Podstaw wartość" for placeholders, "Stan" for text controls';
COMMENT ON COLUMN workers.config_json IS 'JSON configuration for the worker mapping';
COMMENT ON COLUMN audit_log.changes IS 'JSONB field containing before/after values';

-- =====================================================
-- END OF SCRIPT
-- =====================================================
