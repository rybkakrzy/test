# D2Creator Database - Liquibase Migration Guide

## 📋 Przegląd

Projekt wykorzystuje **Liquibase** do zarządzania migracjami bazy danych PostgreSQL. Liquibase zapewnia:

- ✅ Wersjonowanie zmian w bazie danych
- ✅ Rollback (cofanie zmian)
- ✅ Śledzenie historii migracji
- ✅ Walidację przed wdrożeniem
- ✅ Wsparcie dla wielu środowisk

## 🗂️ Struktura plików

```
d2creatordb/
├── liquibase/
│   ├── changelog-master.xml          # Główny plik changelog
│   ├── liquibase.properties          # Konfiguracja lokalna
│   ├── liquibase.docker.properties   # Konfiguracja Docker
│   ├── README.md                     # Szczegółowa dokumentacja
│   └── changelog/
│       ├── 001_initial_schema.sql    # Początkowy schemat
│       ├── 002_add_audit_log.sql     # Audit log (przykład)
│       └── 003_add_settings.sql      # Settings (przykład)
├── Dockerfile.liquibase              # Obraz Docker dla Liquibase
└── liquibase-manager.bat             # Skrypt zarządzania (Windows)
```

## 🚀 Szybki Start

### 1. Instalacja Liquibase

**Windows (Chocolatey):**
```bash
choco install liquibase
```

**macOS (Homebrew):**
```bash
brew install liquibase
```

### 2. Pobierz PostgreSQL JDBC Driver

```bash
# Pobierz driver
wget https://jdbc.postgresql.org/download/postgresql-42.7.1.jar

# Umieść w katalogu lib Liquibase
# Windows: C:\ProgramData\chocolatey\lib\liquibase\tools\lib\
# macOS/Linux: /opt/liquibase/lib/
```

### 3. Uruchom migracje

**Lokalnie:**
```bash
cd c:\Projekty\Jit\Kreator\d2creatordb
liquibase-manager.bat update
```

**Docker:**
```bash
cd c:\Projekty\Jit\Kreator
docker-compose up liquibase
```

## 📝 Tworzenie nowej migracji

### Krok 1: Utwórz plik SQL

Utwórz plik: `liquibase/changelog/004_add_your_feature.sql`

```sql
--liquibase formatted sql

--changeset your-name:004-add-feature
--comment: Opis twojej zmiany

CREATE TABLE your_table (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_your_table_name ON your_table(name);

--rollback DROP INDEX IF EXISTS idx_your_table_name;
--rollback DROP TABLE IF EXISTS your_table CASCADE;
```

### Krok 2: Dodaj do changelog-master.xml

Edytuj `liquibase/changelog-master.xml`:

```xml
<include file="db/changelog/001_initial_schema.sql" relativeToChangelogFile="false"/>
<include file="db/changelog/002_add_audit_log.sql" relativeToChangelogFile="false"/>
<include file="db/changelog/003_add_settings.sql" relativeToChangelogFile="false"/>
<include file="db/changelog/004_add_your_feature.sql" relativeToChangelogFile="false"/>
```

### Krok 3: Waliduj i uruchom

```bash
# Walidacja
liquibase-manager.bat validate

# Sprawdź status
liquibase-manager.bat status

# Uruchom migrację
liquibase-manager.bat update
```

## 🔧 Komendy zarządzania

### Użycie skryptu (zalecane)

```bash
# Uruchom migracje (lokalne)
liquibase-manager.bat update

# Uruchom migracje (Docker)
liquibase-manager.bat update-docker

# Sprawdź status
liquibase-manager.bat status

# Waliduj changelog
liquibase-manager.bat validate

# Cofnij ostatnią zmianę
liquibase-manager.bat rollback-count 1

# Cofnij do tagu
liquibase-manager.bat rollback v1.0

# Generuj dokumentację
liquibase-manager.bat db-doc

# Zwolnij blokady
liquibase-manager.bat release-locks
```

### Bezpośrednio Liquibase

```bash
cd c:\Projekty\Jit\Kreator\d2creatordb

# Update
liquibase --defaults-file=liquibase/liquibase.properties update

# Status
liquibase --defaults-file=liquibase/liquibase.properties status --verbose

# Rollback
liquibase --defaults-file=liquibase/liquibase.properties rollback-count 1
```

## 🐳 Integracja z Docker

### Automatyczne uruchomienie przy starcie

W `docker-compose.yml` Liquibase uruchamia się automatycznie:

```yaml
liquibase:
  build:
    context: ./d2creatordb
    dockerfile: Dockerfile.liquibase
  depends_on:
    d2-postgres:
      condition: service_healthy
```

### Ręczne uruchomienie

```bash
# Uruchom tylko migracje
docker-compose up liquibase

# Sprawdź status
docker-compose run --rm liquibase status --verbose

# Rollback
docker-compose run --rm liquibase rollback-count 1
```

### Sekwencja startowania

1. **PostgreSQL** - uruchamia się i czeka na healthy
2. **Liquibase** - uruchamia migracje, kończy się
3. **API** - startuje po zakończeniu Liquibase
4. **Frontend** - startuje ostatni

## 📊 Tracking migracji

Liquibase tworzy dwie tabele systemowe:

### databasechangelog

Przechowuje historię wykonanych changesetów:

```sql
SELECT * FROM databasechangelog ORDER BY dateexecuted DESC;
```

| Kolumna | Opis |
|---------|------|
| id | ID changesetu |
| author | Autor zmiany |
| filename | Plik źródłowy |
| dateexecuted | Data wykonania |
| orderexecuted | Kolejność wykonania |
| md5sum | Checksum (weryfikacja) |

### databasechangeloglock

Zapobiega równoczesnym migracjom:

```sql
SELECT * FROM databasechangeloglock;
```

## 🔄 Rollback

### Cofnij określoną liczbę changesetów

```bash
liquibase-manager.bat rollback-count 2
```

### Cofnij do określonej daty

```bash
liquibase --defaults-file=liquibase/liquibase.properties rollback-to-date 2025-11-20
```

### Cofnij do tagu

Najpierw dodaj tag:
```bash
liquibase --defaults-file=liquibase/liquibase.properties tag version-1.0
```

Potem rollback:
```bash
liquibase-manager.bat rollback version-1.0
```

## 🎯 Best Practices

### 1. Konwencja nazewnictwa

```
[numer]_[opis].sql
001_initial_schema.sql
002_add_audit_log.sql
003_add_settings.sql
```

### 2. Format changesetów

```sql
--changeset [autor]:[id]-[opis]
--comment: Szczegółowy opis

-- SQL statements here

--rollback -- Kod rollbacku
```

### 3. Zawsze dodawaj rollback

```sql
--changeset author:id
CREATE TABLE example (...);

--rollback DROP TABLE IF EXISTS example CASCADE;
```

### 4. Używaj preconditions

```sql
--preconditions onFail:MARK_RAN
--precondition-sql-check expectedResult:0 SELECT COUNT(*) FROM information_schema.tables WHERE table_name='users'
```

### 5. Testuj przed wdrożeniem

```bash
# 1. Waliduj
liquibase-manager.bat validate

# 2. Sprawdź status
liquibase-manager.bat status

# 3. Uruchom na dev
liquibase-manager.bat update

# 4. Przetestuj
# ... testy ...

# 5. W razie problemów - rollback
liquibase-manager.bat rollback-count 1
```

## 🔍 Troubleshooting

### Problem: Lock na bazie

```bash
liquibase-manager.bat release-locks
```

### Problem: Checksum mismatch

```bash
liquibase-manager.bat clear-checksums
liquibase-manager.bat update
```

### Problem: Liquibase nie działa w Docker

```bash
# Sprawdź logi
docker-compose logs liquibase

# Uruchom ponownie
docker-compose up --build liquibase
```

### Problem: Connection refused

Sprawdź czy PostgreSQL działa:
```bash
docker-compose ps d2-postgres
```

## 📚 Dodatkowe zasoby

- [Oficjalna dokumentacja Liquibase](https://docs.liquibase.com/)
- [SQL Format Guide](https://docs.liquibase.com/concepts/changelogs/sql-format.html)
- [PostgreSQL Tutorial](https://docs.liquibase.com/start/tutorials/postgresql.html)
- [Best Practices](https://docs.liquibase.com/concepts/bestpractices.html)

## 🔐 Bezpieczeństwo

**Ważne:** Nie commituj haseł do repozytorium!

Używaj zmiennych środowiskowych:

```bash
set LIQUIBASE_COMMAND_PASSWORD=twoje_haslo
liquibase-manager.bat update
```

Lub pliku `.env` (dodaj do `.gitignore`):

```env
DB_PASSWORD=secret_password
```

---

**Ostatnia aktualizacja:** 2025-11-23  
**Wersja:** 1.0
