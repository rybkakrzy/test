using D2ApiCreator.Domain.Common.BaseTypes;

namespace D2ApiCreator.Domain.Entities;

/// <summary>
/// Represents a member of a tenant/team
/// </summary>
public class TenantMember : Entity<Guid>
{
    protected TenantMember() { }

    public TenantMember(Guid id, Guid tenantId, string corporateKey, Guid addedBy)
        : base(id)
    {
        TenantId = tenantId;
        CorporateKey = corporateKey;
        AddedBy = addedBy;
        AddedAt = DateTime.UtcNow;
    }

    /// <summary>
    /// Reference to the tenant/team
    /// </summary>
    public Guid TenantId { get; set; }

    /// <summary>
    /// Corporate Key - user identifier in the system
    /// </summary>
    public string CorporateKey { get; set; } = string.Empty;

    /// <summary>
    /// User ID who added this member
    /// </summary>
    public Guid AddedBy { get; set; }

    /// <summary>
    /// When the member was added
    /// </summary>
    public DateTime AddedAt { get; set; }

    /// <summary>
    /// Navigation property to tenant
    /// </summary>
    public Tenant Tenant { get; set; } = null!;
}
