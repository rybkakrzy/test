
namespace D2ApiCreator.Domain.Enums;

public enum ProjectStatus
{
    Draft,
    PendingApproval,
    Approved,
    Deploying,
    Active,
    Inactive
}

