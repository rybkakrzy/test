namespace D2ApiCreator.Domain.Enums;

public enum ApprovalStatus
{
    Requested,
    Approved,
    Rejected
}

