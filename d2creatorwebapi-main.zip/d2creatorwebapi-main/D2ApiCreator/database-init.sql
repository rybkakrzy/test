-- ============================================================
-- D2ApiCreator - Database Initialization Script
-- PostgreSQL 16
-- Autor: D2ApiCreator Team
-- Data: 2025-11-24
-- ============================================================

\echo '╔═══════════════════════════════════════════════════════════╗'
\echo '║   Inicjalizacja bazy danych D2CreatorDb                  ║'
\echo '╚═══════════════════════════════════════════════════════════╝'
\echo ''

-- ============================================================
-- SKRYPT 1: Tabela Tenants
-- ============================================================
\echo '📋 [1/4] Tworzenie tabeli Tenants...'

CREATE TABLE IF NOT EXISTS "Tenants" (
    "Id" UUID PRIMARY KEY,
    "Name" VARCHAR(200) NOT NULL,
    "Code" VARCHAR(50) NOT NULL UNIQUE,
    "IsActive" BOOLEAN NOT NULL DEFAULT true,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "UpdatedAt" TIMESTAMP,
    CONSTRAINT "CK_Tenants_Name_NotEmpty" CHECK (LENGTH(TRIM("Name")) > 0),
    CONSTRAINT "CK_Tenants_Code_NotEmpty" CHECK (LENGTH(TRIM("Code")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Tenants_Code" ON "Tenants" ("Code");
CREATE INDEX IF NOT EXISTS "IX_Tenants_IsActive" ON "Tenants" ("IsActive");

-- Dodaj przykładowego tenanta
INSERT INTO "Tenants" ("Id", "Name", "Code", "IsActive", "CreatedAt")
VALUES (gen_random_uuid(), 'Default Tenant', 'DEFAULT', true, NOW())
ON CONFLICT ("Code") DO NOTHING;

\echo '✓ Tabela Tenants utworzona'
\echo ''

-- ============================================================
-- SKRYPT 2: Tabela Projects
-- ============================================================
\echo '📋 [2/4] Tworzenie tabeli Projects...'

CREATE TABLE IF NOT EXISTS "Projects" (
    "Id" UUID PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "Name" VARCHAR(200) NOT NULL,
    "Description" TEXT,
    "SourceSystem" VARCHAR(100),
    "IsActive" BOOLEAN NOT NULL DEFAULT true,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "CreatedBy" UUID,
    "UpdatedAt" TIMESTAMP,
    "UpdatedBy" UUID,
    CONSTRAINT "FK_Projects_Tenants" FOREIGN KEY ("TenantId") 
        REFERENCES "Tenants" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Projects_Name_NotEmpty" CHECK (LENGTH(TRIM("Name")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Projects_TenantId" ON "Projects" ("TenantId");
CREATE INDEX IF NOT EXISTS "IX_Projects_SourceSystem" ON "Projects" ("SourceSystem");
CREATE INDEX IF NOT EXISTS "IX_Projects_IsActive" ON "Projects" ("IsActive");

\echo '✓ Tabela Projects utworzona'
\echo ''

-- ============================================================
-- SKRYPT 3: Tabela ProjectVersions
-- ============================================================
\echo '📋 [3/4] Tworzenie tabeli ProjectVersions...'

CREATE TABLE IF NOT EXISTS "ProjectVersions" (
    "Id" UUID PRIMARY KEY,
    "ProjectId" UUID NOT NULL,
    "Major" INTEGER NOT NULL DEFAULT 1,
    "Minor" INTEGER NOT NULL DEFAULT 0,
    "VersionTag" VARCHAR(50) NOT NULL,
    "IsActive" BOOLEAN NOT NULL DEFAULT false,
    "Status" VARCHAR(50) NOT NULL DEFAULT 'Draft',
    "StepData" JSONB NOT NULL DEFAULT '{}',
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "CreatedBy" UUID,
    "UpdatedAt" TIMESTAMP,
    "UpdatedBy" UUID,
    CONSTRAINT "FK_ProjectVersions_Projects" FOREIGN KEY ("ProjectId") 
        REFERENCES "Projects" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_ProjectVersions_Major_Positive" CHECK ("Major" > 0),
    CONSTRAINT "CK_ProjectVersions_Minor_NonNegative" CHECK ("Minor" >= 0),
    CONSTRAINT "UQ_ProjectVersions_ProjectId_VersionTag" 
        UNIQUE ("ProjectId", "VersionTag")
);

CREATE INDEX IF NOT EXISTS "IX_ProjectVersions_ProjectId" ON "ProjectVersions" ("ProjectId");
CREATE INDEX IF NOT EXISTS "IX_ProjectVersions_IsActive" ON "ProjectVersions" ("IsActive");
CREATE INDEX IF NOT EXISTS "IX_ProjectVersions_Status" ON "ProjectVersions" ("Status");

-- Trigger: tylko jedna aktywna wersja na projekt
CREATE OR REPLACE FUNCTION ensure_single_active_version()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW."IsActive" = true THEN
        UPDATE "ProjectVersions"
        SET "IsActive" = false
        WHERE "ProjectId" = NEW."ProjectId"
          AND "Id" != NEW."Id"
          AND "IsActive" = true;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_single_active_version ON "ProjectVersions";
CREATE TRIGGER trigger_single_active_version
    BEFORE INSERT OR UPDATE ON "ProjectVersions"
    FOR EACH ROW
    EXECUTE FUNCTION ensure_single_active_version();

\echo '✓ Tabela ProjectVersions utworzona z triggerem'
\echo ''

-- ============================================================
-- SKRYPT 4: Pozostałe tabele
-- ============================================================
\echo '📋 [4/4] Tworzenie pozostałych tabel...'

-- Tabela Users
CREATE TABLE IF NOT EXISTS "Users" (
    "Id" UUID PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "Email" VARCHAR(255) NOT NULL UNIQUE,
    "FirstName" VARCHAR(100),
    "LastName" VARCHAR(100),
    "IsActive" BOOLEAN NOT NULL DEFAULT true,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Users_Tenants" FOREIGN KEY ("TenantId") 
        REFERENCES "Tenants" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Users_Email_NotEmpty" CHECK (LENGTH(TRIM("Email")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Users_TenantId" ON "Users" ("TenantId");
CREATE INDEX IF NOT EXISTS "IX_Users_Email" ON "Users" ("Email");

\echo '  ✓ Tabela Users utworzona'

-- Tabela Files
CREATE TABLE IF NOT EXISTS "Files" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "FileName" VARCHAR(255) NOT NULL,
    "FileType" VARCHAR(50) NOT NULL,
    "FilePath" VARCHAR(500) NOT NULL,
    "FileSize" BIGINT NOT NULL,
    "UploadedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "UploadedBy" UUID,
    CONSTRAINT "FK_Files_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Files_FileSize_Positive" CHECK ("FileSize" > 0),
    CONSTRAINT "CK_Files_FileName_NotEmpty" CHECK (LENGTH(TRIM("FileName")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Files_ProjectVersionId" ON "Files" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Files_FileType" ON "Files" ("FileType");

\echo '  ✓ Tabela Files utworzona'

-- Tabela Mappings
CREATE TABLE IF NOT EXISTS "Mappings" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "Placeholder" VARCHAR(200) NOT NULL,
    "MappingType" VARCHAR(50) NOT NULL,
    "SourceField" VARCHAR(200),
    "DefaultValue" TEXT,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Mappings_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Mappings_Placeholder_NotEmpty" CHECK (LENGTH(TRIM("Placeholder")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Mappings_ProjectVersionId" ON "Mappings" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Mappings_MappingType" ON "Mappings" ("MappingType");

\echo '  ✓ Tabela Mappings utworzona'

-- Tabela Approvals
CREATE TABLE IF NOT EXISTS "Approvals" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "ApprovedBy" UUID NOT NULL,
    "ApprovalStatus" VARCHAR(50) NOT NULL,
    "Comment" TEXT,
    "ApprovedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Approvals_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "FK_Approvals_Users" FOREIGN KEY ("ApprovedBy") 
        REFERENCES "Users" ("Id")
);

CREATE INDEX IF NOT EXISTS "IX_Approvals_ProjectVersionId" ON "Approvals" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Approvals_ApprovalStatus" ON "Approvals" ("ApprovalStatus");

\echo '  ✓ Tabela Approvals utworzona'

-- Tabela AuditLogs
CREATE TABLE IF NOT EXISTS "AuditLogs" (
    "Id" UUID PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "EntityName" VARCHAR(100) NOT NULL,
    "EntityId" UUID NOT NULL,
    "Action" VARCHAR(50) NOT NULL,
    "Changes" JSONB,
    "PerformedBy" UUID,
    "PerformedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_AuditLogs_Tenants" FOREIGN KEY ("TenantId") 
        REFERENCES "Tenants" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_AuditLogs_EntityName_NotEmpty" CHECK (LENGTH(TRIM("EntityName")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_AuditLogs_TenantId" ON "AuditLogs" ("TenantId");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_EntityName" ON "AuditLogs" ("EntityName");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_EntityId" ON "AuditLogs" ("EntityId");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_PerformedAt" ON "AuditLogs" ("PerformedAt");

\echo '  ✓ Tabela AuditLogs utworzona'

-- Tabela ParseResults (dla przechowywania wyników parsowania dokumentów)
CREATE TABLE IF NOT EXISTS "ParseResults" (
    "Id" UUID PRIMARY KEY,
    "FileId" UUID NOT NULL,
    "PlaceholdersFound" INTEGER NOT NULL DEFAULT 0,
    "PlaceholdersJson" JSONB NOT NULL DEFAULT '[]',
    "ParsedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "Status" VARCHAR(50) NOT NULL,
    "ErrorMessage" TEXT,
    CONSTRAINT "FK_ParseResults_Files" FOREIGN KEY ("FileId") 
        REFERENCES "Files" ("Id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "IX_ParseResults_FileId" ON "ParseResults" ("FileId");
CREATE INDEX IF NOT EXISTS "IX_ParseResults_Status" ON "ParseResults" ("Status");

\echo '  ✓ Tabela ParseResults utworzona'
\echo ''

-- ============================================================
-- Dodanie przykładowych danych
-- ============================================================
\echo '📋 Dodawanie przykładowych danych...'

-- Dodaj przykładowego użytkownika
INSERT INTO "Users" ("Id", "TenantId", "Email", "FirstName", "LastName", "IsActive", "CreatedAt")
SELECT gen_random_uuid(), t."Id", 'admin@default.com', 'Admin', 'User', true, NOW()
FROM "Tenants" t WHERE t."Code" = 'DEFAULT'
ON CONFLICT ("Email") DO NOTHING;

\echo '✓ Dodano przykładowego użytkownika (admin@default.com)'
\echo ''

-- ============================================================
-- Weryfikacja
-- ============================================================
\echo '📋 Weryfikacja tabel...'
\echo ''

SELECT 
    'Utworzono ' || COUNT(*) || ' tabel' as "Status",
    STRING_AGG(table_name, ', ') as "Tabele"
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_type = 'BASE TABLE';

\echo ''
\echo '╔═══════════════════════════════════════════════════════════╗'
\echo '║   Inicjalizacja zakończona pomyślnie!                    ║'
\echo '╚═══════════════════════════════════════════════════════════╝'
\echo ''
\echo '✅ Wszystkie tabele zostały utworzone'
\echo '✅ Przykładowy tenant: DEFAULT'
\echo '✅ Przykładowy użytkownik: admin@default.com'
\echo ''
\echo '📌 Dane logowania do bazy:'
\echo '   Host:     localhost'
\echo '   Port:     5432'
\echo '   Database: D2CreatorDb'
\echo '   User:     postgres'
\echo '   Password: postgres'
\echo ''

