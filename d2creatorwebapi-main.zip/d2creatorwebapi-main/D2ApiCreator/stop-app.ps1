# D2ApiCreator Stop Script
# Autor: GitHub Copilot
# Data: 2025-11-20

Write-Host "`n╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Red
Write-Host "║         D2ApiCreator - Stop Application Script                ║" -ForegroundColor Red
Write-Host "╚════════════════════════════════════════════════════════════════╝`n" -ForegroundColor Red

# Sprawdź procesy dotnet
Write-Host "🔍 Szukanie uruchomionych procesów dotnet..." -ForegroundColor Yellow
$dotnetProcesses = Get-Process -Name "dotnet" -ErrorAction SilentlyContinue

if ($dotnetProcesses) {
    Write-Host "Znaleziono $($dotnetProcesses.Count) proces(ów) dotnet:" -ForegroundColor Cyan
    $dotnetProcesses | ForEach-Object {
        Write-Host "   • PID: $($_.Id) | Start: $($_.StartTime)" -ForegroundColor White
    }
    
    Write-Host "`n🛑 Zatrzymywanie wszystkich procesów dotnet..." -ForegroundColor Yellow
    $result = taskkill /F /IM dotnet.exe 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Wszystkie procesy dotnet zostały zatrzymane!" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Wystąpił problem podczas zatrzymywania procesów" -ForegroundColor Yellow
        Write-Host "$result" -ForegroundColor Gray
    }
} else {
    Write-Host "ℹ️  Nie znaleziono uruchomionych procesów dotnet" -ForegroundColor Cyan
}

# Sprawdź port 5000
Write-Host "`n🔍 Sprawdzanie portu 5000..." -ForegroundColor Yellow
$portCheck = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue

if ($portCheck) {
    Write-Host "⚠️  Port 5000 jest nadal zajęty przez proces PID: $($portCheck.OwningProcess)" -ForegroundColor Yellow
    Write-Host "Próba wymuszenia zakończenia procesu..." -ForegroundColor Yellow
    Stop-Process -Id $portCheck.OwningProcess -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    
    # Ponowne sprawdzenie
    $portCheck2 = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    if (-not $portCheck2) {
        Write-Host "✅ Port 5000 został zwolniony!" -ForegroundColor Green
    } else {
        Write-Host "❌ Nie udało się zwolnić portu 5000" -ForegroundColor Red
    }
} else {
    Write-Host "✅ Port 5000 jest wolny" -ForegroundColor Green
}

# Sprawdź port 5001 (HTTPS)
Write-Host "`n🔍 Sprawdzanie portu 5001..." -ForegroundColor Yellow
$portCheck5001 = Get-NetTCPConnection -LocalPort 5001 -ErrorAction SilentlyContinue

if ($portCheck5001) {
    Write-Host "⚠️  Port 5001 jest zajęty przez proces PID: $($portCheck5001.OwningProcess)" -ForegroundColor Yellow
    Stop-Process -Id $portCheck5001.OwningProcess -Force -ErrorAction SilentlyContinue
    Write-Host "✅ Port 5001 został zwolniony!" -ForegroundColor Green
} else {
    Write-Host "✅ Port 5001 jest wolny" -ForegroundColor Green
}

Write-Host "`n╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║                  ✅ Aplikacja zatrzymana!                       ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`n💡 Aby uruchomić aplikację ponownie:" -ForegroundColor Cyan
Write-Host "   • Użyj skryptu: .\restart-app.ps1" -ForegroundColor White
Write-Host "   • Lub wykonaj: dotnet run (w katalogu D2ApiCreator.Api)`n" -ForegroundColor White

