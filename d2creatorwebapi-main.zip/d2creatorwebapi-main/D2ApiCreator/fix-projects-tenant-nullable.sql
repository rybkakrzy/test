-- ============================================================================
-- Migracja: tenant_id w projects jako NULLABLE
-- Data: 2025-11-24
-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '🔧 Zmiana kolumny tenant_id w tabeli projects na NULLABLE...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo ''

-- Sprawdź czy tabela projects istnieje
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'projects') THEN
        RAISE EXCEPTION 'Tabela projects nie istnieje!';
    END IF;
END $$;

\echo '✓ Tabela projects istnieje'
\echo ''

-- Usuń NOT NULL constraint z kolumny tenant_id
DO $$ 
BEGIN
    -- Zmień foreign key na ON DELETE SET NULL
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'fk_projects_tenants' 
        AND table_name = 'projects'
    ) THEN
        ALTER TABLE projects DROP CONSTRAINT fk_projects_tenants;
        RAISE NOTICE '✓ Usunięto stary constraint fk_projects_tenants';
    END IF;
    
    -- Usuń NOT NULL z tenant_id
    ALTER TABLE projects ALTER COLUMN tenant_id DROP NOT NULL;
    RAISE NOTICE '✓ Kolumna tenant_id jest teraz NULLABLE';
    
    -- Dodaj nowy foreign key z ON DELETE SET NULL
    ALTER TABLE projects 
    ADD CONSTRAINT fk_projects_tenants 
    FOREIGN KEY (tenant_id) 
    REFERENCES tenants(id) 
    ON DELETE SET NULL;
    
    RAISE NOTICE '✓ Dodano nowy constraint z ON DELETE SET NULL';
END $$;

\echo ''
\echo '✓ Kolumna tenant_id zmieniona na NULLABLE'
\echo '✓ Foreign key zmieniony na ON DELETE SET NULL'
\echo ''

-- Weryfikacja
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo 'Weryfikacja kolumny tenant_id:'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo ''

SELECT 
    column_name as "Kolumna",
    data_type as "Typ",
    is_nullable as "Nullable"
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'projects' 
AND column_name = 'tenant_id';

\echo ''
\echo '╔══════════════════════════════════════════════════════════════════════╗'
\echo '║                    MIGRACJA ZAKOŃCZONA POMYŚLNIE!                   ║'
\echo '╚══════════════════════════════════════════════════════════════════════╝'
\echo ''
\echo '✅ Kolumna tenant_id jest teraz NULLABLE'
\echo '✅ Projekty mogą być tworzone bez przypisania do tenanta'
\echo ''
\echo '🚀 Możesz teraz uruchomić aplikację:'
\echo '   .\restart-app.ps1'
\echo ''

