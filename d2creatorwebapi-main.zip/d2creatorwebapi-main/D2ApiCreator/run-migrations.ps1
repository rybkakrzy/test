# Wykonanie wszystkich wymaganych migracji bazy danych
# Autor: D2ApiCreator Team
# Data: 2025-11-24

$ErrorActionPreference = "Stop"

Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   Wykonywanie migracji bazy danych D2CreatorDb           ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Sprawdź czy Podman/Docker działa
try {
    $containerStatus = podman ps --filter "name=d2creator-postgres" --format "{{.Status}}" 2>$null
    if (-not $containerStatus) {
        Write-Host "❌ Kontener PostgreSQL nie jest uruchomiony!" -ForegroundColor Red
        Write-Host "   Uruchom: podman start d2creator-postgres" -ForegroundColor Yellow
        Write-Host "   lub:     .\setup-database.ps1" -ForegroundColor Yellow
        exit 1
    }
    Write-Host "✓ Kontener PostgreSQL działa" -ForegroundColor Green
} catch {
    Write-Host "❌ Nie można połączyć się z Podman/Docker" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Migracja 1: Dodanie created_by do tenants
Write-Host "[1/2] Dodawanie kolumny created_by do tabeli tenants..." -ForegroundColor Yellow
try {
    $sql1 = @"
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS created_by UUID;
CREATE INDEX IF NOT EXISTS idx_tenants_created_by ON tenants(created_by);
"@
    
    $result = $sql1 | podman exec -i d2creator-postgres psql -U postgres -d D2CreatorDb 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Kolumna created_by dodana do tenants" -ForegroundColor Green
    } else {
        Write-Host "⚠ Migracja 1 zakończona z ostrzeżeniami: $result" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Błąd podczas migracji 1: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Migracja 2: Zmiana tenant_id w projects na nullable
Write-Host "[2/2] Zmiana tenant_id w projects na NULLABLE..." -ForegroundColor Yellow
try {
    $sql2 = @"
ALTER TABLE projects ALTER COLUMN tenant_id DROP NOT NULL;
ALTER TABLE projects DROP CONSTRAINT IF EXISTS fk_projects_tenants;
ALTER TABLE projects 
ADD CONSTRAINT fk_projects_tenants 
FOREIGN KEY (tenant_id) 
REFERENCES tenants(id) 
ON DELETE SET NULL;
"@
    
    $result = $sql2 | podman exec -i d2creator-postgres psql -U postgres -d D2CreatorDb 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ tenant_id w projects jest teraz NULLABLE" -ForegroundColor Green
    } else {
        Write-Host "⚠ Migracja 2 zakończona z ostrzeżeniami: $result" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Błąd podczas migracji 2: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Weryfikacja
Write-Host "Weryfikacja migracji..." -ForegroundColor Yellow
Write-Host ""

$verificationSql = @"
SELECT 'tenants.created_by' as kolumna, is_nullable
FROM information_schema.columns 
WHERE table_name = 'tenants' AND column_name = 'created_by'
UNION ALL
SELECT 'projects.tenant_id' as kolumna, is_nullable
FROM information_schema.columns 
WHERE table_name = 'projects' AND column_name = 'tenant_id';
"@

try {
    $verificationResult = $verificationSql | podman exec -i d2creator-postgres psql -U postgres -d D2CreatorDb -t 2>&1
    Write-Host "Wynik weryfikacji:" -ForegroundColor Cyan
    Write-Host $verificationResult -ForegroundColor White
} catch {
    Write-Host "⚠ Nie można zweryfikować migracji" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║              MIGRACJE ZAKOŃCZONE POMYŚLNIE!              ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "✅ Migracja 1: created_by dodany do tenants" -ForegroundColor Green
Write-Host "✅ Migracja 2: tenant_id w projects jest NULLABLE" -ForegroundColor Green
Write-Host ""
Write-Host "🚀 Możesz teraz uruchomić aplikację:" -ForegroundColor Cyan
Write-Host "   .\restart-app.ps1" -ForegroundColor White
Write-Host ""
Write-Host "📝 Test: Utwórz projekt bez podawania tenantId" -ForegroundColor Cyan
Write-Host "   POST /api/v1/projects" -ForegroundColor White
Write-Host "   { \"name\": \"Test\", \"applicationName\": \"App\" }" -ForegroundColor White
Write-Host ""

