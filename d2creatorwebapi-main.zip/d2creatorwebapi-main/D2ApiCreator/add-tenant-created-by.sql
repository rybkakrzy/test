-- ============================================================================
-- Migracja: Dodanie kolumny created_by do tabeli tenants
-- Data: 2025-11-24
-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '🔧 Dodawanie brakującej kolumny created_by do tabeli tenants...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo ''

-- Sprawdź czy tabela istnieje
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'tenants') THEN
        RAISE EXCEPTION 'Tabela tenants nie istnieje! Uruchom najpierw complete-database-setup.sql';
    END IF;
END $$;

\echo '✓ Tabela tenants istnieje'
\echo ''

-- Dodaj kolumnę created_by jeśli nie istnieje
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'tenants' 
        AND column_name = 'created_by'
    ) THEN
        ALTER TABLE tenants ADD COLUMN created_by UUID;
        RAISE NOTICE '✓ Dodano kolumnę created_by';
    ELSE
        RAISE NOTICE '⚠ Kolumna created_by już istnieje';
    END IF;
END $$;

-- Dodaj indeks dla created_by (opcjonalnie, dla wydajności)
CREATE INDEX IF NOT EXISTS idx_tenants_created_by ON tenants(created_by);

\echo ''
\echo '✓ Kolumna created_by dodana'
\echo '✓ Indeks idx_tenants_created_by utworzony'
\echo ''

-- Weryfikacja
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo 'Weryfikacja struktury tabeli tenants:'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo ''

SELECT 
    column_name as "Kolumna",
    data_type as "Typ",
    is_nullable as "Nullable"
FROM information_schema.columns 
WHERE table_schema = 'public' 
AND table_name = 'tenants' 
ORDER BY ordinal_position;

\echo ''
\echo '╔══════════════════════════════════════════════════════════════════════╗'
\echo '║                    MIGRACJA ZAKOŃCZONA POMYŚLNIE!                   ║'
\echo '╚══════════════════════════════════════════════════════════════════════╝'
\echo ''
\echo '✅ Kolumna created_by została dodana do tabeli tenants'
\echo ''
\echo '🚀 Możesz teraz uruchomić aplikację:'
\echo '   .\restart-app.ps1'
\echo ''

