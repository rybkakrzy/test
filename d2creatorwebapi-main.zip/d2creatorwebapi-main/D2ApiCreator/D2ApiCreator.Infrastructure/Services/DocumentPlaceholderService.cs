﻿﻿using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Office2010.Word;
using D2ApiCreator.Application.Common.Interfaces;
using Microsoft.Extensions.Logging;
namespace D2ApiCreator.Infrastructure.Services;
/// <summary>
/// Service for extracting placeholders from DOCX documents
/// </summary>
public class DocumentPlaceholderService : IDocumentPlaceholderService
{
    private readonly ILogger<DocumentPlaceholderService> _logger;
    
    // Placeholder pattern: <%identifier%> where identifier contains only alphanumeric and underscore
    private static readonly Regex PlaceholderRegex = new(@"<%([a-zA-Z0-9_]+)%>", RegexOptions.Compiled);
    
    // Pattern to detect all potential placeholders (including invalid ones)
    private static readonly Regex InvalidPlaceholderPattern = new(@"<%([^%]*)%>", RegexOptions.Compiled);
    
    public DocumentPlaceholderService(ILogger<DocumentPlaceholderService> logger)
    {
        _logger = logger;
    }
    public async Task<List<string>> ExtractPlaceholdersFromDocxAsync(Stream fileStream, string fileName)
    {
        try
        {
            var placeholders = new HashSet<string>();
            using (var document = WordprocessingDocument.Open(fileStream, false))
            {
                if (document.MainDocumentPart == null)
                {
                    _logger.LogWarning("Document {FileName} has no main document part", fileName);
                    return new List<string>();
                }
                var body = document.MainDocumentPart.Document.Body;
                if (body == null)
                {
                    _logger.LogWarning("Document {FileName} has no body", fileName);
                    return new List<string>();
                }
                
                // Extract from main document body using paragraph-based extraction
                _logger.LogDebug("Extracting placeholders from main document body");
                ExtractPlaceholdersFromPart(body, placeholders);
                
                // Also check in headers and footers
                foreach (var headerPart in document.MainDocumentPart.HeaderParts)
                {
                    _logger.LogDebug("Extracting placeholders from header");
                    ExtractPlaceholdersFromPart(headerPart.Header, placeholders);
                }
                foreach (var footerPart in document.MainDocumentPart.FooterParts)
                {
                    _logger.LogDebug("Extracting placeholders from footer");
                    ExtractPlaceholdersFromPart(footerPart.Footer, placeholders);
                }
            }
            _logger.LogInformation("Extracted {Count} unique placeholders from {FileName}", 
                placeholders.Count, fileName);
            return await Task.FromResult(placeholders.OrderBy(p => p).ToList());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting placeholders from {FileName}", fileName);
            throw;
        }
    }

    public async Task<List<string>> ExtractBooleanContentControlsFromDocxAsync(Stream fileStream, string fileName)
    {
        try
        {
            var allControls = await ExtractContentControlsFromDocxAsync(fileStream, fileName);
            return allControls
                .Where(kvp => string.Equals(kvp.Value, "boolean", StringComparison.OrdinalIgnoreCase))
                .Select(kvp => kvp.Key)
                .ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error detecting boolean content controls in {FileName}", fileName);
            throw;
        }
    }

    public async Task<Dictionary<string, string>> ExtractContentControlsFromDocxAsync(Stream fileStream, string fileName)
    {
        try
        {
            var contentControls = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            
            using (var document = WordprocessingDocument.Open(fileStream, false))
            {
                if (document.MainDocumentPart == null)
                {
                    _logger.LogWarning("Document {FileName} has no main document part", fileName);
                    return contentControls;
                }

                _logger.LogDebug("Starting to extract all content controls from {FileName}", fileName);

                // Search in main document
                var mainDocSdts = document.MainDocumentPart.Document.Descendants<SdtElement>().ToList();
                _logger.LogDebug("Found {Count} SDT elements in main document", mainDocSdts.Count);
                ProcessAllSdtElements(mainDocSdts, contentControls, "MainDocument");

                // Search in headers
                foreach (var headerPart in document.MainDocumentPart.HeaderParts)
                {
                    var headerSdts = headerPart.Header.Descendants<SdtElement>().ToList();
                    _logger.LogDebug("Found {Count} SDT elements in header", headerSdts.Count);
                    ProcessAllSdtElements(headerSdts, contentControls, "Header");
                }
                
                // Search in footers
                foreach (var footerPart in document.MainDocumentPart.FooterParts)
                {
                    var footerSdts = footerPart.Footer.Descendants<SdtElement>().ToList();
                    _logger.LogDebug("Found {Count} SDT elements in footer", footerSdts.Count);
                    ProcessAllSdtElements(footerSdts, contentControls, "Footer");
                }
            }

            _logger.LogInformation("Found {Count} content controls in {FileName}", contentControls.Count, fileName);
            return await Task.FromResult(contentControls);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting content controls from {FileName}", fileName);
            throw;
        }
    }

    private void ProcessAllSdtElements(IEnumerable<SdtElement> sdts, Dictionary<string, string> result, string location = "Unknown")
    {
        int processedCount = 0;
        int addedCount = 0;
        int skippedCount = 0;

        foreach (var sdt in sdts)
        {
            processedCount++;
            try
            {
                var sdtProps = sdt.SdtProperties;
                if (sdtProps == null)
                {
                    _logger.LogDebug("SDT #{Index} in {Location}: No SdtProperties found", processedCount, location);
                    skippedCount++;
                    continue;
                }

                // Get identifier from Tag, then Alias, then ID
                string? tagVal = sdtProps.GetFirstChild<Tag>()?.Val?.Value;
                string? aliasVal = sdtProps.GetFirstChild<SdtAlias>()?.Val?.Value;
                string? idVal = sdtProps.GetFirstChild<SdtId>()?.Val?.ToString();

                string identifier = !string.IsNullOrWhiteSpace(tagVal) ? tagVal
                                  : !string.IsNullOrWhiteSpace(aliasVal) ? aliasVal
                                  : !string.IsNullOrWhiteSpace(idVal) ? $"sdt_id_{idVal}"
                                  : $"sdt_{processedCount}";

                // Determine control type
                string? controlType = DetermineControlType(sdtProps);

                // Skip if type is null (not interested in this control)
                if (controlType == null)
                {
                    _logger.LogDebug("SDT #{Index} in {Location}: Identifier='{Identifier}', Type=skipped (not interested)",
                        processedCount, location, identifier);
                    skippedCount++;
                    continue;
                }

                _logger.LogDebug("SDT #{Index} in {Location}: Identifier='{Identifier}', Type='{Type}'",
                    processedCount, location, identifier, controlType);

                // Add to result (skip duplicates)
                if (!result.ContainsKey(identifier))
                {
                    result.Add(identifier, controlType);
                    addedCount++;
                }
                else
                {
                    _logger.LogWarning("SDT #{Index} in {Location}: Duplicate identifier '{Identifier}' - skipping",
                        processedCount, location, identifier);
                    skippedCount++;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "SDT #{Index} in {Location}: Failed to process SdtElement", processedCount, location);
                skippedCount++;
            }
        }

        _logger.LogInformation("Processed {TotalCount} SDT elements in {Location}: added {AddedCount}, skipped {SkippedCount}",
            processedCount, location, addedCount, skippedCount);
    }

    private string? DetermineControlType(SdtProperties sdtProps)
    {
        // Ignoruj natywne typy Word - nie interesują nas
        if (sdtProps.Elements<SdtContentCheckBox>().Any())
        {
            _logger.LogDebug("Skipping checkbox control - not interested");
            return null;
        }

        if (sdtProps.Elements<SdtContentDate>().Any())
        {
            _logger.LogDebug("Skipping date control - not interested");
            return null;
        }

        if (sdtProps.Elements<SdtContentDropDownList>().Any())
        {
            _logger.LogDebug("Skipping dropdown control - not interested");
            return null;
        }

        if (sdtProps.Elements<SdtContentComboBox>().Any())
        {
            _logger.LogDebug("Skipping combobox control - not interested");
            return null;
        }

        if (sdtProps.Elements<SdtContentPicture>().Any())
        {
            _logger.LogDebug("Skipping picture control - not interested");
            return null;
        }

        // Wszystkie pozostałe to Rich Text / Plain Text controls
        // Zwracamy "boolean" zamiast "text" zgodnie z wymaganiem
        _logger.LogDebug("Found text/richtext control - returning as 'boolean'");
        return "boolean";
    }

    private void ExtractPlaceholdersFromPart(OpenXmlElement element, HashSet<string> placeholders)
    {
        // Problem: Word często rozbija tekst placeholder na wiele <w:t> elementów
        // np. <w:t><%</w:t><w:t>data</w:t><w:t>%></w:t>
        // Rozwiązanie: zbieramy cały tekst z każdego paragrafu i dopiero wtedy szukamy placeholders
        
        var paragraphs = element.Descendants<Paragraph>();
        foreach (var paragraph in paragraphs)
        {
            // Zbierz cały tekst z paragrafu
            var fullText = string.Concat(paragraph.Descendants<Text>().Select(t => t.Text));
            
            if (string.IsNullOrWhiteSpace(fullText))
                continue;
            
            // Najpierw sprawdź czy są jakiekolwiek nieprawidłowe placeholdery
            var allPotentialMatches = InvalidPlaceholderPattern.Matches(fullText);
            foreach (Match potentialMatch in allPotentialMatches)
            {
                if (!potentialMatch.Success)
                    continue;
                    
                var content = potentialMatch.Groups[1].Value;
                
                // Sprawdź czy to pusty placeholder
                if (string.IsNullOrWhiteSpace(content))
                {
                    _logger.LogWarning("Found empty placeholder '<%%>' in document - this is invalid and will be ignored");
                    continue;
                }
                
                // Sprawdź czy zawiera spacje
                if (content.Contains(' ') || content.Contains('\t') || content.Contains('\n') || content.Contains('\r'))
                {
                    _logger.LogWarning("Found placeholder with whitespace '<%{Content}%>' in document - placeholders cannot contain spaces and will be ignored", 
                        content);
                    continue;
                }
                
                // Sprawdź czy zawiera niedozwolone znaki
                if (!Regex.IsMatch(content, @"^[a-zA-Z0-9_]+$"))
                {
                    _logger.LogWarning("Found placeholder with invalid characters '<%{Content}%>' in document - only alphanumeric and underscore are allowed", 
                        content);
                }
            }
                
            // Teraz szukaj poprawnych placeholders
            var validMatches = PlaceholderRegex.Matches(fullText);
            foreach (Match match in validMatches)
            {
                if (match.Success)
                {
                    placeholders.Add(match.Value);
                }
            }
        }
    }
}
