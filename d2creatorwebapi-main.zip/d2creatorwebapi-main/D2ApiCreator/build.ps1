# Build D2ApiCreator Solution
# Ten skrypt najpierw zatrzymuje aplikację, a następnie buduje rozwiązanie

Write-Host "=== Build D2ApiCreator ===" -ForegroundColor Cyan
Write-Host ""

# Krok 1: Zatrzymanie uruchomionych procesów
Write-Host "[1/3] Zatrzymywanie uruchomionych procesów..." -ForegroundColor Yellow
$processes = Get-Process | Where-Object {$_.ProcessName -like "*D2ApiCreator*"}
if ($processes) {
    $processes | Stop-Process -Force -ErrorAction SilentlyContinue
    Write-Host "  ✓ Zatrzymano $($processes.Count) proces(ów)" -ForegroundColor Green
} else {
    Write-Host "  ✓ Brak uruchomionych procesów" -ForegroundColor Green
}

Start-Sleep -Seconds 1

# Krok 2: Czyszczenie bin/obj (opcjonalne - zakomentowane)
# Write-Host "[2/3] Czyszczenie katalogów bin i obj..." -ForegroundColor Yellow
# dotnet clean D2ApiCreator.sln --verbosity quiet
# Write-Host "  ✓ Wyczyszczono" -ForegroundColor Green

# Krok 3: Budowanie rozwiązania
Write-Host "[2/3] Budowanie rozwiązania..." -ForegroundColor Yellow
$buildResult = dotnet build D2ApiCreator.sln --nologo

if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ Build zakończony sukcesem!" -ForegroundColor Green
    Write-Host ""
    Write-Host "=== Build completed successfully ===" -ForegroundColor Green
} else {
    Write-Host "  ✗ Build zakończony niepowodzeniem!" -ForegroundColor Red
    Write-Host ""
    Write-Host "=== Build failed ===" -ForegroundColor Red
    Write-Host "Sprawdź błędy powyżej." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Aby uruchomić aplikację:" -ForegroundColor Cyan
Write-Host "  cd D2ApiCreator.Api" -ForegroundColor White
Write-Host "  dotnet run" -ForegroundColor White

