# Stop D2ApiCreator Application
# Ten skrypt zatrzymuje wszystkie uruchomione instancje aplikacji D2ApiCreator

Write-Host "Szukanie procesów D2ApiCreator..." -ForegroundColor Yellow

$processes = Get-Process | Where-Object {
    $_.ProcessName -like "*D2ApiCreator*" -or 
    $_.MainWindowTitle -like "*D2ApiCreator*"
}

if ($processes) {
    Write-Host "Znaleziono $($processes.Count) proces(ów):" -ForegroundColor Green
    $processes | ForEach-Object {
        Write-Host "  - PID: $($_.Id), Nazwa: $($_.ProcessName), Pamięć: $([math]::Round($_.WorkingSet64/1MB, 2)) MB" -ForegroundColor Cyan
    }
    
    Write-Host "`nZatrzymywanie procesów..." -ForegroundColor Yellow
    $processes | Stop-Process -Force
    Write-Host "✓ Wszystkie procesy zostały zatrzymane!" -ForegroundColor Green
} else {
    Write-Host "Nie znaleziono uruchomionych procesów D2ApiCreator." -ForegroundColor Gray
}

Write-Host "`nMożesz teraz zbudować projekt używając:" -ForegroundColor Cyan
Write-Host "  dotnet build D2ApiCreator.sln" -ForegroundColor White

