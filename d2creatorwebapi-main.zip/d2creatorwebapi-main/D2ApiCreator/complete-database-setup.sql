-- ============================================================================
-- D2ApiCreator - Complete Database Initialization Script
-- PostgreSQL 16+
-- ============================================================================
-- Autor: D2ApiCreator Team
-- Data: 2025-11-24
-- 
-- INSTRUKCJA UŻYCIA:
-- 1. Połącz się z bazą danych:
--    podman exec -it d2creator-postgres psql -U postgres -d D2CreatorDb
-- 2. Wykonaj ten plik:
--    \i /path/to/complete-database-setup.sql
-- LUB z PowerShell:
--    Get-Content complete-database-setup.sql | podman exec -i d2creator-postgres psql -U postgres -d D2CreatorDb
-- ============================================================================

\echo ''
\echo '╔══════════════════════════════════════════════════════════════════════╗'
\echo '║              D2ApiCreator - Database Setup Script                   ║'
\echo '║                    PostgreSQL 16+                                    ║'
\echo '╚══════════════════════════════════════════════════════════════════════╝'
\echo ''

-- ============================================================================
-- SEKCJA 1: TABELE GŁÓWNE
-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [1/9] Tworzenie tabeli Tenants (Multi-tenancy)...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    metadata JSONB,
    CONSTRAINT ck_tenants_name_not_empty CHECK (LENGTH(TRIM(name)) > 0)
);

CREATE INDEX IF NOT EXISTS idx_tenants_is_active ON tenants(is_active);
CREATE INDEX IF NOT EXISTS idx_tenants_created_by ON tenants(created_by);

\echo '  ✓ Tabela tenants utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [2/9] Tworzenie tabeli Users...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "Users" (
    "Id" UUID PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "Email" VARCHAR(255) NOT NULL UNIQUE,
    "FirstName" VARCHAR(100),
    "LastName" VARCHAR(100),
    "IsActive" BOOLEAN NOT NULL DEFAULT true,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Users_Tenants" FOREIGN KEY ("TenantId") 
        REFERENCES "Tenants" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Users_Email_NotEmpty" CHECK (LENGTH(TRIM("Email")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Users_TenantId" ON "Users" ("TenantId");
CREATE INDEX IF NOT EXISTS "IX_Users_Email" ON "Users" ("Email");
CREATE INDEX IF NOT EXISTS "IX_Users_IsActive" ON "Users" ("IsActive");

\echo '  ✓ Tabela Users utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [3/9] Tworzenie tabeli Projects...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY,
    tenant_id UUID,  -- NULLABLE - projekt może nie mieć tenanta
    source VARCHAR(200) NOT NULL UNIQUE,
    name VARCHAR(500) NOT NULL,
    description TEXT,
    retention_days INTEGER NOT NULL DEFAULT 90,
    default_template_name VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_by UUID,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    current_active_version_id UUID,
    metadata JSONB,
    CONSTRAINT fk_projects_tenants FOREIGN KEY (tenant_id) 
        REFERENCES tenants (id) ON DELETE SET NULL,
    CONSTRAINT ck_projects_name_not_empty CHECK (LENGTH(TRIM(name)) > 0),
    CONSTRAINT ck_projects_retention_positive CHECK (retention_days > 0)
);

CREATE INDEX IF NOT EXISTS idx_projects_tenant_id ON projects(tenant_id);
CREATE INDEX IF NOT EXISTS idx_projects_source ON projects(source);
CREATE INDEX IF NOT EXISTS idx_projects_is_active ON projects(is_active);
CREATE INDEX IF NOT EXISTS idx_projects_created_at ON projects(created_at);
CREATE INDEX IF NOT EXISTS idx_projects_tenant_source ON projects(tenant_id, source);

\echo '  ✓ Tabela projects utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [4/9] Tworzenie tabeli ProjectVersions + Trigger...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS project_versions (
    id UUID PRIMARY KEY,
    project_id UUID NOT NULL,
    major INTEGER NOT NULL DEFAULT 1,
    minor INTEGER NOT NULL DEFAULT 0,
    version_tag VARCHAR(50) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT false,
    status VARCHAR(50) NOT NULL DEFAULT 'Draft',
    step_data JSONB NOT NULL DEFAULT '{}',
    notes TEXT,
    created_by UUID,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    CONSTRAINT fk_project_versions_projects FOREIGN KEY (project_id) 
        REFERENCES projects (id) ON DELETE CASCADE,
    CONSTRAINT ck_project_versions_major_positive CHECK (major > 0),
    CONSTRAINT ck_project_versions_minor_non_negative CHECK (minor >= 0),
    CONSTRAINT uq_project_versions_project_version 
        UNIQUE (project_id, version_tag)
);

CREATE INDEX IF NOT EXISTS idx_project_versions_project_id ON project_versions(project_id);
CREATE INDEX IF NOT EXISTS idx_project_versions_is_active ON project_versions(is_active);
CREATE INDEX IF NOT EXISTS idx_project_versions_status ON project_versions(status);
CREATE INDEX IF NOT EXISTS idx_project_versions_created_at ON project_versions(created_at);

-- Trigger Function: Zapewnia że tylko jedna wersja projektu może być aktywna
CREATE OR REPLACE FUNCTION ensure_single_active_version()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.is_active = true THEN
        -- Dezaktywuj wszystkie inne wersje tego projektu
        UPDATE project_versions
        SET is_active = false, updated_at = NOW()
        WHERE project_id = NEW.project_id
          AND id != NEW.id
          AND is_active = true;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Wykonuje funkcję przed INSERT lub UPDATE
DROP TRIGGER IF EXISTS trigger_single_active_version ON project_versions;
CREATE TRIGGER trigger_single_active_version
    BEFORE INSERT OR UPDATE ON project_versions
    FOR EACH ROW
    EXECUTE FUNCTION ensure_single_active_version();

\echo '  ✓ Tabela project_versions utworzona'
\echo '  ✓ Trigger ensure_single_active_version dodany'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [5/9] Tworzenie tabeli Files...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "Files" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "FileName" VARCHAR(255) NOT NULL,
    "FileType" VARCHAR(50) NOT NULL,
    "FilePath" VARCHAR(500) NOT NULL,
    "FileSize" BIGINT NOT NULL,
    "UploadedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "UploadedBy" UUID,
    CONSTRAINT "FK_Files_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Files_FileSize_Positive" CHECK ("FileSize" > 0),
    CONSTRAINT "CK_Files_FileName_NotEmpty" CHECK (LENGTH(TRIM("FileName")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Files_ProjectVersionId" ON "Files" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Files_FileType" ON "Files" ("FileType");
CREATE INDEX IF NOT EXISTS "IX_Files_UploadedAt" ON "Files" ("UploadedAt");

\echo '  ✓ Tabela Files utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [6/9] Tworzenie tabeli Mappings...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "Mappings" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "Placeholder" VARCHAR(200) NOT NULL,
    "MappingType" VARCHAR(50) NOT NULL,
    "SourceField" VARCHAR(200),
    "DefaultValue" TEXT,
    "CreatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Mappings_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_Mappings_Placeholder_NotEmpty" CHECK (LENGTH(TRIM("Placeholder")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_Mappings_ProjectVersionId" ON "Mappings" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Mappings_MappingType" ON "Mappings" ("MappingType");
CREATE INDEX IF NOT EXISTS "IX_Mappings_Placeholder" ON "Mappings" ("Placeholder");

\echo '  ✓ Tabela Mappings utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [7/9] Tworzenie tabeli Approvals...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "Approvals" (
    "Id" UUID PRIMARY KEY,
    "ProjectVersionId" UUID NOT NULL,
    "ApprovedBy" UUID NOT NULL,
    "ApprovalStatus" VARCHAR(50) NOT NULL,
    "Comment" TEXT,
    "ApprovedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_Approvals_ProjectVersions" FOREIGN KEY ("ProjectVersionId") 
        REFERENCES "ProjectVersions" ("Id") ON DELETE CASCADE,
    CONSTRAINT "FK_Approvals_Users" FOREIGN KEY ("ApprovedBy") 
        REFERENCES "Users" ("Id")
);

CREATE INDEX IF NOT EXISTS "IX_Approvals_ProjectVersionId" ON "Approvals" ("ProjectVersionId");
CREATE INDEX IF NOT EXISTS "IX_Approvals_ApprovedBy" ON "Approvals" ("ApprovedBy");
CREATE INDEX IF NOT EXISTS "IX_Approvals_ApprovalStatus" ON "Approvals" ("ApprovalStatus");
CREATE INDEX IF NOT EXISTS "IX_Approvals_ApprovedAt" ON "Approvals" ("ApprovedAt");

\echo '  ✓ Tabela Approvals utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [8/9] Tworzenie tabeli AuditLogs...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "AuditLogs" (
    "Id" UUID PRIMARY KEY,
    "TenantId" UUID NOT NULL,
    "EntityName" VARCHAR(100) NOT NULL,
    "EntityId" UUID NOT NULL,
    "Action" VARCHAR(50) NOT NULL,
    "Changes" JSONB,
    "PerformedBy" UUID,
    "PerformedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT "FK_AuditLogs_Tenants" FOREIGN KEY ("TenantId") 
        REFERENCES "Tenants" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_AuditLogs_EntityName_NotEmpty" CHECK (LENGTH(TRIM("EntityName")) > 0)
);

CREATE INDEX IF NOT EXISTS "IX_AuditLogs_TenantId" ON "AuditLogs" ("TenantId");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_EntityName" ON "AuditLogs" ("EntityName");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_EntityId" ON "AuditLogs" ("EntityId");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_Action" ON "AuditLogs" ("Action");
CREATE INDEX IF NOT EXISTS "IX_AuditLogs_PerformedAt" ON "AuditLogs" ("PerformedAt");

\echo '  ✓ Tabela AuditLogs utworzona'
\echo ''

-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 [9/9] Tworzenie tabeli ParseResults...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

CREATE TABLE IF NOT EXISTS "ParseResults" (
    "Id" UUID PRIMARY KEY,
    "FileId" UUID NOT NULL,
    "PlaceholdersFound" INTEGER NOT NULL DEFAULT 0,
    "PlaceholdersJson" JSONB NOT NULL DEFAULT '[]',
    "ParsedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
    "Status" VARCHAR(50) NOT NULL,
    "ErrorMessage" TEXT,
    CONSTRAINT "FK_ParseResults_Files" FOREIGN KEY ("FileId") 
        REFERENCES "Files" ("Id") ON DELETE CASCADE,
    CONSTRAINT "CK_ParseResults_PlaceholdersFound_NonNegative" CHECK ("PlaceholdersFound" >= 0)
);

CREATE INDEX IF NOT EXISTS "IX_ParseResults_FileId" ON "ParseResults" ("FileId");
CREATE INDEX IF NOT EXISTS "IX_ParseResults_Status" ON "ParseResults" ("Status");
CREATE INDEX IF NOT EXISTS "IX_ParseResults_ParsedAt" ON "ParseResults" ("ParsedAt");

\echo '  ✓ Tabela ParseResults utworzona'
\echo ''

-- ============================================================================
-- SEKCJA 2: DANE STARTOWE
-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 Dodawanie przykładowych danych startowych...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

-- Dodaj domyślnego tenanta
INSERT INTO tenants (id, name, description, is_active, created_at)
VALUES (gen_random_uuid(), 'Default Tenant', 'Default organization tenant', true, NOW())
ON CONFLICT DO NOTHING;

\echo '  ✓ Dodano domyślnego tenanta'

-- Dodaj przykładowego użytkownika admin
INSERT INTO users (id, tenant_id, email, first_name, last_name, is_active, created_at)
SELECT gen_random_uuid(), t.id, 'admin@default.com', 'Admin', 'User', true, NOW()
FROM tenants t WHERE t.name = 'Default Tenant'
ON CONFLICT (email) DO NOTHING;

\echo '  ✓ Dodano użytkownika admin (email: admin@default.com)'
\echo ''

-- ============================================================================
-- SEKCJA 3: WERYFIKACJA
-- ============================================================================

\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo '📋 Weryfikacja utworzonych tabel...'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo ''

SELECT 
    COUNT(*) as "Liczba Tabel",
    STRING_AGG(table_name, ', ' ORDER BY table_name) as "Nazwy Tabel"
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_type = 'BASE TABLE';

\echo ''
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo 'Szczegóły tabel:'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

SELECT 
    schemaname as "Schema",
    tablename as "Tabela",
    (SELECT COUNT(*) FROM pg_indexes WHERE tablename = t.tablename) as "Liczba Indeksów"
FROM pg_tables t
WHERE schemaname = 'public'
ORDER BY tablename;

\echo ''
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
\echo 'Sprawdzenie danych startowych:'
\echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

\echo ''
\echo 'Tenants:'
SELECT "Id", "Name", "Code", "IsActive", "CreatedAt" FROM "Tenants";

\echo ''
\echo 'Users:'
SELECT "Id", "Email", "FirstName", "LastName", "IsActive" FROM "Users";

-- ============================================================================
-- SEKCJA 4: PODSUMOWANIE
-- ============================================================================

\echo ''
\echo '╔══════════════════════════════════════════════════════════════════════╗'
\echo '║                    SETUP ZAKOŃCZONY POMYŚLNIE!                      ║'
\echo '╚══════════════════════════════════════════════════════════════════════╝'
\echo ''
\echo '✅ Utworzono 9 tabel:'
\echo '   1. Tenants           - Organizacje/firmy (multi-tenancy)'
\echo '   2. Users             - Użytkownicy systemu'
\echo '   3. Projects          - Projekty dokumentów'
\echo '   4. ProjectVersions   - Wersje projektów (z triggerem)'
\echo '   5. Files             - Przesłane pliki/szablony'
\echo '   6. Mappings          - Mapowania placeholderów'
\echo '   7. Approvals         - Zatwierdzenia wersji'
\echo '   8. AuditLogs         - Logi audytowe'
\echo '   9. ParseResults      - Wyniki parsowania dokumentów'
\echo ''
\echo '✅ Dodano dane startowe:'
\echo '   • Tenant:   DEFAULT (Default Tenant)'
\echo '   • User:     admin@default.com (Admin User)'
\echo ''
\echo '✅ Utworzono trigger:'
\echo '   • ensure_single_active_version() - zapewnia tylko 1 aktywną wersję'
\echo ''
\echo '📌 Dane połączenia:'
\echo '   Host:       localhost'
\echo '   Port:       5432'
\echo '   Database:   D2CreatorDb'
\echo '   Username:   postgres'
\echo '   Password:   postgres'
\echo ''
\echo '🚀 Możesz teraz uruchomić aplikację:'
\echo '   .\restart-app.ps1'
\echo '   lub'
\echo '   dotnet run --project D2ApiCreator.Api\D2ApiCreator.Api.csproj'
\echo ''
\echo '🌐 Aplikacja będzie dostępna pod:'
\echo '   https://localhost:5001/swagger'
\echo ''
\echo '╚══════════════════════════════════════════════════════════════════════╝'
\echo ''

