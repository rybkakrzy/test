# Setup PostgreSQL w Podman i zainicjalizuj bazę danych
# Autor: D2ApiCreator Team
# Data: 2025-11-24

param(
    [switch]$SkipContainerCreation,
    [switch]$SkipDatabaseInit
)

$ErrorActionPreference = "Stop"

Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   Setup PostgreSQL dla D2ApiCreator na Podman           ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Funkcja do sprawdzania czy podman jest zainstalowany
function Test-PodmanInstalled {
    try {
        $null = podman --version
        return $true
    }
    catch {
        return $false
    }
}

# Funkcja do sprawdzania czy kontener istnieje
function Test-ContainerExists {
    param([string]$ContainerName)
    $containers = podman ps -a --format "{{.Names}}"
    return $containers -contains $ContainerName
}

# Krok 0: Sprawdź czy Podman jest zainstalowany
if (-not (Test-PodmanInstalled)) {
    Write-Host "❌ Podman nie jest zainstalowany!" -ForegroundColor Red
    Write-Host "   Pobierz Podman Desktop z: https://podman.io/getting-started/installation" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Podman jest zainstalowany" -ForegroundColor Green

if (-not $SkipContainerCreation) {
    # Krok 1: Sprawdź czy kontener już istnieje
    Write-Host "`n[1/6] Sprawdzanie istniejącego kontenera..." -ForegroundColor Yellow
    if (Test-ContainerExists "d2creator-postgres") {
        Write-Host "⚠ Kontener 'd2creator-postgres' już istnieje" -ForegroundColor Yellow
        $response = Read-Host "Czy chcesz go usunąć i utworzyć nowy? (t/n)"
        if ($response -eq "t" -or $response -eq "T") {
            Write-Host "Usuwanie starego kontenera..." -ForegroundColor Yellow
            podman rm -f d2creator-postgres 2>$null
            Write-Host "✓ Stary kontener usunięty" -ForegroundColor Green
        }
        else {
            Write-Host "Pomijam tworzenie kontenera..." -ForegroundColor Yellow
            $SkipContainerCreation = $true
        }
    }
}

if (-not $SkipContainerCreation) {
    # Krok 2: Utwórz volume
    Write-Host "`n[2/6] Tworzenie volume dla danych PostgreSQL..." -ForegroundColor Yellow
    try {
        podman volume create d2creator-pgdata 2>$null
        Write-Host "✓ Volume 'd2creator-pgdata' utworzony" -ForegroundColor Green
    }
    catch {
        Write-Host "⚠ Volume już istnieje (to jest OK)" -ForegroundColor Yellow
    }

    # Krok 3: Uruchom kontener PostgreSQL
    Write-Host "`n[3/6] Uruchamianie kontenera PostgreSQL..." -ForegroundColor Yellow
    podman run -d `
        --name d2creator-postgres `
        -e POSTGRES_USER=postgres `
        -e POSTGRES_PASSWORD=postgres `
        -e POSTGRES_DB=D2CreatorDb `
        -p 5432:5432 `
        -v d2creator-pgdata:/var/lib/postgresql/data `
        postgres:16-alpine

    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Kontener uruchomiony" -ForegroundColor Green
    }
    else {
        Write-Host "❌ Błąd uruchamiania kontenera" -ForegroundColor Red
        exit 1
    }

    # Krok 4: Poczekaj aż PostgreSQL się uruchomi
    Write-Host "`n[4/6] Oczekiwanie na uruchomienie PostgreSQL..." -ForegroundColor Yellow
    $maxRetries = 30
    $retryCount = 0
    $connected = $false

    while ($retryCount -lt $maxRetries -and -not $connected) {
        Start-Sleep -Seconds 1
        $retryCount++
        Write-Host "." -NoNewline
        
        try {
            $result = podman exec d2creator-postgres pg_isready -U postgres 2>$null
            if ($LASTEXITCODE -eq 0) {
                $connected = $true
            }
        }
        catch {
            # Kontynuuj próby
        }
    }

    Write-Host ""
    if ($connected) {
        Write-Host "✓ PostgreSQL gotowy do pracy" -ForegroundColor Green
    }
    else {
        Write-Host "❌ PostgreSQL nie odpowiada po $maxRetries sekundach" -ForegroundColor Red
        Write-Host "Sprawdź logi: podman logs d2creator-postgres" -ForegroundColor Yellow
        exit 1
    }
}
else {
    Write-Host "`n[2-4/6] Pomijam tworzenie kontenera..." -ForegroundColor Yellow
    
    # Sprawdź czy kontener działa
    $containerStatus = podman ps --filter "name=d2creator-postgres" --format "{{.Status}}"
    if (-not $containerStatus) {
        Write-Host "Uruchamianie istniejącego kontenera..." -ForegroundColor Yellow
        podman start d2creator-postgres
        Start-Sleep -Seconds 3
    }
}

if (-not $SkipDatabaseInit) {
    # Krok 5: Inicjalizacja bazy danych
    Write-Host "`n[5/6] Inicjalizacja bazy danych..." -ForegroundColor Yellow
    
    $sqlScriptsPath = Join-Path $PSScriptRoot "database-init.sql"
    
    if (Test-Path $sqlScriptsPath) {
        Write-Host "Wykonywanie skryptu: $sqlScriptsPath" -ForegroundColor Cyan
        Get-Content $sqlScriptsPath | podman exec -i d2creator-postgres psql -U postgres -d D2CreatorDb
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ Skrypt SQL wykonany pomyślnie" -ForegroundColor Green
        }
        else {
            Write-Host "⚠ Wystąpiły błędy podczas wykonywania skryptu" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "⚠ Plik database-init.sql nie został znaleziony" -ForegroundColor Yellow
        Write-Host "Wykonaj ręcznie 4 skrypty SQL z pliku PODMAN_POSTGRES_SETUP.md" -ForegroundColor Yellow
    }
}
else {
    Write-Host "`n[5/6] Pomijam inicjalizację bazy danych..." -ForegroundColor Yellow
}

# Krok 6: Weryfikacja
Write-Host "`n[6/6] Weryfikacja..." -ForegroundColor Yellow
Write-Host "Status kontenera:" -ForegroundColor Cyan
podman ps | Select-String "d2creator-postgres"

Write-Host "`nListowanie tabel w bazie danych:" -ForegroundColor Cyan
$tablesOutput = podman exec d2creator-postgres psql -U postgres -d D2CreatorDb -c "\dt" 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Host $tablesOutput
    Write-Host "✓ Baza danych działa poprawnie" -ForegroundColor Green
}
else {
    Write-Host "⚠ Nie można połączyć się z bazą danych" -ForegroundColor Yellow
}

# Podsumowanie
Write-Host "`n╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                  SETUP ZAKOŃCZONY                        ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "✅ PostgreSQL uruchomiony na Podman" -ForegroundColor Green
Write-Host "   Kontener:  d2creator-postgres" -ForegroundColor White
Write-Host "   Host:      localhost" -ForegroundColor White
Write-Host "   Port:      5432" -ForegroundColor White
Write-Host "   Database:  D2CreatorDb" -ForegroundColor White
Write-Host "   User:      postgres" -ForegroundColor White
Write-Host "   Password:  postgres" -ForegroundColor White
Write-Host ""
Write-Host "📌 Przydatne komendy:" -ForegroundColor Cyan
Write-Host "   Sprawdź status:     podman ps" -ForegroundColor White
Write-Host "   Zatrzymaj:          podman stop d2creator-postgres" -ForegroundColor White
Write-Host "   Uruchom:            podman start d2creator-postgres" -ForegroundColor White
Write-Host "   Logi:               podman logs d2creator-postgres" -ForegroundColor White
Write-Host "   Połącz się (psql):  podman exec -it d2creator-postgres psql -U postgres -d D2CreatorDb" -ForegroundColor White
Write-Host ""
Write-Host "🚀 Uruchom aplikację:" -ForegroundColor Cyan
Write-Host "   .\restart-app.ps1" -ForegroundColor White
Write-Host "   lub" -ForegroundColor Gray
Write-Host "   dotnet run --project D2ApiCreator.Api\D2ApiCreator.Api.csproj" -ForegroundColor White
Write-Host ""

