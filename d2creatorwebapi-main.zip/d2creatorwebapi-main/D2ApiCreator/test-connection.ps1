# Test Connection String - Weryfikacja połączenia z PostgreSQL
# Użycie: .\test-connection.ps1

$ErrorActionPreference = "Stop"

Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   Test Connection String - PostgreSQL                    ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Funkcja do parsowania connection string
function Parse-ConnectionString {
    param([string]$ConnStr)
    
    $parts = $ConnStr -split ';'
    $dict = @{}
    
    foreach ($part in $parts) {
        if ($part -match '^\s*([^=]+)\s*=\s*(.+)\s*$') {
            $key = $matches[1].Trim()
            $value = $matches[2].Trim()
            $dict[$key] = $value
        }
    }
    
    return $dict
}

# Wczytaj appsettings.json
Write-Host "[1/4] Wczytywanie appsettings.json..." -ForegroundColor Yellow
$appsettingsPath = "D2ApiCreator.Api\appsettings.json"

if (-not (Test-Path $appsettingsPath)) {
    Write-Host "❌ Nie znaleziono pliku: $appsettingsPath" -ForegroundColor Red
    exit 1
}

$appsettings = Get-Content $appsettingsPath | ConvertFrom-Json
$connectionString = $appsettings.ConnectionStrings.DefaultConnection

if ([string]::IsNullOrEmpty($connectionString)) {
    Write-Host "❌ Connection string jest pusty!" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Connection string wczytany" -ForegroundColor Green
Write-Host ""

# Parsuj i wyświetl szczegóły
Write-Host "[2/4] Analiza connection string..." -ForegroundColor Yellow
$connDetails = Parse-ConnectionString $connectionString

Write-Host "  Host:     $($connDetails['Host'])" -ForegroundColor White
Write-Host "  Port:     $($connDetails['Port'])" -ForegroundColor White
Write-Host "  Database: $($connDetails['Database'])" -ForegroundColor White
Write-Host "  Username: $($connDetails['Username'])" -ForegroundColor White

if ($connDetails.ContainsKey('Password')) {
    $passLength = $connDetails['Password'].Length
    $maskedPass = '*' * $passLength
    Write-Host "  Password: $maskedPass (długość: $passLength)" -ForegroundColor Green
} else {
    Write-Host "  Password: ❌ BRAK!" -ForegroundColor Red
    Write-Host ""
    Write-Host "⚠️  BŁĄD: Connection string nie zawiera hasła!" -ForegroundColor Yellow
    Write-Host "   Dodaj: ;Password=postgres" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Sprawdź czy PostgreSQL działa
Write-Host "[3/4] Sprawdzanie czy PostgreSQL działa..." -ForegroundColor Yellow

try {
    $containerStatus = podman ps --filter "name=d2creator-postgres" --format "{{.Status}}" 2>$null
    
    if ($containerStatus) {
        Write-Host "✓ Kontener PostgreSQL działa: $containerStatus" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Kontener PostgreSQL nie jest uruchomiony" -ForegroundColor Yellow
        Write-Host "   Uruchom: podman start d2creator-postgres" -ForegroundColor White
        Write-Host "   lub:     .\setup-database.ps1" -ForegroundColor White
    }
} catch {
    Write-Host "⚠️  Podman nie jest dostępny lub kontener nie istnieje" -ForegroundColor Yellow
}
Write-Host ""

# Test połączenia
Write-Host "[4/4] Test połączenia z bazą danych..." -ForegroundColor Yellow

try {
    $testResult = podman exec d2creator-postgres psql -U $connDetails['Username'] -d $connDetails['Database'] -c "SELECT version();" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Połączenie z bazą danych DZIAŁA!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Wersja PostgreSQL:" -ForegroundColor Cyan
        $testResult | Select-String "PostgreSQL" | ForEach-Object { Write-Host "  $_" -ForegroundColor White }
    } else {
        Write-Host "❌ Nie można połączyć się z bazą danych" -ForegroundColor Red
        Write-Host "   Błąd: $testResult" -ForegroundColor Red
    }
} catch {
    Write-Host "⚠️  Nie można przetestować połączenia" -ForegroundColor Yellow
    Write-Host "   Upewnij się że kontener działa: podman ps" -ForegroundColor White
}

Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                    TEST ZAKOŃCZONY                       ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Podsumowanie
Write-Host "📋 Podsumowanie:" -ForegroundColor Cyan
Write-Host ""

if ($connDetails.ContainsKey('Password')) {
    Write-Host "✅ Connection string zawiera hasło" -ForegroundColor Green
    Write-Host "✅ Konfiguracja jest prawidłowa" -ForegroundColor Green
    Write-Host ""
    Write-Host "🚀 Możesz uruchomić aplikację:" -ForegroundColor Cyan
    Write-Host "   .\restart-app.ps1" -ForegroundColor White
} else {
    Write-Host "❌ Connection string NIE ZAWIERA hasła" -ForegroundColor Red
    Write-Host "📝 Edytuj: $appsettingsPath" -ForegroundColor Yellow
    Write-Host "   Dodaj: ;Password=postgres" -ForegroundColor Yellow
}

Write-Host ""

