﻿﻿using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Application.DTOs;
using MediatR;
using Microsoft.Extensions.Logging;
namespace D2ApiCreator.Application.Features.Documents.Queries.ExtractPlaceholders;
/// <summary>
/// Handler for extracting placeholders from documents
/// </summary>
public class ExtractPlaceholdersQueryHandler : IRequestHandler<ExtractPlaceholdersQuery, DocumentPlaceholderDto>
{
    private readonly IDocumentPlaceholderService _documentPlaceholderService;
    private readonly ILogger<ExtractPlaceholdersQueryHandler> _logger;
    public ExtractPlaceholdersQueryHandler(
        IDocumentPlaceholderService documentPlaceholderService,
        ILogger<ExtractPlaceholdersQueryHandler> logger)
    {
        _documentPlaceholderService = documentPlaceholderService;
        _logger = logger;
    }
    public async Task<DocumentPlaceholderDto> Handle(ExtractPlaceholdersQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Extracting placeholders and content controls from document: {FileName}", request.FileName);
        
        // Extract placeholders <%...%>
        var placeholders = await _documentPlaceholderService.ExtractPlaceholdersFromDocxAsync(
            request.FileStream, 
            request.FileName);
        
        // Reset stream position to read again for content controls
        if (request.FileStream.CanSeek)
        {
            request.FileStream.Position = 0;
        }
        
        // Extract content controls (Rich Text / Plain Text)
        var contentControls = await _documentPlaceholderService.ExtractContentControlsFromDocxAsync(
            request.FileStream,
            request.FileName);
        
        return new DocumentPlaceholderDto
        {
            Placeholders = placeholders,
            PlaceholdersCount = placeholders.Count,
            ContentControls = contentControls,
            ContentControlsCount = contentControls.Count,
            FileName = request.FileName
        };
    }
}
