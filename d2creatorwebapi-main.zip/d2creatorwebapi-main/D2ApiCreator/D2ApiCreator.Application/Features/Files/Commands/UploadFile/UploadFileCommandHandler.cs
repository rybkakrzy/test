using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Domain.Entities;
using D2ApiCreator.Domain.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography;

namespace D2ApiCreator.Application.Features.Files.Commands.UploadFile;

public class UploadFileCommandHandler : IRequestHandler<UploadFileCommand, Guid>
{
    private readonly IFileRepository _fileRepository;
    private readonly IProjectVersionRepository _projectVersionRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<UploadFileCommandHandler> _logger;

    public UploadFileCommandHandler(
        IFileRepository fileRepository,
        IProjectVersionRepository projectVersionRepository,
        IUnitOfWork unitOfWork,
        ILogger<UploadFileCommandHandler> logger)
    {
        _fileRepository = fileRepository;
        _projectVersionRepository = projectVersionRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<Guid> Handle(UploadFileCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("=== START FILE UPLOAD ===");
        _logger.LogInformation("Uploading file {FileName} to project version {ProjectVersionId}", 
            request.File.FileName, request.ProjectVersionId);
        _logger.LogInformation("Content-Type: {ContentType}, FileType: {FileType}", 
            request.File.ContentType, request.FileType ?? "null");

        try
        {
            // Verify project version exists
            _logger.LogInformation("Checking if project version {ProjectVersionId} exists...", request.ProjectVersionId);
            var projectVersion = await _projectVersionRepository.GetByIdAsync(request.ProjectVersionId, cancellationToken);
            
            if (projectVersion == null)
            {
                _logger.LogError("Project version {ProjectVersionId} NOT FOUND in database", request.ProjectVersionId);
                throw new InvalidOperationException($"Project version {request.ProjectVersionId} not found");
            }
            
            _logger.LogInformation("Project version found: {ProjectId}, VersionTag: {VersionTag}", 
                projectVersion.ProjectId, projectVersion.VersionTag);

            // Read file content
            _logger.LogInformation("Reading file content from stream...");
            byte[] fileContent;
            using (var memoryStream = new MemoryStream())
            {
                await request.File.OpenReadStream().CopyToAsync(memoryStream, cancellationToken);
                fileContent = memoryStream.ToArray();
            }
            _logger.LogInformation("File content read successfully. Size: {Size} bytes", fileContent.Length);

            // Calculate SHA256 hash
            _logger.LogInformation("Calculating SHA256 hash...");
            string sha256Hash;
            using (var sha256 = SHA256.Create())
            {
                var hashBytes = sha256.ComputeHash(fileContent);
                sha256Hash = BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();
            }
            _logger.LogInformation("SHA256 hash calculated: {Hash}", sha256Hash);

            // Create file entity
            var fileId = Guid.NewGuid();
            _logger.LogInformation("Creating file entity with ID: {FileId}", fileId);
            var fileEntity = new FileEntity(
                id: fileId,
                projectVersionId: request.ProjectVersionId,
                filename: request.File.FileName,
                content: fileContent,
                contentType: request.File.ContentType,
                size: fileContent.Length,
                sha256: sha256Hash
            );

            _logger.LogInformation("Saving file entity to database...");
            await _fileRepository.AddAsync(fileEntity, cancellationToken);
            await _unitOfWork.SaveChangesAsync(cancellationToken);

            _logger.LogInformation("Successfully uploaded file {FileId} ({FileName}) to project version {ProjectVersionId}", 
                fileId, request.File.FileName, request.ProjectVersionId);
            _logger.LogInformation("=== FILE UPLOAD COMPLETED SUCCESSFULLY ===");

            return fileId;
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Invalid operation during file upload: {Message}", ex.Message);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "=== FILE UPLOAD FAILED === Unexpected error: {Message}", ex.Message);
            _logger.LogError("Stack trace: {StackTrace}", ex.StackTrace);
            throw;
        }
    }
}
