using D2ApiCreator.Application.Common;
using D2ApiCreator.Application.DTOs.Projects;
using D2ApiCreator.Domain.Entities;
using D2ApiCreator.Domain.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;

namespace D2ApiCreator.Application.Features.Projects.Queries.GetProjects;

/// <summary>
/// Handler for getting projects with pagination
/// </summary>
public class GetProjectsQueryHandler : IRequestHandler<GetProjectsQuery, Result<PagedResult<ProjectDto>>>
{
    private readonly IRepository<Project, Guid> _projectRepository;
    private readonly IRepository<ProjectVersion, Guid> _versionRepository;
    private readonly IRepository<TenantMember, Guid> _tenantMemberRepository;
    private readonly ILogger<GetProjectsQueryHandler> _logger;

    public GetProjectsQueryHandler(
        IRepository<Project, Guid> projectRepository,
        IRepository<ProjectVersion, Guid> versionRepository,
        IRepository<TenantMember, Guid> tenantMemberRepository,
        ILogger<GetProjectsQueryHandler> logger)
    {
        _projectRepository = projectRepository;
        _versionRepository = versionRepository;
        _tenantMemberRepository = tenantMemberRepository;
        _logger = logger;
    }

    public async Task<Result<PagedResult<ProjectDto>>> Handle(GetProjectsQuery request, CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Getting projects. TenantId: {TenantId}, Page: {PageNumber}, Size: {PageSize}, Search: {SearchTerm}", 
                request.TenantId, request.PageNumber, request.PageSize, request.SearchTerm);

            var projects = await _projectRepository.GetAllAsync(cancellationToken);

            // Filter by tenant membership if corporate key provided
            if (!string.IsNullOrEmpty(request.CurrentUserCorporateKey))
            {
                // Get all tenant IDs where user is a member
                var userMemberships = await _tenantMemberRepository.FindAsync(
                    m => m.CorporateKey == request.CurrentUserCorporateKey,
                    cancellationToken);

                var userTenantIds = userMemberships.Select(m => m.TenantId).Distinct().ToList();

                // Filter projects to only those in tenants where user is a member, or projects without tenant
                projects = projects.Where(p => !p.TenantId.HasValue || userTenantIds.Contains(p.TenantId.Value)).ToList();
            }

            // Apply filters
            if (request.TenantId.HasValue)
            {
                projects = projects.Where(p => p.TenantId == request.TenantId.Value).ToList();
            }

            if (!string.IsNullOrEmpty(request.Source))
            {
                projects = projects.Where(p => p.Source.Contains(request.Source, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (!string.IsNullOrEmpty(request.SearchTerm))
            {
                var searchLower = request.SearchTerm.ToLower();
                projects = projects.Where(p => 
                    p.Name.ToLower().Contains(searchLower) || 
                    p.Source.ToLower().Contains(searchLower)).ToList();
            }

            if (request.DateFrom.HasValue)
            {
                projects = projects.Where(p => p.CreatedAt >= request.DateFrom.Value).ToList();
            }

            if (request.DateTo.HasValue)
            {
                var dateTo = request.DateTo.Value.Date.AddDays(1).AddTicks(-1);
                projects = projects.Where(p => p.CreatedAt <= dateTo).ToList();
            }

            var projectCount = projects.Count();

            // Order by created date descending and apply pagination
            var pagedItems = projects
                .OrderByDescending(p => p.CreatedAt)
                .Skip((request.PageNumber - 1) * request.PageSize)
                .Take(request.PageSize)
                .ToList();

            var totalPages = (int)Math.Ceiling(projectCount / (double)request.PageSize);

            // Get all active versions in one query
            var activeVersionIds = pagedItems
                .Where(p => p.CurrentActiveVersionId.HasValue)
                .Select(p => p.CurrentActiveVersionId!.Value)
                .Distinct()
                .ToList();

            var activeVersions = activeVersionIds.Any()
                ? await _versionRepository.FindAsync(
                    v => activeVersionIds.Contains(v.Id),
                    cancellationToken)
                : new List<ProjectVersion>();

            var versionLookup = activeVersions.ToDictionary(v => v.Id, v => v);

            // Map to DTOs
            var projectDtos = pagedItems.Select(p =>
            {
                ProjectVersion? activeVersion = null;
                if (p.CurrentActiveVersionId.HasValue && versionLookup.ContainsKey(p.CurrentActiveVersionId.Value))
                {
                    activeVersion = versionLookup[p.CurrentActiveVersionId.Value];
                }

                return new ProjectDto
                {
                    Id = p.Id,
                    TenantId = p.TenantId,
                    Source = p.Source,
                    Name = p.Name,
                    DefaultTemplateName = p.DefaultTemplateName,
                    CreatedBy = p.CreatedBy,
                    CreatedAt = p.CreatedAt,
                    RetentionDays = p.RetentionDays,
                    Description = p.Description,
                    CurrentActiveVersionId = p.CurrentActiveVersionId,
                    ActiveVersionTag = activeVersion?.VersionTag,
                    ActiveVersionTemplateName = activeVersion?.Files.FirstOrDefault()?.Filename
                };
            }).ToList();

            var result = new PagedResult<ProjectDto>
            {
                Items = projectDtos,
                PageNumber = request.PageNumber,
                PageSize = request.PageSize,
                TotalCount = projectCount,
                TotalPages = totalPages
            };

            _logger.LogInformation("Found {Count} projects (page {Page} of {TotalPages})", 
                projectDtos.Count, request.PageNumber, totalPages);

            return Result<PagedResult<ProjectDto>>.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting projects");
            return Result<PagedResult<ProjectDto>>.Failure($"Error getting projects: {ex.Message}");
        }
    }
}
