using D2ApiCreator.Application.Common.Interfaces;
using D2ApiCreator.Application.DTOs.Workers;
using D2ApiCreator.Domain.Entities;
using D2ApiCreator.Domain.Repositories;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace D2ApiCreator.Application.Features.Workers.Commands.GenerateWorkers;

/// <summary>
/// Handler for generating workers from document analysis
/// Creates "Podstaw wartość" workers for placeholders and "Stan" workers for content controls
/// </summary>
public class GenerateWorkersCommandHandler : IRequestHandler<GenerateWorkersCommand, List<WorkerDto>>
{
    private readonly IWorkerRepository _workerRepository;
    private readonly IProjectVersionRepository _projectVersionRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<GenerateWorkersCommandHandler> _logger;

    public GenerateWorkersCommandHandler(
        IWorkerRepository workerRepository,
        IProjectVersionRepository projectVersionRepository,
        IUnitOfWork unitOfWork,
        ILogger<GenerateWorkersCommandHandler> logger)
    {
        _workerRepository = workerRepository;
        _projectVersionRepository = projectVersionRepository;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<List<WorkerDto>> Handle(GenerateWorkersCommand request, CancellationToken cancellationToken)
    {
        var dto = request.Dto;

        // Verify project version exists
        var projectVersion = await _projectVersionRepository.GetByIdAsync(dto.ProjectVersionId, cancellationToken);
        if (projectVersion == null)
        {
            throw new KeyNotFoundException($"Project version with ID {dto.ProjectVersionId} not found");
        }

        _logger.LogInformation(
            "Generating workers for project version {ProjectVersionId}: {PlaceholderCount} placeholders, {ControlCount} content controls",
            dto.ProjectVersionId, dto.Placeholders.Count, dto.ContentControls.Count);

        // Delete existing workers for this project version
        await _workerRepository.DeleteByProjectVersionIdAsync(dto.ProjectVersionId, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var workers = new List<Worker>();

        // Generate "Podstaw wartość" workers for placeholders
        foreach (var placeholder in dto.Placeholders)
        {
            var cleanName = placeholder.Replace("<%", "").Replace("%>", "").Trim();
            
            var configJson = JsonDocument.Parse(JsonSerializer.Serialize(new
            {
                replacement_property_expression = $"formModel.{cleanName}",
                search_for = placeholder
            }));

            var worker = new Worker(
                Guid.NewGuid(),
                dto.ProjectVersionId,
                cleanName,
                "Podstaw wartość",
                configJson
            );

            workers.Add(worker);
            await _workerRepository.AddAsync(worker, cancellationToken);
        }

        // Generate "Stan" workers for content controls (text controls only)
        foreach (var control in dto.ContentControls)
        {
            var configJson = JsonDocument.Parse(JsonSerializer.Serialize(new
            {
                tag_name = control.Key,
                conditional_expression = $"formModel.{control.Key}"
            }));

            var worker = new Worker(
                Guid.NewGuid(),
                dto.ProjectVersionId,
                control.Key,
                "Stan",
                configJson
            );

            workers.Add(worker);
            await _workerRepository.AddAsync(worker, cancellationToken);
        }

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Successfully generated {WorkerCount} workers for project version {ProjectVersionId}",
            workers.Count, dto.ProjectVersionId);

        // Map to DTOs
        return workers.Select(w => new WorkerDto
        {
            Id = w.Id,
            ProjectVersionId = w.ProjectVersionId,
            Name = w.Name,
            WorkerType = w.WorkerType,
            ConfigJson = w.ConfigJson.RootElement.GetRawText(),
            CreatedAt = w.CreatedAt,
            UpdatedAt = w.UpdatedAt
        }).ToList();
    }
}
