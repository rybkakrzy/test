using D2ApiCreator.Domain.Enums;
using System.Text.Json;

namespace D2ApiCreator.Application.DTOs.Projects;

/// <summary>
/// DTO representing a project version
/// </summary>
public class ProjectVersionDto
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public int Major { get; set; }
    public int Minor { get; set; }
    public string VersionTag { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public ProjectStatus Status { get; set; }
    public Guid? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public JsonDocument? StepData { get; set; }
    public string? Notes { get; set; }
}
