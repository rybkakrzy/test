namespace D2ApiCreator.Application.DTOs.Workers;

/// <summary>
/// DTO for generating workers from document analysis
/// </summary>
public class GenerateWorkersDto
{
    /// <summary>
    /// Project version ID
    /// </summary>
    public Guid ProjectVersionId { get; set; }

    /// <summary>
    /// List of placeholders from document (e.g., ["<%data_aktualna%>", "<%porto%>"])
    /// </summary>
    public List<string> Placeholders { get; set; } = new();

    /// <summary>
    /// Dictionary of content controls from document (key: control name, value: type)
    /// </summary>
    public Dictionary<string, string> ContentControls { get; set; } = new();
}
