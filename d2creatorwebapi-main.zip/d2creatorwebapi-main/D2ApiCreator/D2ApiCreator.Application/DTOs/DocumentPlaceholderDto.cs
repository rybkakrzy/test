﻿﻿namespace D2ApiCreator.Application.DTOs;

/// <summary>
/// DTO representing found placeholders and content controls in a document
/// </summary>
public class DocumentPlaceholderDto
{
    /// <summary>
    /// Placeholders in format <%...%>
    /// </summary>
    public List<string> Placeholders { get; set; } = new();
    
    /// <summary>
    /// Content controls (Rich Text / Plain Text) with their names/tags
    /// Key: control tag/alias, Value: always "boolean"
    /// </summary>
    public Dictionary<string, string> ContentControls { get; set; } = new();
    
    /// <summary>
    /// Total count of placeholders
    /// </summary>
    public int PlaceholdersCount { get; set; }
    
    /// <summary>
    /// Total count of content controls
    /// </summary>
    public int ContentControlsCount { get; set; }
    
    /// <summary>
    /// File name
    /// </summary>
    public string FileName { get; set; } = string.Empty;
}
