namespace D2ApiCreator.Application.DTOs.Tenants;

/// <summary>
/// DTO for tenant member information
/// </summary>
public class TenantMemberDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string CorporateKey { get; set; } = string.Empty;
    public Guid AddedBy { get; set; }
    public DateTime AddedAt { get; set; }
}
