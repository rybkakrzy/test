using D2ApiCreator.Application.DTOs.Projects;
using FluentValidation;

namespace D2ApiCreator.Application.Validators.Projects;

/// <summary>
/// Validator for CreateProjectVersionDto
/// </summary>
public class CreateProjectVersionDtoValidator : AbstractValidator<CreateProjectVersionDto>
{
    public CreateProjectVersionDtoValidator()
    {
        RuleFor(x => x.ProjectId)
            .NotEmpty()
            .WithMessage("Project ID is required");

        RuleFor(x => x.Major)
            .GreaterThanOrEqualTo(0)
            .WithMessage("Major version must be non-negative");

        RuleFor(x => x.Minor)
            .GreaterThanOrEqualTo(0)
            .WithMessage("Minor version must be non-negative");

        RuleFor(x => x.ProcessName)
            .NotEmpty()
            .WithMessage("Process name is required")
            .MaximumLength(500)
            .WithMessage("Process name cannot exceed 500 characters");

        // TenantIdentifier is optional - projects can be personal or team-based
        RuleFor(x => x.TenantIdentifier)
            .MaximumLength(200)
            .WithMessage("Tenant identifier cannot exceed 200 characters")
            .When(x => !string.IsNullOrWhiteSpace(x.TenantIdentifier));

        RuleFor(x => x.ProcessOwner)
            .NotEmpty()
            .WithMessage("Process owner is required")
            .MaximumLength(200)
            .WithMessage("Process owner cannot exceed 200 characters");

        RuleFor(x => x.ProcessVersion)
            .NotEmpty()
            .WithMessage("Process version is required")
            .MaximumLength(100)
            .WithMessage("Process version cannot exceed 100 characters");

        RuleFor(x => x.ProcessStep)
            .NotEmpty()
            .WithMessage("Process step is required")
            .MaximumLength(200)
            .WithMessage("Process step cannot exceed 200 characters");

        RuleFor(x => x.StatusId)
            .NotEmpty()
            .WithMessage("Status ID is required")
            .MaximumLength(100)
            .WithMessage("Status ID cannot exceed 100 characters");
    }
}
