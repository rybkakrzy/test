import { Routes } from '@angular/router';
import { AppShellComponent } from './core/layout/app-shell/app-shell.component';
import { adminGuard } from './core/guards/admin.guard';

export const APP_ROUTES: Routes = [
  {
    path: '',
    component: AppShellComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'projects'
      },
      {
        path: 'projects',
        loadChildren: () =>
          import('./features/projects/projects.routes').then(
            m => m.PROJECTS_ROUTES
          )
      },
      {
        path: 'admin',
        canMatch: [adminGuard],
        loadChildren: () =>
          import('./features/admin/admin.routes').then(
            m => m.ADMIN_ROUTES
          )
      },
      {
        path: 'error',
        loadChildren: () =>
          import('./features/error/error.routes').then(
            m => m.ERROR_ROUTES
          )
      },
      {
        path: '**',
        redirectTo: 'error/not-found'
      }
    ]
  }
];
