import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NotificationService } from '../services/notification.service';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  constructor(
    private readonly notifier: NotificationService,
    private readonly router: Router
  ) {}

  intercept(
    req: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 0) {
          this.notifier.showError('API is not reachable at the moment.');
        } else if (error.status === 404) {
          this.router.navigate(['/error/not-found']);
        } else if (error.status >= 500) {
          this.router.navigate(['/error/global']);
        } else {
          this.notifier.showError('Request failed. Please try again.');
        }

        return throwError(() => error);
      })
    );
  }
}
