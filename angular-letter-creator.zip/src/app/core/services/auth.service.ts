import { Injectable } from '@angular/core';

export interface AppUser {
  id: string;
  name: string;
  roles: string[];
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // In a real application this data should come from the authentication backend.
  private readonly mockUser: AppUser | null = {
    id: 'u-001',
    name: 'Admin User',
    roles: ['Admin']
  };

  getCurrentUser(): AppUser | null {
    return this.mockUser;
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.roles.includes('Admin') ?? false;
  }
}
