import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Router } from '@angular/router';
import { PageLayoutComponent } from '../../../shared/ui/page-layout/page-layout.component';
import { EmptyStateComponent } from '../../../shared/ui/empty-state/empty-state.component';
import { Project } from '../../../shared/models/project.model';
import { ProjectListTableComponent } from '../../components/project-list-table/project-list-table.component';

@Component({
  selector: 'app-project-list-page',
  standalone: true,
  imports: [
    CommonModule,
    PageLayoutComponent,
    EmptyStateComponent,
    ProjectListTableComponent
  ],
  templateUrl: './project-list-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectListPageComponent {
  projects: Project[] = [
    {
      id: 'p-001',
      name: 'Contract renewal Q1',
      ownerName: 'Anna Kowalska',
      status: 'InProgress',
      createdAt: '2025-01-10T10:00:00Z'
    },
    {
      id: 'p-002',
      name: 'Vendor onboarding',
      ownerName: 'Jan Nowak',
      status: 'Draft',
      createdAt: '2025-01-12T09:30:00Z'
    }
  ];

  isLoading = false;

  constructor(private readonly router: Router) {}

  onCreateProject(): void {
    console.log('Create project clicked');
  }

  onOpenProject(project: Project): void {
    this.router.navigate(['/projects', project.id]);
  }
}
