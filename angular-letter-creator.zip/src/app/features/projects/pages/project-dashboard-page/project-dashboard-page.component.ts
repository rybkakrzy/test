import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageLayoutComponent } from '../../../shared/ui/page-layout/page-layout.component';

@Component({
  selector: 'app-project-dashboard-page',
  standalone: true,
  imports: [CommonModule, PageLayoutComponent],
  templateUrl: './project-dashboard-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectDashboardPageComponent {
  projectId: string | null;

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {
    this.projectId = this.route.snapshot.paramMap.get('projectId');
  }

  goBackToList(): void {
    this.router.navigate(['/projects']);
  }

  startWizard(): void {
    if (!this.projectId) {
      return;
    }
    this.router.navigate(['/projects', this.projectId, 'wizard']);
  }
}
