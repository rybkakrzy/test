import { CommonModule, DatePipe } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { Project } from '../../../shared/models/project.model';

@Component({
  selector: 'app-project-list-table',
  standalone: true,
  imports: [CommonModule, DatePipe],
  templateUrl: './project-list-table.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProjectListTableComponent {
  @Input() projects: Project[] = [];
  @Input() isLoading = false;

  @Output() openProject = new EventEmitter<Project>();

  onRowClick(project: Project): void {
    this.openProject.emit(project);
  }

  trackByProjectId(_: number, project: Project): string {
    return project.id;
  }
}
