import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { WizardHeaderComponent } from '../../components/wizard-header/wizard-header.component';
import { WizardFooterComponent } from '../../components/wizard-footer/wizard-footer.component';
import {
  WizardStepperNavComponent,
  WizardStepDefinition
} from '../../components/wizard-stepper-nav/wizard-stepper-nav.component';
import { RecipientStepComponent } from '../../steps/recipient-step/recipient-step.component';
import { ContentStepComponent } from '../../steps/content-step/content-step.component';
import { SummaryStepComponent } from '../../steps/summary-step/summary-step.component';

@Component({
  selector: 'app-letter-wizard-page',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    WizardHeaderComponent,
    WizardFooterComponent,
    WizardStepperNavComponent,
    RecipientStepComponent,
    ContentStepComponent,
    SummaryStepComponent
  ],
  templateUrl: './letter-wizard-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LetterWizardPageComponent {
  readonly steps: WizardStepDefinition[] = [
    { key: 'recipient', label: 'Recipient' },
    { key: 'content', label: 'Content' },
    { key: 'summary', label: 'Summary' }
  ];

  readonly activeStepIndex = signal(0);
  readonly activeStepKey = computed(
    () => this.steps[this.activeStepIndex()]?.key ?? 'recipient'
  );

  readonly form: FormGroup;

  isSubmitting = false;

  constructor(private readonly fb: FormBuilder) {
    this.form = this.fb.group({
      recipient: this.fb.group({
        companyName: [''],
        personName: [''],
        address: ['']
      }),
      content: this.fb.group({
        subject: [''],
        body: ['']
      })
    });
  }

  get isLastStep(): boolean {
    return this.activeStepIndex() === this.steps.length - 1;
  }

  get canGoNext(): boolean {
    return this.isCurrentStepValid() && !this.isSubmitting;
  }

  get recipientGroup(): FormGroup {
    return this.form.get('recipient') as FormGroup;
  }

  get contentGroup(): FormGroup {
    return this.form.get('content') as FormGroup;
  }

  goToStep(index: number): void {
    if (index < 0 || index >= this.steps.length) {
      return;
    }
    this.activeStepIndex.set(index);
  }

  goNext(): void {
    if (!this.isCurrentStepValid()) {
      this.markCurrentGroupAsTouched();
      return;
    }

    if (!this.isLastStep) {
      this.activeStepIndex.update(i => i + 1);
      return;
    }

    this.submit();
  }

  goBack(): void {
    if (this.activeStepIndex() === 0) {
      return;
    }

    this.activeStepIndex.update(i => i - 1);
  }

  cancel(): void {
    console.log('Wizard cancelled');
  }

  private isCurrentStepValid(): boolean {
    const currentKey = this.activeStepKey();
    const group = this.form.get(currentKey);

    if (!group) {
      return true;
    }

    return group.valid;
  }

  private markCurrentGroupAsTouched(): void {
    const currentKey = this.activeStepKey();
    const group = this.form.get(currentKey);

    if (!group) {
      return;
    }

    group.markAllAsTouched();
  }

  private submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isSubmitting = true;
    console.log('Submitting letter', this.form.value);

    setTimeout(() => {
      this.isSubmitting = false;
    }, 500);
  }
}
