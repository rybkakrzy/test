import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';

export interface WizardStepDefinition {
  key: string;
  label: string;
}

@Component({
  selector: 'app-wizard-stepper-nav',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './wizard-stepper-nav.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WizardStepperNavComponent {
  @Input() steps: WizardStepDefinition[] = [];
  @Input() activeStepIndex = 0;

  @Output() stepSelected = new EventEmitter<number>();

  onStepClick(index: number): void {
    if (index < 0 || index >= this.steps.length) {
      return;
    }
    this.stepSelected.emit(index);
  }

  trackByIndex(index: number, _step: WizardStepDefinition): number {
    return index;
  }
}
