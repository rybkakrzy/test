import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-wizard-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './wizard-header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class WizardHeaderComponent {
  @Input() title = 'New letter';
  @Input() projectName?: string;
}
