import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-recipient-step',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './recipient-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RecipientStepComponent {
  @Input() formGroup!: FormGroup;
}
