import { Routes } from '@angular/router';
import { AdminShellComponent } from './layout/admin-shell/admin-shell.component';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    component: AdminShellComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'dashboard'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import(
            './pages/admin-dashboard-page/admin-dashboard-page.component'
          ).then(c => c.AdminDashboardPageComponent)
      },
      {
        path: 'projects',
        loadComponent: () =>
          import(
            './pages/admin-projects-page/admin-projects-page.component'
          ).then(c => c.AdminProjectsPageComponent)
      },
      {
        path: 'settings',
        loadComponent: () =>
          import(
            './pages/admin-settings-page/admin-settings-page.component'
          ).then(c => c.AdminSettingsPageComponent)
      }
    ]
  }
];
