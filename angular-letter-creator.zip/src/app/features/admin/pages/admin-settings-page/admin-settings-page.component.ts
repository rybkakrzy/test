import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { PageLayoutComponent } from '../../../shared/ui/page-layout/page-layout.component';

@Component({
  selector: 'app-admin-settings-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, PageLayoutComponent],
  templateUrl: './admin-settings-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminSettingsPageComponent {
  readonly form: FormGroup;

  constructor(private readonly fb: FormBuilder) {
    this.form = this.fb.group({
      showAttachmentsStep: [true],
      requireSubject: [true],
      defaultTemplateName: ['Standard letter']
    });
  }

  onSave(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    console.log('Saving wizard settings', this.form.value);
  }
}
