import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Router } from '@angular/router';
import { PageLayoutComponent } from '../../../shared/ui/page-layout/page-layout.component';
import { EmptyStateComponent } from '../../../shared/ui/empty-state/empty-state.component';
import { Project } from '../../../shared/models/project.model';
import { ProjectListTableComponent } from '../../../features/projects/components/project-list-table/project-list-table.component';

@Component({
  selector: 'app-admin-projects-page',
  standalone: true,
  imports: [
    CommonModule,
    PageLayoutComponent,
    EmptyStateComponent,
    ProjectListTableComponent
  ],
  templateUrl: './admin-projects-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdminProjectsPageComponent {
  projects: Project[] = [];
  isLoading = false;

  constructor(private readonly router: Router) {}

  onOpenProject(project: Project): void {
    this.router.navigate(['/projects', project.id]);
  }
}
