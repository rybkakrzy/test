import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-not-found-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './not-found-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotFoundPageComponent {
  constructor(private readonly router: Router) {}

  goToProjects(): void {
    this.router.navigate(['/projects']);
  }
}
