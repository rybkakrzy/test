import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-global-error-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './global-error-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GlobalErrorPageComponent {
  constructor(private readonly router: Router) {}

  goToProjects(): void {
    this.router.navigate(['/projects']);
  }
}
